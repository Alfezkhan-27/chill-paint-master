import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * CHILL PAINT MASTER - COLOR MIXING STUDIO & VECTOR ARTIST WORKBENCH
 * Professional Dark Executive Theme | Move & 360 Rotate Engine | Instant Shape Fill
 * Crisp Black Button Text | Synthesized Studio Sound Feedback | Centered Obsidian Portal
 */
public class ColorMixingStudio extends JFrame {

    // --- Executive Obsidian Color Palette ---
    public static final Color BG_WINDOW   = new Color(15, 17, 23);
    public static final Color BG_HEADER   = new Color(22, 25, 34);
    public static final Color BG_CARD     = new Color(28, 32, 44);
    public static final Color BG_INPUT    = new Color(18, 20, 28);
    public static final Color BG_DARK     = new Color(18, 20, 28);
    public static final Color CARD_BORDER = new Color(45, 52, 70);
    public static final Color TEXT_LIGHT  = new Color(230, 235, 245);
    public static final Color TEXT_MUTED  = new Color(155, 165, 185);
    public static final Color ACCENT_GOLD = new Color(255, 215, 0);
    public static final Color ACCENT_CYAN = new Color(0, 245, 212);
    public static final Color ACCENT_PINK = new Color(255, 95, 160);

    // --- Global State ---
    public int r1 = 255, g1 = 80, b1 = 80;
    public int r2 = 50, g2 = 120, b2 = 255;
    public float ratio = 0.5f;
    public String blendMode = "Normal (Linear Lerp)";
    public int mixedR = 0, mixedG = 0, mixedB = 0;

    // --- GUI Controls ---
    public JSlider sR1, sG1, sB1, sR2, sG2, sB2, sRatio;
    public JLabel lblR1Val, lblG1Val, lblB1Val, lblR2Val, lblG2Val, lblB2Val, lblRatioVal;
    public JPanel pnlColor1Preview, pnlColor2Preview, pnlMixedPreview, pnlShapeFillSwatch, pnlShapeBorderSwatch;
    public JLabel lblColor1PreviewInfo, lblColor2PreviewInfo;
    public JTextField tfHex1, tfHex2;
    public boolean updatingHexText = false;
    public JComboBox<String> cbBlendMode, cbTools;
    public JLabel lblMixedHex, lblMixedRgb, lblMixedHsv;
    public GradientBar pnlGradient;
    public JPanel pnlHarmonies, pnlPalette;
    public ArrayList<Color> savedColors = new ArrayList<>();

    public PaintCanvas paintCanvas;
    public JSlider sBrushSize, sBrushOpacity;
    public int brushSize = 18, brushOpacity = 100;
    public JButton btnEraser, btnThemeToggle, btnSoundToggle;
    public Random rng = new Random();
    public String loggedInUser = "Guest";

    // --- Responsive Header & Canvas Toolbar Controls ---
    public JPanel topHeader, canvasHeader, titleBox;
    public JLabel lblUserBadge, lblTool, lblFillMode, lblShapeColorTitle, lblSize, lblOpacity;
    public JButton btnRandomize, btnSwap, btnMagicArt, btnTheoryLab, btnColorGame, btnPresentation, btnLogout;
    public JComboBox<String> cbFillMode;
    public JButton btnRotateLeft, btnRotateRight, btnResetRotate;
    public JButton btnChooseFillColor, btnUseMixedAsFill, btnQuickBucket, btnFillSelected, btnChooseBorderColor;
    public JButton btnEyedropper, btnUndo, btnRedo, btnKaleidoscope, btnNeonGlow;
    public JButton btnFill, btnClear, btnOpenImage, btnSavePng;
    public JButton btnCopyCanvas, btnFiltersLab, btnWatermark, btnExtractColors, btnTimelapse;
    public boolean isFullScreenMode = false;

    public ColorMixingStudio() { this("Guest"); }

    public ColorMixingStudio(String user) {
        super("Chill Paint Master - Color Mixing Studio");
        this.loggedInUser = (user != null && !user.trim().isEmpty()) ? user.trim() : "Guest";
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280, 890);
        setMinimumSize(new Dimension(1080, 740));
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_WINDOW);
        UIManager.put("Label.foreground", TEXT_LIGHT);
        setIconImages(getAppIconImages());
        applyTaskbarIcon();

        // Pre-populate palette with high-contrast starting colors
        savedColors.add(new Color(235, 75, 75));
        savedColors.add(new Color(255, 185, 45));
        savedColors.add(new Color(50, 215, 145));
        savedColors.add(new Color(45, 155, 255));
        savedColors.add(new Color(175, 85, 255));

        initUI();
        recalculateAndRepaint();
    }

    public static void applyTaskbarIcon() {
        try {
            if (Taskbar.isTaskbarSupported()) {
                Taskbar taskbar = Taskbar.getTaskbar();
                if (taskbar.isSupported(Taskbar.Feature.ICON_IMAGE)) {
                    taskbar.setIconImage(createAppIcon(256));
                }
            }
        } catch (Throwable ignored) {}
    }

    public static BufferedImage createAppIcon(int size) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        StudioLogo.renderLogo(g2, size, size);
        g2.dispose();
        return img;
    }

    public static java.util.List<Image> getAppIconImages() {
        java.util.List<Image> icons = new ArrayList<>();
        int[] sizes = {16, 24, 32, 48, 64, 128, 256};
        for (int s : sizes) {
            icons.add(createAppIcon(s));
        }
        return icons;
    }

    private void initUI() {
        setLayout(new BorderLayout(8, 8));

        // Top Header
        topHeader = new JPanel();
        topHeader.setBackground(BG_HEADER);
        add(topHeader, BorderLayout.NORTH);

        titleBox = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        titleBox.setOpaque(false);
        titleBox.add(new StudioLogo(42, 42));

        JPanel textTitles = new JPanel(new GridLayout(2, 1, 0, 2));
        textTitles.setOpaque(false);
        JLabel title = new JLabel("CHILL PAINT MASTER");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(ACCENT_GOLD);
        JLabel subtitle = new JLabel("Interactive Color Mixing & Creative Drawing Studio");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitle.setForeground(TEXT_MUTED);
        textTitles.add(title);
        textTitles.add(subtitle);
        titleBox.add(textTitles);

        // Sound Toggle Option (Strictly Black Text)
        btnSoundToggle = new JButton("Sound: ON");
        styleButton(btnSoundToggle, new Color(190, 245, 215));
        btnSoundToggle.setToolTipText("Toggle all studio sound effects ON/OFF");
        btnSoundToggle.addActionListener(e -> {
            SoundManager.enabled = !SoundManager.enabled;
            if (SoundManager.enabled) {
                btnSoundToggle.setText("Sound: ON");
                btnSoundToggle.setBackground(new Color(190, 245, 215));
                SoundManager.play("snap");
            } else {
                btnSoundToggle.setText("Sound: OFF");
                btnSoundToggle.setBackground(new Color(225, 228, 238));
            }
            btnSoundToggle.setForeground(Color.BLACK);
        });

        btnRandomize = new JButton("Randomize");
        styleButton(btnRandomize, new Color(220, 228, 245));
        btnRandomize.addActionListener(e -> {
            r1 = rng.nextInt(256); g1 = rng.nextInt(256); b1 = rng.nextInt(256);
            r2 = rng.nextInt(256); g2 = rng.nextInt(256); b2 = rng.nextInt(256);
            sR1.setValue(r1); sG1.setValue(g1); sB1.setValue(b1);
            sR2.setValue(r2); sG2.setValue(g2); sB2.setValue(b2);
            SoundManager.play("pop");
            recalculateAndRepaint();
        });

        btnSwap = new JButton("Swap Colors");
        styleButton(btnSwap, new Color(220, 228, 245));
        btnSwap.addActionListener(e -> {
            int tr = r1, tg = g1, tb = b1;
            r1 = r2; g1 = g2; b1 = b2;
            r2 = tr; g2 = tg; b2 = tb;
            sR1.setValue(r1); sG1.setValue(g1); sB1.setValue(b1);
            sR2.setValue(r2); sG2.setValue(g2); sB2.setValue(b2);
            SoundManager.play("pop");
            recalculateAndRepaint();
        });

        lblUserBadge = new JLabel("Artist: " + loggedInUser);
        lblUserBadge.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblUserBadge.setForeground(ACCENT_CYAN);

        btnMagicArt = new JButton("Magic Art");
        styleButton(btnMagicArt, Color.WHITE);
        btnMagicArt.setToolTipText("Generate mathematical procedural art masterpieces (Ctrl+M)");
        btnMagicArt.addActionListener(e -> openMagicArtDialog());

        btnTheoryLab = new JButton("Color Theory Lab");
        styleButton(btnTheoryLab, Color.WHITE);
        btnTheoryLab.setToolTipText("Scientific Color Theory, WCAG 2.1 Accessibility & Vision Simulator (Ctrl+T)");
        btnTheoryLab.addActionListener(e -> openColorTheoryLab());

        btnColorGame = new JButton("Color IQ Game");
        styleButton(btnColorGame, Color.WHITE);
        btnColorGame.setToolTipText("Interactive Color IQ Matching Tournament & Chroma Challenge (Ctrl+G)");
        btnColorGame.addActionListener(e -> openColorIQGame());

        btnPresentation = new JButton("Presentation");
        styleButton(btnPresentation, Color.WHITE);
        btnPresentation.setToolTipText("Launch Fullscreen Presentation Showcase Mode (F11)");
        btnPresentation.addActionListener(e -> openPresentationMode());

        btnLogout = new JButton("Logout");
        styleButton(btnLogout, new Color(255, 125, 125));
        btnLogout.addActionListener(e -> {
            SoundManager.play("click");
            dispose();
            showApp(false);
        });

        // Center Split Pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(565);
        splitPane.setContinuousLayout(true);
        splitPane.setBackground(BG_WINDOW);
        splitPane.setDividerSize(6);
        splitPane.setBorder(null);

        // Left Controls Panel (Scrollable)
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBackground(BG_WINDOW);
        leftPanel.setBorder(new EmptyBorder(8, 12, 8, 12));

        // 1. Color A & B Cards
        JPanel twoCards = new JPanel(new GridLayout(1, 2, 10, 0));
        twoCards.setOpaque(false);
        twoCards.add(buildColorControlCard("Source Color A", 1));
        twoCards.add(buildColorControlCard("Source Color B", 2));
        leftPanel.add(twoCards);
        leftPanel.add(Box.createVerticalStrut(10));

        // 2. Mixing Settings Card
        JPanel mixCard = new JPanel();
        mixCard.setLayout(new BoxLayout(mixCard, BoxLayout.Y_AXIS));
        mixCard.setBackground(BG_CARD);
        mixCard.setBorder(BorderFactory.createCompoundBorder(new LineBorder(CARD_BORDER, 1, true), new EmptyBorder(10, 14, 10, 14)));

        JLabel mixTitle = new JLabel("Mixing Settings & Blend Formula");
        mixTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        mixTitle.setForeground(new Color(130, 190, 255));
        mixCard.add(mixTitle);
        mixCard.add(Box.createVerticalStrut(8));

        JPanel ratioRow = new JPanel(new BorderLayout(8, 0));
        ratioRow.setOpaque(false);
        JLabel lblRatioTitle = new JLabel("Blend Ratio (A -> B):");
        lblRatioTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblRatioTitle.setForeground(TEXT_LIGHT);
        sRatio = new JSlider(0, 100, 50);
        sRatio.setOpaque(false);
        lblRatioVal = new JLabel("50% (0.50)");
        lblRatioVal.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblRatioVal.setPreferredSize(new Dimension(80, 20));
        lblRatioVal.setForeground(Color.WHITE);
        final int[] lastRatioSound = {50};
        sRatio.addChangeListener(e -> {
            ratio = sRatio.getValue() / 100.0f;
            lblRatioVal.setText(sRatio.getValue() + "% (" + String.format("%.2f", ratio) + ")");
            if (Math.abs(sRatio.getValue() - lastRatioSound[0]) >= 10) {
                SoundManager.play("tick");
                lastRatioSound[0] = sRatio.getValue();
            }
            recalculateAndRepaint();
        });
        ratioRow.add(lblRatioTitle, BorderLayout.WEST);
        ratioRow.add(sRatio, BorderLayout.CENTER);
        ratioRow.add(lblRatioVal, BorderLayout.EAST);
        mixCard.add(ratioRow);
        mixCard.add(Box.createVerticalStrut(8));

        // Blend Mode Selector (Crisp Black Text)
        JPanel modeRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        modeRow.setOpaque(false);
        JLabel lblMode = new JLabel("Blend Mode:");
        lblMode.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblMode.setForeground(TEXT_LIGHT);

        String[] modes = {
                "Normal (Linear Lerp)", "Multiply (Darkening)", "Screen (Brightening)",
                "Overlay (Contrast)", "Additive (Light Physics)", "Subtractive (Pigment)",
                "Difference", "Average (50/50 Mean)"
        };
        cbBlendMode = new JComboBox<>(modes);
        cbBlendMode.setBackground(new Color(240, 244, 252));
        cbBlendMode.setForeground(Color.BLACK);
        cbBlendMode.setFont(new Font("Segoe UI", Font.BOLD, 12));
        cbBlendMode.setRenderer(createBlackTextRenderer());
        cbBlendMode.setPreferredSize(new Dimension(210, 26));
        cbBlendMode.addActionListener(e -> {
            blendMode = (String) cbBlendMode.getSelectedItem();
            SoundManager.play("click");
            recalculateAndRepaint();
        });
        modeRow.add(lblMode);
        modeRow.add(cbBlendMode);
        mixCard.add(modeRow);
        mixCard.add(Box.createVerticalStrut(8));

        // Preset Quick-Mix Buttons
        JPanel presetRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        presetRow.setOpaque(false);
        JLabel lblPreset = new JLabel("Quick Preset:");
        lblPreset.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblPreset.setForeground(TEXT_LIGHT);

        String[] presets = {
                "Select Preset...", "Sunset Sky (Orange + Violet)", "Ocean Depth (Cyan + Deep Navy)",
                "Cyberpunk Neon (Magenta + Cyan)", "Forest Meadow (Gold + Emerald)", "Volcano Fire (Red + Bright Yellow)"
        };
        JComboBox<String> cbPresets = new JComboBox<>(presets);
        cbPresets.setBackground(new Color(240, 244, 252));
        cbPresets.setForeground(Color.BLACK);
        cbPresets.setFont(new Font("Segoe UI", Font.BOLD, 12));
        cbPresets.setRenderer(createBlackTextRenderer());
        cbPresets.setPreferredSize(new Dimension(210, 26));
        cbPresets.addActionListener(e -> {
            applyPreset((String) cbPresets.getSelectedItem());
            SoundManager.play("pop");
        });
        presetRow.add(lblPreset);
        presetRow.add(cbPresets);
        mixCard.add(presetRow);
        leftPanel.add(mixCard);
        leftPanel.add(Box.createVerticalStrut(10));

        // 3. Mixed Result Card
        JPanel resCard = new JPanel();
        resCard.setLayout(new BoxLayout(resCard, BoxLayout.Y_AXIS));
        resCard.setBackground(BG_CARD);
        resCard.setBorder(BorderFactory.createCompoundBorder(new LineBorder(CARD_BORDER, 1, true), new EmptyBorder(10, 14, 10, 14)));

        JLabel resTitle = new JLabel("Mixed Color Result");
        resTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        resTitle.setForeground(ACCENT_GOLD);
        resCard.add(resTitle);
        resCard.add(Box.createVerticalStrut(8));

        JPanel resInfoRow = new JPanel(new BorderLayout(12, 0));
        resInfoRow.setOpaque(false);
        pnlMixedPreview = new JPanel();
        pnlMixedPreview.setPreferredSize(new Dimension(84, 84));
        pnlMixedPreview.setBackground(Color.DARK_GRAY);
        pnlMixedPreview.setBorder(new LineBorder(Color.WHITE, 2, true));
        resInfoRow.add(pnlMixedPreview, BorderLayout.WEST);

        JPanel resLabels = new JPanel(new GridLayout(4, 1, 0, 3));
        resLabels.setOpaque(false);
        lblMixedHex = new JLabel("HEX: #000000");
        lblMixedHex.setFont(new Font("Consolas", Font.BOLD, 14));
        lblMixedHex.setForeground(ACCENT_CYAN);
        lblMixedRgb = new JLabel("RGB: rgb(0, 0, 0)");
        lblMixedRgb.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblMixedRgb.setForeground(TEXT_LIGHT);
        lblMixedHsv = new JLabel("HSV: 0 deg, 0%, 0%");
        lblMixedHsv.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblMixedHsv.setForeground(TEXT_MUTED);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        btnRow.setOpaque(false);
        JButton btnCopyHex = new JButton("Copy HEX");
        styleButton(btnCopyHex, new Color(220, 228, 245));
        btnCopyHex.addActionListener(e -> {
            String hex = String.format("#%02X%02X%02X", mixedR, mixedG, mixedB);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(hex), null);
            SoundManager.play("snap");
            JOptionPane.showMessageDialog(this, "Copied to clipboard: " + hex, "HEX Copied", JOptionPane.INFORMATION_MESSAGE);
        });

        JButton btnSavePalette = new JButton("+ Save to Palette");
        styleButton(btnSavePalette, new Color(185, 245, 215));
        btnSavePalette.addActionListener(e -> {
            Color mc = new Color(mixedR, mixedG, mixedB);
            if (!savedColors.contains(mc)) {
                savedColors.add(mc);
                updatePalettePanel();
                SoundManager.play("chime");
            }
        });
        btnRow.add(btnCopyHex);
        btnRow.add(btnSavePalette);

        resLabels.add(lblMixedHex);
        resLabels.add(lblMixedRgb);
        resLabels.add(lblMixedHsv);
        resLabels.add(btnRow);
        resInfoRow.add(resLabels, BorderLayout.CENTER);
        resCard.add(resInfoRow);
        resCard.add(Box.createVerticalStrut(10));

        // Interactive Color Gradient Bar
        JLabel lblGrad = new JLabel("Color Gradient (Drag slider to sample):");
        lblGrad.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblGrad.setForeground(TEXT_MUTED);
        pnlGradient = new GradientBar();
        pnlGradient.setPreferredSize(new Dimension(100, 24));
        pnlGradient.setBorder(new LineBorder(CARD_BORDER, 1, true));
        pnlGradient.addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) { updateGradientRatio(e.getX()); SoundManager.play("snap"); }
        });
        pnlGradient.addMouseMotionListener(new MouseMotionAdapter() {
            @Override public void mouseDragged(MouseEvent e) { updateGradientRatio(e.getX()); }
        });
        resCard.add(lblGrad);
        resCard.add(Box.createVerticalStrut(4));
        resCard.add(pnlGradient);
        leftPanel.add(resCard);
        leftPanel.add(Box.createVerticalStrut(10));

        // 4. Harmonies Card
        JPanel harmCard = new JPanel();
        harmCard.setLayout(new BoxLayout(harmCard, BoxLayout.Y_AXIS));
        harmCard.setBackground(BG_CARD);
        harmCard.setBorder(BorderFactory.createCompoundBorder(new LineBorder(CARD_BORDER, 1, true), new EmptyBorder(8, 12, 8, 12)));

        JLabel harmTitle = new JLabel("Color Harmonies (Click to load):");
        harmTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        harmTitle.setForeground(new Color(130, 220, 255));
        harmCard.add(harmTitle);
        harmCard.add(Box.createVerticalStrut(6));

        pnlHarmonies = new JPanel(new GridLayout(1, 5, 6, 0));
        pnlHarmonies.setOpaque(false);
        pnlHarmonies.setPreferredSize(new Dimension(100, 34));
        harmCard.add(pnlHarmonies);
        leftPanel.add(harmCard);
        leftPanel.add(Box.createVerticalStrut(10));

        // 5. Saved Palette Card
        JPanel palCard = new JPanel();
        palCard.setLayout(new BoxLayout(palCard, BoxLayout.Y_AXIS));
        palCard.setBackground(BG_CARD);
        palCard.setBorder(BorderFactory.createCompoundBorder(new LineBorder(CARD_BORDER, 1, true), new EmptyBorder(8, 12, 8, 12)));

        JLabel palTitle = new JLabel("Saved Palette");
        palTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        palTitle.setForeground(ACCENT_GOLD);
        palCard.add(palTitle);
        palCard.add(Box.createVerticalStrut(6));

        pnlPalette = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        pnlPalette.setOpaque(false);
        palCard.add(pnlPalette);
        leftPanel.add(palCard);

        JScrollPane leftScroll = new JScrollPane(leftPanel);
        leftScroll.setBorder(null);
        leftScroll.setBackground(BG_WINDOW);
        leftScroll.getVerticalScrollBar().setUnitIncrement(16);
        splitPane.setLeftComponent(leftScroll);

        // Right Drawing Canvas Area
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(BG_WINDOW);

        paintCanvas = new PaintCanvas();

        // Canvas Header
        canvasHeader = new JPanel();
        canvasHeader.setBackground(BG_HEADER);

        lblTool = new JLabel("Drawing Tool:");
        lblTool.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblTool.setForeground(new Color(130, 205, 255));

        String[] toolOptions = {
                "Select & Move Shape", // Interactive Shape Movement & 360 Rotation
                "Rectangle", "Circle", "Ellipse", "Triangle", "Right Triangle",
                "Diamond", "Rounded Rectangle", "Star", "Arrow", "Heart", "Line",
                "Freehand Brush", "Paint Bucket (Flood Fill)"
        };
        cbTools = new JComboBox<>(toolOptions);
        cbTools.setBackground(new Color(240, 244, 252));
        cbTools.setForeground(Color.BLACK);
        cbTools.setFont(new Font("Segoe UI", Font.BOLD, 12));
        cbTools.setRenderer(createBlackTextRenderer());
        cbTools.setPreferredSize(new Dimension(160, 26));

        lblFillMode = new JLabel("Shape Fill Mode:");
        lblFillMode.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblFillMode.setForeground(TEXT_LIGHT);

        String[] fillModeOptions = { "Solid Fill", "Outline Only", "Fill + Outline" };
        cbFillMode = new JComboBox<>(fillModeOptions);
        cbFillMode.setBackground(new Color(240, 244, 252));
        cbFillMode.setForeground(Color.BLACK);
        cbFillMode.setFont(new Font("Segoe UI", Font.BOLD, 12));
        cbFillMode.setRenderer(createBlackTextRenderer());
        cbFillMode.setPreferredSize(new Dimension(115, 26));

        cbTools.addActionListener(e -> {
            String sel = (String) cbTools.getSelectedItem();
            if (sel != null) {
                if (sel.startsWith("Paint Bucket")) paintCanvas.currentTool = "Bucket";
                else if (sel.startsWith("Freehand")) paintCanvas.currentTool = "Brush";
                else paintCanvas.currentTool = sel;
                paintCanvas.isEraser = false;
                paintCanvas.isEyedropper = false;
                if (btnEraser != null) btnEraser.setText("Eraser");
                SoundManager.play("switch");
            }
        });
        cbFillMode.addActionListener(e -> {
            paintCanvas.shapeStyle = (String) cbFillMode.getSelectedItem();
            if (paintCanvas.selectedShape != null) {
                paintCanvas.saveSnapshot();
                paintCanvas.selectedShape.shapeStyle = paintCanvas.shapeStyle;
                paintCanvas.repaint();
            }
            SoundManager.play("switch");
        });

        btnRotateLeft = new JButton("Rot -45°");
        styleButton(btnRotateLeft, new Color(225, 230, 245));
        btnRotateLeft.setToolTipText("Rotate selected shape 45 degrees counter-clockwise");
        btnRotateLeft.addActionListener(e -> {
            paintCanvas.rotateSelectedOrLast(-Math.PI / 4.0);
            SoundManager.play("rotate");
        });

        btnRotateRight = new JButton("Rot +45°");
        styleButton(btnRotateRight, new Color(225, 230, 245));
        btnRotateRight.setToolTipText("Rotate selected shape 45 degrees clockwise");
        btnRotateRight.addActionListener(e -> {
            paintCanvas.rotateSelectedOrLast(Math.PI / 4.0);
            SoundManager.play("rotate");
        });

        btnResetRotate = new JButton("Reset 0°");
        styleButton(btnResetRotate, new Color(225, 230, 245));
        btnResetRotate.setToolTipText("Reset shape rotation angle to 0 degrees");
        btnResetRotate.addActionListener(e -> {
            paintCanvas.resetRotationSelectedOrLast();
            SoundManager.play("whoosh");
        });

        lblShapeColorTitle = new JLabel("Shape Colors:");
        lblShapeColorTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblShapeColorTitle.setForeground(ACCENT_GOLD);

        pnlShapeFillSwatch = new JPanel();
        pnlShapeFillSwatch.setPreferredSize(new Dimension(24, 22));
        pnlShapeFillSwatch.setBackground(paintCanvas.shapeFillColor);
        pnlShapeFillSwatch.setBorder(new LineBorder(Color.WHITE, 1, true));

        btnChooseFillColor = new JButton("Set Fill Color...");
        styleButton(btnChooseFillColor, new Color(200, 235, 255));
        btnChooseFillColor.setToolTipText("Choose a custom color to fill shapes");
        btnChooseFillColor.addActionListener(e -> {
            Color picked = JColorChooser.showDialog(this, "Choose Shape Fill Color", paintCanvas.shapeFillColor);
            if (picked != null) {
                paintCanvas.syncFillWithMixed = false;
                paintCanvas.shapeFillColor = picked;
                pnlShapeFillSwatch.setBackground(picked);
                if (paintCanvas.selectedShape != null) {
                    paintCanvas.fillSelectedOrLastShape(picked);
                } else {
                    SoundManager.play("click");
                }
            }
        });

        btnUseMixedAsFill = new JButton("Use Mixed Color");
        styleButton(btnUseMixedAsFill, new Color(185, 245, 215));
        btnUseMixedAsFill.setToolTipText("Set the current mixed color as Shape Fill Color");
        btnUseMixedAsFill.addActionListener(e -> {
            paintCanvas.syncFillWithMixed = true;
            Color mc = new Color(mixedR, mixedG, mixedB);
            paintCanvas.shapeFillColor = mc;
            pnlShapeFillSwatch.setBackground(paintCanvas.shapeFillColor);
            if (paintCanvas.selectedShape != null) {
                paintCanvas.fillSelectedOrLastShape(mc);
            } else {
                SoundManager.play("chime");
            }
        });

        btnQuickBucket = new JButton("Paint Bucket (Fill Area)");
        styleButton(btnQuickBucket, new Color(255, 220, 130));
        btnQuickBucket.setToolTipText("Activate Paint Bucket to fill any region on the image or canvas with active color");
        btnQuickBucket.addActionListener(e -> {
            paintCanvas.currentTool = "Bucket";
            if (cbTools != null) cbTools.setSelectedItem("Paint Bucket (Flood Fill)");
            SoundManager.play("fill");
        });

        btnFillSelected = new JButton("Fill Shape / Region");
        styleButton(btnFillSelected, new Color(255, 235, 160));
        btnFillSelected.setToolTipText("Fill selected vector shape or activate Paint Bucket to fill any area on the image");
        btnFillSelected.addActionListener(e -> {
            paintCanvas.fillSelectedOrLastShape(paintCanvas.shapeFillColor);
        });

        pnlShapeBorderSwatch = new JPanel();
        pnlShapeBorderSwatch.setPreferredSize(new Dimension(24, 22));
        pnlShapeBorderSwatch.setBackground(paintCanvas.shapeBorderColor);
        pnlShapeBorderSwatch.setBorder(new LineBorder(Color.WHITE, 1, true));

        btnChooseBorderColor = new JButton("Set Border Color...");
        styleButton(btnChooseBorderColor, new Color(225, 230, 245));
        btnChooseBorderColor.setToolTipText("Choose a custom color for shape outlines & borders");
        btnChooseBorderColor.addActionListener(e -> {
            Color picked = JColorChooser.showDialog(this, "Choose Shape Border Color", paintCanvas.shapeBorderColor);
            if (picked != null) {
                paintCanvas.shapeBorderColor = picked;
                pnlShapeBorderSwatch.setBackground(picked);
                if (paintCanvas.selectedShape != null) {
                    paintCanvas.saveSnapshot();
                    paintCanvas.selectedShape.borderColor = picked;
                    paintCanvas.repaint();
                }
                SoundManager.play("click");
            }
        });

        lblSize = new JLabel("Size:");
        lblSize.setFont(new Font("Segoe UI", Font.BOLD, 12));
        sBrushSize = new JSlider(1, 80, brushSize);
        sBrushSize.setPreferredSize(new Dimension(80, 20));
        sBrushSize.setOpaque(false);
        final int[] lastBrushSound = {brushSize};
        sBrushSize.addChangeListener(e -> {
            brushSize = sBrushSize.getValue();
            if (Math.abs(brushSize - lastBrushSound[0]) >= 4) {
                SoundManager.play("tick");
                lastBrushSound[0] = brushSize;
            }
        });

        lblOpacity = new JLabel("Opacity:");
        lblOpacity.setFont(new Font("Segoe UI", Font.BOLD, 12));
        sBrushOpacity = new JSlider(10, 100, brushOpacity);
        sBrushOpacity.setPreferredSize(new Dimension(75, 20));
        sBrushOpacity.setOpaque(false);
        final int[] lastOpacitySound = {brushOpacity};
        sBrushOpacity.addChangeListener(e -> {
            brushOpacity = sBrushOpacity.getValue();
            if (Math.abs(brushOpacity - lastOpacitySound[0]) >= 6) {
                SoundManager.play("tick");
                lastOpacitySound[0] = brushOpacity;
            }
        });

        btnEraser = new JButton("Eraser");
        styleButton(btnEraser, new Color(225, 230, 242));
        btnEraser.addActionListener(e -> {
            paintCanvas.isEraser = !paintCanvas.isEraser;
            paintCanvas.isEyedropper = false;
            btnEraser.setText(paintCanvas.isEraser ? "Brush Mode" : "Eraser");
            btnEraser.setBackground(paintCanvas.isEraser ? new Color(255, 205, 130) : new Color(225, 230, 242));
            SoundManager.play(paintCanvas.isEraser ? "eraser" : "switch");
        });

        btnEyedropper = new JButton("Eyedropper");
        styleButton(btnEyedropper, new Color(225, 230, 242));
        btnEyedropper.addActionListener(e -> {
            paintCanvas.isEyedropper = !paintCanvas.isEyedropper;
            if (paintCanvas.isEyedropper) { paintCanvas.isEraser = false; btnEraser.setText("Eraser"); }
            btnEyedropper.setBackground(paintCanvas.isEyedropper ? new Color(130, 215, 255) : new Color(225, 230, 242));
            SoundManager.play(paintCanvas.isEyedropper ? "bubble" : "switch");
        });

        btnUndo = new JButton("Undo");
        styleButton(btnUndo, new Color(225, 230, 242));
        btnUndo.addActionListener(e -> { paintCanvas.undo(); SoundManager.play("whoosh"); });

        btnRedo = new JButton("Redo");
        styleButton(btnRedo, new Color(225, 230, 242));
        btnRedo.addActionListener(e -> { paintCanvas.redo(); SoundManager.play("snap"); });

        btnKaleidoscope = new JButton("Kaleidoscope: OFF");
        styleButton(btnKaleidoscope, Color.WHITE);
        btnKaleidoscope.setToolTipText("Toggle live radial symmetry mirror mandala drawing (4x, 8x, 12x, 16x) [Ctrl+K]");
        btnKaleidoscope.addActionListener(e -> {
            paintCanvas.cycleKaleidoscopeMode();
            if (paintCanvas.isKaleidoscope) {
                btnKaleidoscope.setText("Kaleidoscope: " + paintCanvas.kaleidoscopeSlices + "x");
                btnKaleidoscope.setBackground(Color.WHITE);
                btnKaleidoscope.setForeground(Color.BLACK);
                SoundManager.play("chime");
            } else {
                btnKaleidoscope.setText("Kaleidoscope: OFF");
                btnKaleidoscope.setBackground(Color.WHITE);
                btnKaleidoscope.setForeground(Color.BLACK);
                SoundManager.play("whoosh");
            }
        });

        btnNeonGlow = new JButton("Neon Glow FX: OFF");
        styleButton(btnNeonGlow, Color.WHITE);
        btnNeonGlow.setToolTipText("Toggle multi-pass luminous bloom and neon cyber laser glow brush [Ctrl+G]");
        btnNeonGlow.addActionListener(e -> {
            paintCanvas.isNeonGlow = !paintCanvas.isNeonGlow;
            if (paintCanvas.isNeonGlow) {
                btnNeonGlow.setText("Neon Glow FX: ON");
                btnNeonGlow.setBackground(Color.WHITE);
                btnNeonGlow.setForeground(Color.BLACK);
                SoundManager.play("snap");
            } else {
                btnNeonGlow.setText("Neon Glow FX: OFF");
                btnNeonGlow.setBackground(Color.WHITE);
                btnNeonGlow.setForeground(Color.BLACK);
                SoundManager.play("switch");
            }
        });

        btnThemeToggle = new JButton("Dark Canvas");
        styleButton(btnThemeToggle, new Color(225, 230, 242));
        btnThemeToggle.addActionListener(e -> {
            paintCanvas.toggleCanvasTheme();
            btnThemeToggle.setText(paintCanvas.canvasBgColor == Color.WHITE ? "Dark Canvas" : "Light Canvas");
            SoundManager.play("whoosh");
        });

        btnFill = new JButton("Fill Canvas");
        styleButton(btnFill, new Color(200, 225, 250));
        btnFill.addActionListener(e -> {
            paintCanvas.fillBackground(paintCanvas.shapeFillColor);
            SoundManager.play("fill");
        });

        btnClear = new JButton("Clear Canvas");
        styleButton(btnClear, new Color(255, 190, 190));
        btnClear.addActionListener(e -> {
            paintCanvas.clear();
            SoundManager.play("clear");
        });

        btnOpenImage = new JButton("Open Image to Edit...");
        styleButton(btnOpenImage, new Color(200, 235, 255));
        btnOpenImage.setToolTipText("Open and edit a saved image, artwork or photo on the canvas (Ctrl+O)");
        btnOpenImage.addActionListener(e -> paintCanvas.openFileToEdit());

        btnSavePng = new JButton("Save Artwork PNG");
        styleButton(btnSavePng, new Color(195, 245, 215));
        btnSavePng.setToolTipText("Save current artwork to PNG (Ctrl+S)");
        btnSavePng.addActionListener(e -> paintCanvas.saveToFile());

        btnCopyCanvas = new JButton("Copy Canvas");
        styleButton(btnCopyCanvas, Color.WHITE);
        btnCopyCanvas.setToolTipText("Copy full canvas artwork to clipboard to paste in Word, WhatsApp, etc. (Ctrl+C)");
        btnCopyCanvas.addActionListener(e -> copyCanvasToClipboard());

        btnFiltersLab = new JButton("Filters Lab");
        styleButton(btnFiltersLab, Color.WHITE);
        btnFiltersLab.setToolTipText("Studio Post-Processing FX (8-Bit Pixelate, Vignette, Sepia, Invert, Glow, Grayscale)");
        btnFiltersLab.addActionListener(e -> openFiltersDialog());

        btnWatermark = new JButton("Artist Stamp");
        styleButton(btnWatermark, Color.WHITE);
        btnWatermark.setToolTipText("Stamp official artist signature, date & verification certificate badge on artwork");
        btnWatermark.addActionListener(e -> paintCanvas.applyArtistWatermark(loggedInUser));

        btnExtractColors = new JButton("Extract Palette");
        styleButton(btnExtractColors, Color.WHITE);
        btnExtractColors.setToolTipText("Analyze canvas/image and extract top 5 dominant colors into palette");
        btnExtractColors.addActionListener(e -> extractDominantColors());

        btnTimelapse = new JButton("Timelapse Replay");
        styleButton(btnTimelapse, Color.WHITE);
        btnTimelapse.setToolTipText("Replay drawing creation history step-by-step with timeline & speed controls");
        btnTimelapse.addActionListener(e -> openTimelapseDialog());

        getRootPane().registerKeyboardAction(e -> { paintCanvas.undo(); SoundManager.play("whoosh"); },
                KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_DOWN_MASK), JComponent.WHEN_IN_FOCUSED_WINDOW);
        getRootPane().registerKeyboardAction(e -> { paintCanvas.redo(); SoundManager.play("snap"); },
                KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_DOWN_MASK), JComponent.WHEN_IN_FOCUSED_WINDOW);
        getRootPane().registerKeyboardAction(e -> paintCanvas.openFileToEdit(),
                KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_DOWN_MASK), JComponent.WHEN_IN_FOCUSED_WINDOW);
        getRootPane().registerKeyboardAction(e -> paintCanvas.saveToFile(),
                KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK), JComponent.WHEN_IN_FOCUSED_WINDOW);
        getRootPane().registerKeyboardAction(e -> copyCanvasToClipboard(),
                KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_DOWN_MASK), JComponent.WHEN_IN_FOCUSED_WINDOW);
        getRootPane().registerKeyboardAction(e -> openMagicArtDialog(),
                KeyStroke.getKeyStroke(KeyEvent.VK_M, InputEvent.CTRL_DOWN_MASK), JComponent.WHEN_IN_FOCUSED_WINDOW);
        getRootPane().registerKeyboardAction(e -> openColorTheoryLab(),
                KeyStroke.getKeyStroke(KeyEvent.VK_T, InputEvent.CTRL_DOWN_MASK), JComponent.WHEN_IN_FOCUSED_WINDOW);
        getRootPane().registerKeyboardAction(e -> openColorIQGame(),
                KeyStroke.getKeyStroke(KeyEvent.VK_G, InputEvent.CTRL_DOWN_MASK), JComponent.WHEN_IN_FOCUSED_WINDOW);
        getRootPane().registerKeyboardAction(e -> openPresentationMode(),
                KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);

        rightPanel.add(canvasHeader, BorderLayout.NORTH);
        rightPanel.add(paintCanvas, BorderLayout.CENTER);
        splitPane.setRightComponent(rightPanel);
        add(splitPane, BorderLayout.CENTER);

        updateResponsiveLayout();

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                updateResponsiveLayout();
            }
        });
        addWindowStateListener(e -> updateResponsiveLayout());

        updatePalettePanel();
    }

    // =========================================================================
    // RESPONSIVE SYSTEMATIC TOOLBAR MANAGER (FULL SCREEN VS MINI SCREEN)
    // =========================================================================

    public void updateResponsiveLayout() {
        boolean full = (getExtendedState() & JFrame.MAXIMIZED_BOTH) != 0 || getWidth() >= 1420;
        isFullScreenMode = full;

        buildTopHeader(isFullScreenMode);
        buildCanvasHeader(isFullScreenMode);

        topHeader.revalidate();
        topHeader.repaint();
        canvasHeader.revalidate();
        canvasHeader.repaint();
    }

    private JLabel createSectionBadge(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 10));
        lbl.setForeground(new Color(130, 205, 255));
        return lbl;
    }

    private JComponent createToolbarSeparator() {
        JSeparator sep = new JSeparator(JSeparator.VERTICAL);
        sep.setPreferredSize(new Dimension(2, 22));
        sep.setForeground(new Color(65, 75, 100));
        return sep;
    }

    private void buildTopHeader(boolean isFull) {
        topHeader.removeAll();
        if (isFull) {
            // FULL SCREEN MODE: Single continuous high-end executive command bar
            topHeader.setLayout(new BorderLayout(16, 0));
            topHeader.setBorder(new EmptyBorder(10, 22, 10, 22));

            topHeader.add(titleBox, BorderLayout.WEST);

            JPanel rightBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
            rightBar.setOpaque(false);

            // Group 1: Studio Quick Actions
            rightBar.add(btnSoundToggle);
            rightBar.add(btnRandomize);
            rightBar.add(btnSwap);

            rightBar.add(createToolbarSeparator());

            // Group 2: Showcase Suite (White buttons, solid black text)
            rightBar.add(btnMagicArt);
            rightBar.add(btnTheoryLab);
            rightBar.add(btnColorGame);
            rightBar.add(btnPresentation);

            rightBar.add(createToolbarSeparator());

            // Group 3: User Session
            rightBar.add(lblUserBadge);
            rightBar.add(btnLogout);

            topHeader.add(rightBar, BorderLayout.EAST);
        } else {
            // MINI SCREEN MODE: 2-Tier systematic non-clipping command header
            topHeader.setLayout(new BoxLayout(topHeader, BoxLayout.Y_AXIS));
            topHeader.setBorder(new EmptyBorder(6, 14, 6, 14));

            // Tier 1: Brand & User
            JPanel tier1 = new JPanel(new BorderLayout(10, 0));
            tier1.setOpaque(false);
            tier1.add(titleBox, BorderLayout.WEST);

            JPanel tier1Right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            tier1Right.setOpaque(false);
            tier1Right.add(btnSoundToggle);
            tier1Right.add(lblUserBadge);
            tier1Right.add(btnLogout);
            tier1.add(tier1Right, BorderLayout.EAST);

            // Tier 2: Action Suite (Randomize/Swap on Left, Showcase Suite on Right)
            JPanel tier2 = new JPanel(new BorderLayout(10, 0));
            tier2.setOpaque(false);
            tier2.setBorder(new EmptyBorder(5, 0, 0, 0));

            JPanel tier2Left = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            tier2Left.setOpaque(false);
            tier2Left.add(btnRandomize);
            tier2Left.add(btnSwap);
            tier2.add(tier2Left, BorderLayout.WEST);

            JPanel tier2Right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            tier2Right.setOpaque(false);
            tier2Right.add(btnMagicArt);
            tier2Right.add(btnTheoryLab);
            tier2Right.add(btnColorGame);
            tier2Right.add(btnPresentation);
            tier2.add(tier2Right, BorderLayout.EAST);

            topHeader.add(tier1);
            topHeader.add(tier2);
        }
    }

    private void buildCanvasHeader(boolean isFull) {
        canvasHeader.removeAll();
        if (isFull) {
            // FULL SCREEN MODE: 3 wide, systematic categorized rows with clean badges
            canvasHeader.setLayout(new BoxLayout(canvasHeader, BoxLayout.Y_AXIS));
            canvasHeader.setBorder(new EmptyBorder(8, 14, 8, 14));

            // Row 1: Geometry & Vector Tools + Palette
            JPanel r1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
            r1.setOpaque(false);
            r1.add(createSectionBadge("VECTOR TOOLS:"));
            r1.add(cbTools);
            r1.add(lblFillMode);
            r1.add(cbFillMode);
            r1.add(btnRotateLeft);
            r1.add(btnRotateRight);
            r1.add(btnResetRotate);
            r1.add(Box.createHorizontalStrut(12));
            r1.add(createSectionBadge("SHAPE PALETTE:"));
            r1.add(pnlShapeFillSwatch);
            r1.add(btnChooseFillColor);
            r1.add(btnUseMixedAsFill);
            r1.add(pnlShapeBorderSwatch);
            r1.add(btnChooseBorderColor);

            // Row 2: Brush, Painting & Special FX
            JPanel r2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
            r2.setOpaque(false);
            r2.add(createSectionBadge("BRUSH & FX:"));
            r2.add(lblSize);
            r2.add(sBrushSize);
            r2.add(lblOpacity);
            r2.add(sBrushOpacity);
            r2.add(btnEraser);
            r2.add(btnEyedropper);
            r2.add(btnQuickBucket);
            r2.add(btnFillSelected);
            r2.add(Box.createHorizontalStrut(8));
            r2.add(btnUndo);
            r2.add(btnRedo);
            r2.add(Box.createHorizontalStrut(10));
            r2.add(btnKaleidoscope);
            r2.add(btnNeonGlow);

            // Row 3: Canvas Management & File Export
            JPanel r3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
            r3.setOpaque(false);
            r3.add(createSectionBadge("CANVAS & EXPORT:"));
            r3.add(btnThemeToggle);
            r3.add(btnFill);
            r3.add(btnClear);
            r3.add(Box.createHorizontalStrut(10));
            r3.add(btnOpenImage);
            r3.add(btnSavePng);
            r3.add(btnCopyCanvas);

            // Row 4: Studio Creative Lab Suite
            JPanel r4 = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
            r4.setOpaque(false);
            r4.add(createSectionBadge("CREATIVE SUITE:"));
            r4.add(btnFiltersLab);
            r4.add(btnWatermark);
            r4.add(btnExtractColors);
            r4.add(btnTimelapse);

            canvasHeader.add(r1);
            canvasHeader.add(Box.createVerticalStrut(4));
            canvasHeader.add(r2);
            canvasHeader.add(Box.createVerticalStrut(4));
            canvasHeader.add(r3);
            canvasHeader.add(Box.createVerticalStrut(4));
            canvasHeader.add(r4);
        } else {
            // MINI SCREEN MODE: 6 compact, systematic, non-overflowing rows
            canvasHeader.setLayout(new BoxLayout(canvasHeader, BoxLayout.Y_AXIS));
            canvasHeader.setBorder(new EmptyBorder(5, 10, 5, 10));

            // Mini Row 1: Drawing Tool & Rotation
            JPanel mr1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
            mr1.setOpaque(false);
            mr1.add(lblTool);
            mr1.add(cbTools);
            mr1.add(lblFillMode);
            mr1.add(cbFillMode);
            mr1.add(btnRotateLeft);
            mr1.add(btnRotateRight);
            mr1.add(btnResetRotate);

            // Mini Row 2: Shape Colors
            JPanel mr2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
            mr2.setOpaque(false);
            mr2.add(lblShapeColorTitle);
            mr2.add(pnlShapeFillSwatch);
            mr2.add(btnChooseFillColor);
            mr2.add(btnUseMixedAsFill);
            mr2.add(pnlShapeBorderSwatch);
            mr2.add(btnChooseBorderColor);

            // Mini Row 3: Brush Controls & Bucket
            JPanel mr3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
            mr3.setOpaque(false);
            mr3.add(lblSize);
            mr3.add(sBrushSize);
            mr3.add(lblOpacity);
            mr3.add(sBrushOpacity);
            mr3.add(btnEraser);
            mr3.add(btnEyedropper);
            mr3.add(btnQuickBucket);
            mr3.add(btnFillSelected);

            // Mini Row 4: History & Special FX (Prominent spotlight!)
            JPanel mr4 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
            mr4.setOpaque(false);
            mr4.add(btnUndo);
            mr4.add(btnRedo);
            mr4.add(Box.createHorizontalStrut(8));
            mr4.add(btnKaleidoscope);
            mr4.add(btnNeonGlow);

            // Mini Row 5: Canvas Actions & Export
            JPanel mr5 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
            mr5.setOpaque(false);
            mr5.add(btnThemeToggle);
            mr5.add(btnFill);
            mr5.add(btnClear);
            mr5.add(btnOpenImage);
            mr5.add(btnSavePng);
            mr5.add(btnCopyCanvas);

            // Mini Row 6: Creative Suite
            JPanel mr6 = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
            mr6.setOpaque(false);
            mr6.add(btnFiltersLab);
            mr6.add(btnWatermark);
            mr6.add(btnExtractColors);
            mr6.add(btnTimelapse);

            canvasHeader.add(mr1);
            canvasHeader.add(Box.createVerticalStrut(3));
            canvasHeader.add(mr2);
            canvasHeader.add(Box.createVerticalStrut(3));
            canvasHeader.add(mr3);
            canvasHeader.add(Box.createVerticalStrut(3));
            canvasHeader.add(mr4);
            canvasHeader.add(Box.createVerticalStrut(3));
            canvasHeader.add(mr5);
            canvasHeader.add(Box.createVerticalStrut(3));
            canvasHeader.add(mr6);
        }
    }

    private JPanel buildColorControlCard(String title, int colIndex) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(BG_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(CARD_BORDER, 1, true),
                new EmptyBorder(8, 8, 8, 8)
        ));

        // Header with glowing dot and subtitle role
        JPanel titleRow = new JPanel(new BorderLayout());
        titleRow.setOpaque(false);
        titleRow.setMaximumSize(new Dimension(Short.MAX_VALUE, 22));

        JLabel lblTitle = new JLabel(colIndex == 1 ? "● SOURCE COLOR A" : "● SOURCE COLOR B");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblTitle.setForeground(colIndex == 1 ? new Color(255, 125, 125) : new Color(130, 190, 255));

        JLabel lblRole = new JLabel(colIndex == 1 ? "[Base Layer]" : "[Blend Layer]");
        lblRole.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblRole.setForeground(TEXT_MUTED);

        titleRow.add(lblTitle, BorderLayout.WEST);
        titleRow.add(lblRole, BorderLayout.EAST);
        card.add(titleRow);
        card.add(Box.createVerticalStrut(8));

        // Swatch Preview Panel with adaptive high-contrast hex code
        JPanel pnlPreview = new JPanel(new GridBagLayout());
        pnlPreview.setPreferredSize(new Dimension(60, 36));
        pnlPreview.setMaximumSize(new Dimension(Short.MAX_VALUE, 36));
        pnlPreview.setBorder(new LineBorder(new Color(255, 255, 255, 190), 1, true));

        JLabel lblPrev = new JLabel(colIndex == 1 ? "#FF5050" : "#3278FF");
        lblPrev.setFont(new Font("Consolas", Font.BOLD, 11));
        pnlPreview.add(lblPrev);

        if (colIndex == 1) {
            pnlColor1Preview = pnlPreview;
            lblColor1PreviewInfo = lblPrev;
        } else {
            pnlColor2Preview = pnlPreview;
            lblColor2PreviewInfo = lblPrev;
        }
        card.add(pnlPreview);
        card.add(Box.createVerticalStrut(8));

        // Hex Input Row with Black Text Set Button
        JPanel hexRow = new JPanel(new BorderLayout(6, 0));
        hexRow.setOpaque(false);
        hexRow.setMaximumSize(new Dimension(Short.MAX_VALUE, 26));

        JLabel lblHex = new JLabel("HEX: #");
        lblHex.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblHex.setForeground(ACCENT_CYAN);

        JTextField tfHex = new JTextField(colIndex == 1 ? "FF5050" : "3278FF", 6);
        tfHex.setFont(new Font("Consolas", Font.BOLD, 13));
        tfHex.setBackground(BG_INPUT);
        tfHex.setForeground(Color.WHITE);
        tfHex.setCaretColor(ACCENT_CYAN);
        tfHex.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(65, 75, 95), 1, true),
                new EmptyBorder(2, 6, 2, 6)
        ));

        JButton btnApply = new JButton("Set");
        styleButton(btnApply, new Color(225, 230, 245));
        ActionListener hexAction = e -> {
            try {
                String txt = tfHex.getText().trim();
                if (txt.startsWith("#")) txt = txt.substring(1);
                if (txt.length() == 6) {
                    int val = Integer.parseInt(txt, 16);
                    int r = (val >> 16) & 0xFF, g = (val >> 8) & 0xFF, b = val & 0xFF;
                    if (colIndex == 1) { r1 = r; g1 = g; b1 = b; sR1.setValue(r1); sG1.setValue(g1); sB1.setValue(b1); }
                    else { r2 = r; g2 = g; b2 = b; sR2.setValue(r2); sG2.setValue(g2); sB2.setValue(b2); }
                    SoundManager.play("snap");
                    recalculateAndRepaint();
                }
            } catch (Exception ignored) {}
        };
        tfHex.addActionListener(hexAction);
        btnApply.addActionListener(hexAction);
        if (colIndex == 1) tfHex1 = tfHex; else tfHex2 = tfHex;

        hexRow.add(lblHex, BorderLayout.WEST);
        hexRow.add(tfHex, BorderLayout.CENTER);
        hexRow.add(btnApply, BorderLayout.EAST);
        card.add(hexRow);
        card.add(Box.createVerticalStrut(6));

        // Color Dialog Picker Button (Full Width, Black Text)
        JButton btnPick = new JButton("Choose Color Dialog...");
        styleButton(btnPick, new Color(225, 230, 245));
        btnPick.setMaximumSize(new Dimension(Short.MAX_VALUE, 26));
        btnPick.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnPick.addActionListener(e -> {
            Color init = colIndex == 1 ? new Color(r1, g1, b1) : new Color(r2, g2, b2);
            Color picked = JColorChooser.showDialog(this, "Select " + (colIndex == 1 ? "Source Color A" : "Source Color B"), init);
            if (picked != null) {
                if (colIndex == 1) { r1 = picked.getRed(); g1 = picked.getGreen(); b1 = picked.getBlue(); sR1.setValue(r1); sG1.setValue(g1); sB1.setValue(b1); }
                else { r2 = picked.getRed(); g2 = picked.getGreen(); b2 = picked.getBlue(); sR2.setValue(r2); sG2.setValue(g2); sB2.setValue(b2); }
                SoundManager.play("snap");
                recalculateAndRepaint();
            }
        });
        card.add(btnPick);
        card.add(Box.createVerticalStrut(8));

        // R, G, B Sliders with tactile micro-tick audio feedback
        JSlider sR = new JSlider(0, 255, colIndex == 1 ? r1 : r2);
        JSlider sG = new JSlider(0, 255, colIndex == 1 ? g1 : g2);
        JSlider sB = new JSlider(0, 255, colIndex == 1 ? b1 : b2);

        JLabel rVal = new JLabel(String.valueOf(sR.getValue()), SwingConstants.RIGHT);
        JLabel gVal = new JLabel(String.valueOf(sG.getValue()), SwingConstants.RIGHT);
        JLabel bVal = new JLabel(String.valueOf(sB.getValue()), SwingConstants.RIGHT);

        if (colIndex == 1) { sR1 = sR; sG1 = sG; sB1 = sB; lblR1Val = rVal; lblG1Val = gVal; lblB1Val = bVal; }
        else { sR2 = sR; sG2 = sG; sB2 = sB; lblR2Val = rVal; lblG2Val = gVal; lblB2Val = bVal; }

        final int[] lastSoundVal = {0};
        ChangeListener cl = e -> {
            int curR, curG, curB;
            if (colIndex == 1) {
                r1 = sR1.getValue(); g1 = sG1.getValue(); b1 = sB1.getValue();
                lblR1Val.setText(String.valueOf(r1)); lblG1Val.setText(String.valueOf(g1)); lblB1Val.setText(String.valueOf(b1));
                curR = r1; curG = g1; curB = b1;
            } else {
                r2 = sR2.getValue(); g2 = sG2.getValue(); b2 = sB2.getValue();
                lblR2Val.setText(String.valueOf(r2)); lblG2Val.setText(String.valueOf(g2)); lblB2Val.setText(String.valueOf(b2));
                curR = r2; curG = g2; curB = b2;
            }
            if (Math.abs((curR + curG + curB) - lastSoundVal[0]) >= 15) {
                SoundManager.play("tick");
                lastSoundVal[0] = curR + curG + curB;
            }
            recalculateAndRepaint();
        };
        sR.addChangeListener(cl); sG.addChangeListener(cl); sB.addChangeListener(cl);

        card.add(createSliderRow("R", sR, rVal, new Color(255, 100, 100)));
        card.add(Box.createVerticalStrut(3));
        card.add(createSliderRow("G", sG, gVal, new Color(100, 240, 120)));
        card.add(Box.createVerticalStrut(3));
        card.add(createSliderRow("B", sB, bVal, new Color(110, 180, 255)));
        return card;
    }

    private JPanel createSliderRow(String label, JSlider slider, JLabel valLabel, Color labelColor) {
        JPanel row = new JPanel(new BorderLayout(6, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Short.MAX_VALUE, 24));
        JLabel lbl = new JLabel(label, SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lbl.setForeground(labelColor);
        lbl.setPreferredSize(new Dimension(20, 20));
        slider.setOpaque(false);
        valLabel.setFont(new Font("Consolas", Font.BOLD, 12));
        valLabel.setForeground(TEXT_LIGHT);
        valLabel.setPreferredSize(new Dimension(34, 20));
        valLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        row.add(lbl, BorderLayout.WEST);
        row.add(slider, BorderLayout.CENTER);
        row.add(valLabel, BorderLayout.EAST);
        return row;
    }

    public static void styleButton(JButton btn, Color bg) {
        btn.setUI(new javax.swing.plaf.basic.BasicButtonUI());
        btn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btn.setBackground(bg);
        btn.setForeground(Color.BLACK);
        btn.setOpaque(true);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(60, 68, 88), 1, true),
                new EmptyBorder(5, 9, 5, 9)
        ));
    }

    public static ListCellRenderer<Object> createBlackTextRenderer() {
        return new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                JLabel lbl = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
                if (isSelected) {
                    lbl.setBackground(new Color(185, 215, 255));
                    lbl.setForeground(Color.BLACK);
                } else {
                    lbl.setBackground(Color.WHITE);
                    lbl.setForeground(Color.BLACK);
                }
                lbl.setBorder(new EmptyBorder(4, 8, 4, 8));
                return lbl;
            }
        };
    }

    private void updateGradientRatio(int mouseX) {
        if (pnlGradient.getWidth() > 0) {
            float r = Math.max(0.0f, Math.min(1.0f, (float) mouseX / pnlGradient.getWidth()));
            sRatio.setValue(Math.round(r * 100));
        }
    }

    public void openMagicArtDialog() {
        SoundManager.play("chime");
        MagicArtGeneratorDialog dlg = new MagicArtGeneratorDialog(this, paintCanvas);
        dlg.setVisible(true);
    }

    public void openColorTheoryLab() {
        SoundManager.play("click");
        Color c1 = new Color(r1, g1, b1);
        Color c2 = new Color(r2, g2, b2);
        Color cMix = new Color(mixedR, mixedG, mixedB);
        ColorTheoryLabDialog dlg = new ColorTheoryLabDialog(this, c1, c2, cMix);
        dlg.setVisible(true);
    }

    public void openColorIQGame() {
        SoundManager.play("chime");
        ColorIQGameDialog dlg = new ColorIQGameDialog(this);
        dlg.setVisible(true);
    }

    public void openPresentationMode() {
        SoundManager.play("chime");
        int state = getExtendedState();
        if ((state & JFrame.MAXIMIZED_BOTH) == JFrame.MAXIMIZED_BOTH) {
            setExtendedState(JFrame.NORMAL);
            updateResponsiveLayout();
            JOptionPane.showMessageDialog(this,
                    "Exited Presentation Mode. Returned to normal window size.",
                    "Presentation Mode", JOptionPane.INFORMATION_MESSAGE);
        } else {
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            updateResponsiveLayout();
            JOptionPane.showMessageDialog(this,
                    "<html><body style='font-family:Segoe UI; padding:8px;'>"
                    + "<h2 style='color:#00ffff; margin-bottom:5px;'>Projector & Viva Showcase Mode Activated!</h2>"
                    + "<p>The studio is now maximized for classroom & projector evaluation.</p>"
                    + "<ul style='margin-top:6px;'>"
                    + "<li><b>Ctrl + M</b> : Procedural Mathematical Art (Mandala, Fibonacci, Waves)</li>"
                    + "<li><b>Ctrl + T</b> : Color Theory & WCAG 2.1 Accessibility Lab</li>"
                    + "<li><b>Ctrl + G</b> : Interactive Color IQ Matching Tournament & Chroma Game</li>"
                    + "<li><b>Kaleidoscope (Toolbar)</b> : 4x, 8x, 12x, 16x Radial Symmetry Live Drawing</li>"
                    + "<li><b>Neon Glow (Toolbar)</b> : Luminous Cyberpunk Bloom Lighting Brush</li>"
                    + "<li><b>F11</b> : Toggle Presentation View on / off</li>"
                    + "</ul></body></html>",
                    "Viva & Classroom Demo Ready", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void copyCanvasToClipboard() {
        if (paintCanvas == null) return;
        BufferedImage comp = paintCanvas.getCompositeCanvasImage();
        if (comp != null) {
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new ImageTransferable(comp), null);
            SoundManager.play("chime");
            JOptionPane.showMessageDialog(this,
                    "<html><body style='font-family:Segoe UI; padding:6px;'>"
                    + "<h3 style='color:#00f5d4; margin-bottom:4px;'>Canvas Artwork Copied to Clipboard!</h3>"
                    + "<p>You can now paste (<b>Ctrl + V</b>) directly into WhatsApp, MS Word, PowerPoint, Discord, or Photoshop.</p>"
                    + "</body></html>",
                    "Clipboard Export Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void openFiltersDialog() {
        SoundManager.play("click");
        StudioFiltersDialog dlg = new StudioFiltersDialog(this, paintCanvas);
        dlg.setVisible(true);
    }

    public void openTimelapseDialog() {
        SoundManager.play("chime");
        TimelapseReplayDialog dlg = new TimelapseReplayDialog(this, paintCanvas.timelapseFrames);
        dlg.setVisible(true);
    }

    public void extractDominantColors() {
        if (paintCanvas != null) {
            paintCanvas.extractDominantColors(this);
        }
    }

    private void applyPreset(String preset) {
        if (preset == null || preset.startsWith("Select")) return;
        if (preset.contains("Sunset Sky")) setColors(255, 120, 40, 120, 40, 180, 0.5f, "Normal (Linear Lerp)");
        else if (preset.contains("Ocean Depth")) setColors(0, 230, 220, 10, 30, 110, 0.5f, "Screen (Brightening)");
        else if (preset.contains("Cyberpunk Neon")) setColors(255, 0, 128, 0, 240, 255, 0.5f, "Overlay (Contrast)");
        else if (preset.contains("Forest Meadow")) setColors(230, 210, 40, 30, 140, 60, 0.5f, "Multiply (Darkening)");
        else if (preset.contains("Volcano Fire")) setColors(255, 30, 30, 255, 220, 0, 0.5f, "Additive (Light Physics)");
    }

    private void setColors(int rA, int gA, int bA, int rB, int gB, int bB, float rat, String mode) {
        r1 = rA; g1 = gA; b1 = bA; r2 = rB; g2 = gB; b2 = bB;
        sR1.setValue(r1); sG1.setValue(g1); sB1.setValue(b1);
        sR2.setValue(r2); sG2.setValue(g2); sB2.setValue(b2);
        sRatio.setValue(Math.round(rat * 100));
        cbBlendMode.setSelectedItem(mode);
        recalculateAndRepaint();
    }

    public void recalculateAndRepaint() {
        Color c1 = new Color(r1, g1, b1), c2 = new Color(r2, g2, b2);
        if (pnlColor1Preview != null) pnlColor1Preview.setBackground(c1);
        if (pnlColor2Preview != null) pnlColor2Preview.setBackground(c2);

        String hex1 = String.format("%02X%02X%02X", r1, g1, b1);
        String hex2 = String.format("%02X%02X%02X", r2, g2, b2);
        if (lblColor1PreviewInfo != null) {
            lblColor1PreviewInfo.setText("#" + hex1);
            boolean isDark = (r1 * 0.299 + g1 * 0.587 + b1 * 0.114) < 135;
            lblColor1PreviewInfo.setForeground(isDark ? Color.WHITE : Color.BLACK);
        }
        if (lblColor2PreviewInfo != null) {
            lblColor2PreviewInfo.setText("#" + hex2);
            boolean isDark = (r2 * 0.299 + g2 * 0.587 + b2 * 0.114) < 135;
            lblColor2PreviewInfo.setForeground(isDark ? Color.WHITE : Color.BLACK);
        }
        if (!updatingHexText) {
            if (tfHex1 != null && !tfHex1.hasFocus()) tfHex1.setText(hex1);
            if (tfHex2 != null && !tfHex2.hasFocus()) tfHex2.setText(hex2);
        }

        Color mixed = blendColors(c1, c2, ratio, blendMode);
        mixedR = mixed.getRed(); mixedG = mixed.getGreen(); mixedB = mixed.getBlue();

        if (paintCanvas != null && paintCanvas.syncFillWithMixed) {
            paintCanvas.shapeFillColor = mixed;
            if (pnlShapeFillSwatch != null) pnlShapeFillSwatch.setBackground(mixed);
        }

        if (pnlMixedPreview != null) pnlMixedPreview.setBackground(mixed);
        if (lblMixedHex != null) lblMixedHex.setText("HEX: #" + String.format("%02X%02X%02X", mixedR, mixedG, mixedB));
        if (lblMixedRgb != null) lblMixedRgb.setText(String.format("RGB: rgb(%d, %d, %d)", mixedR, mixedG, mixedB));

        float[] hsv = Color.RGBtoHSB(mixedR, mixedG, mixedB, null);
        if (lblMixedHsv != null) lblMixedHsv.setText(String.format("HSV: %d°, %d%%, %d%%",
                Math.round(hsv[0] * 360), Math.round(hsv[1] * 100), Math.round(hsv[2] * 100)));

        if (pnlGradient != null) pnlGradient.repaint();
        updateHarmonies(mixed);
    }

    private Color blendColors(Color c1, Color c2, float t, String mode) {
        float rA = c1.getRed(), gA = c1.getGreen(), bA = c1.getBlue();
        float rB = c2.getRed(), gB = c2.getGreen(), bB = c2.getBlue();

        if (mode.startsWith("Normal")) {
            return new Color(clamp(Math.round(rA + t * (rB - rA))), clamp(Math.round(gA + t * (gB - gA))), clamp(Math.round(bA + t * (bB - bA))));
        } else if (mode.startsWith("Multiply")) {
            int br = (int)((rA * rB) / 255.0f), bg = (int)((gA * gB) / 255.0f), bb = (int)((bA * bB) / 255.0f);
            return new Color(clamp(Math.round(rA + t * (br - rA))), clamp(Math.round(gA + t * (bg - gA))), clamp(Math.round(bA + t * (bb - bA))));
        } else if (mode.startsWith("Screen")) {
            int br = (int)(255 - ((255 - rA) * (255 - rB)) / 255.0f);
            int bg = (int)(255 - ((255 - gA) * (255 - gB)) / 255.0f);
            int bb = (int)(255 - ((255 - bA) * (255 - bB)) / 255.0f);
            return new Color(clamp(Math.round(rA + t * (br - rA))), clamp(Math.round(gA + t * (bg - gA))), clamp(Math.round(bA + t * (bb - bA))));
        } else if (mode.startsWith("Overlay")) {
            int br = overlayChannel((int)rA, (int)rB), bg = overlayChannel((int)gA, (int)gB), bb = overlayChannel((int)bA, (int)bB);
            return new Color(clamp(Math.round(rA + t * (br - rA))), clamp(Math.round(gA + t * (bg - gA))), clamp(Math.round(bA + t * (bb - bA))));
        } else if (mode.startsWith("Additive")) {
            return new Color(clamp(Math.round(rA + t * rB)), clamp(Math.round(gA + t * gB)), clamp(Math.round(bA + t * bB)));
        } else if (mode.startsWith("Subtractive")) {
            return new Color(clamp(Math.round(rA - t * (255 - rB))), clamp(Math.round(gA - t * (255 - gB))), clamp(Math.round(bA - t * (255 - bB))));
        } else if (mode.startsWith("Difference")) {
            int br = (int)Math.abs(rA - rB), bg = (int)Math.abs(gA - gB), bb = (int)Math.abs(bA - bB);
            return new Color(clamp(Math.round(rA + t * (br - rA))), clamp(Math.round(gA + t * (bg - gA))), clamp(Math.round(bA + t * (bb - bA))));
        } else {
            int mr = Math.round((rA + rB) / 2.0f), mg = Math.round((gA + gB) / 2.0f), mb = Math.round((bA + bB) / 2.0f);
            return new Color(clamp(Math.round(rA + t * (mr - rA))), clamp(Math.round(gA + t * (mg - gA))), clamp(Math.round(bA + t * (mb - bA))));
        }
    }

    private int overlayChannel(int a, int b) { return (a < 128) ? (2 * a * b) / 255 : 255 - (2 * (255 - a) * (255 - b)) / 255; }
    private int clamp(int val) { return Math.max(0, Math.min(255, val)); }

    private void updateHarmonies(Color base) {
        if (pnlHarmonies == null) return;
        pnlHarmonies.removeAll();
        float[] hsv = Color.RGBtoHSB(base.getRed(), base.getGreen(), base.getBlue(), null);
        float h = hsv[0], s = hsv[1], v = hsv[2];

        Color[] harms = {
                Color.getHSBColor((h + 0.5f) % 1.0f, s, v),
                Color.getHSBColor((h + 0.416f) % 1.0f, s, v),
                Color.getHSBColor((h + 0.583f) % 1.0f, s, v),
                Color.getHSBColor((h + 0.333f) % 1.0f, s, v),
                Color.getHSBColor((h + 0.083f) % 1.0f, s, v)
        };
        String[] titles = {"Complementary", "Split 1", "Split 2", "Triadic", "Analogous"};

        for (int i = 0; i < harms.length; i++) {
            Color hc = harms[i];
            JButton hb = new JButton();
            hb.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            hb.setBackground(hc);
            hb.setOpaque(true);
            hb.setPreferredSize(new Dimension(36, 32));
            hb.setToolTipText(titles[i] + ": Click for Color A | Right-click for Color B | Shift-click to Fill Shape");
            hb.setBorder(new LineBorder(Color.WHITE, 1, true));
            hb.setCursor(new Cursor(Cursor.HAND_CURSOR));
            hb.addMouseListener(new MouseAdapter() {
                @Override public void mousePressed(MouseEvent e) {
                    if (e.isShiftDown() && paintCanvas != null) {
                        paintCanvas.shapeFillColor = hc;
                        if (pnlShapeFillSwatch != null) pnlShapeFillSwatch.setBackground(hc);
                        paintCanvas.fillSelectedOrLastShape(hc);
                        return;
                    }
                    if (SwingUtilities.isRightMouseButton(e)) {
                        r2 = hc.getRed(); g2 = hc.getGreen(); b2 = hc.getBlue();
                        sR2.setValue(r2); sG2.setValue(g2); sB2.setValue(b2);
                    } else {
                        r1 = hc.getRed(); g1 = hc.getGreen(); b1 = hc.getBlue();
                        sR1.setValue(r1); sG1.setValue(g1); sB1.setValue(b1);
                    }
                    SoundManager.play("snap");
                    recalculateAndRepaint();
                }
            });
            pnlHarmonies.add(hb);
        }
        pnlHarmonies.revalidate();
        pnlHarmonies.repaint();
    }

    public void updatePalettePanel() {
        if (pnlPalette == null) return;
        pnlPalette.removeAll();
        for (Color c : savedColors) {
            JButton pb = new JButton();
            pb.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            pb.setPreferredSize(new Dimension(28, 28));
            pb.setBackground(c);
            pb.setOpaque(true);
            pb.setBorder(new LineBorder(Color.WHITE, 1, true));
            pb.setToolTipText("Left-click: Set Color A | Right-click: Set Color B | Shift-click to Fill Shape");
            pb.setCursor(new Cursor(Cursor.HAND_CURSOR));
            pb.addMouseListener(new MouseAdapter() {
                @Override public void mousePressed(MouseEvent e) {
                    if (e.isShiftDown() && paintCanvas != null) {
                        paintCanvas.shapeFillColor = c;
                        if (pnlShapeFillSwatch != null) pnlShapeFillSwatch.setBackground(c);
                        paintCanvas.fillSelectedOrLastShape(c);
                        return;
                    }
                    if (SwingUtilities.isRightMouseButton(e)) {
                        r2 = c.getRed(); g2 = c.getGreen(); b2 = c.getBlue();
                        sR2.setValue(r2); sG2.setValue(g2); sB2.setValue(b2);
                    } else {
                        r1 = c.getRed(); g1 = c.getGreen(); b1 = c.getBlue();
                        sR1.setValue(r1); sG1.setValue(g1); sB1.setValue(b1);
                    }
                    SoundManager.play("tap");
                    recalculateAndRepaint();
                }
            });
            pnlPalette.add(pb);
        }
        pnlPalette.revalidate();
        pnlPalette.repaint();
    }

    // =========================================================================
    // SOUND ENGINE: High-Quality In-Memory Synthesized Studio Audio
    // =========================================================================
    public static class SoundManager {
        public static boolean enabled = true;

        public static void play(String type) {
            if (!enabled) return;
            new Thread(() -> {
                try {
                    byte[] data = synthesize(type);
                    if (data == null) return;
                    AudioFormat af = new AudioFormat(44100f, 16, 1, true, false);
                    DataLine.Info info = new DataLine.Info(SourceDataLine.class, af);
                    if (!AudioSystem.isLineSupported(info)) return;
                    SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info);
                    line.open(af, data.length);
                    line.start();
                    line.write(data, 0, data.length);
                    line.drain();
                    line.close();
                } catch (Exception ignored) {}
            }).start();
        }

        private static byte[] synthesize(String type) {
            int sampleRate = 44100;
            int durationMs = 120;
            if ("save".equals(type)) durationMs = 380;        // Triple bell chime for image save
            else if ("login".equals(type)) durationMs = 280;  // Harmonic rising chime
            else if ("clear".equals(type)) durationMs = 300;  // Silky airy canvas wipe + sparkle chime
            else if ("fill".equals(type)) durationMs = 240;   // Liquid paint fill droplet chord
            else if ("bubble".equals(type)) durationMs = 130; // Upward water bubble
            else if ("click".equals(type)) durationMs = 35;   // Micro tick
            else if ("snap".equals(type)) durationMs = 65;    // Soft woodblock snap
            else if ("pop".equals(type)) durationMs = 85;     // Lively pop
            else if ("rotate".equals(type)) durationMs = 45;  // Mechanical ratchet cog tick
            else if ("whoosh".equals(type)) durationMs = 160; // Airy whoosh sweep
            else if ("chime".equals(type)) durationMs = 260;  // Dual crystal chime
            else if ("tap".equals(type)) durationMs = 55;     // Organic resonant tap
            else if ("brush".equals(type)) durationMs = 65;   // Soft bristled stroke
            else if ("eraser".equals(type)) durationMs = 80;  // Soft rubber eraser glide
            else if ("tick".equals(type)) durationMs = 24;    // Micro tactile ratchet tick for sliders
            else if ("switch".equals(type)) durationMs = 30;  // Crisp mechanical toggle switch sound

            int totalSamples = (sampleRate * durationMs) / 1000;
            byte[] buffer = new byte[totalSamples * 2];

            for (int i = 0; i < totalSamples; i++) {
                double t = (double) i / sampleRate;
                double progress = (double) i / totalSamples;
                double sample = 0;

                if ("save".equals(type)) {
                    // C6 (1046Hz) -> E6 (1318Hz) -> G6 (1568Hz) triple bell chord
                    double f = (progress < 0.33) ? 1046.5 : (progress < 0.66 ? 1318.5 : 1567.98);
                    double env = Math.exp(-6.0 * (progress % 0.33) * 3);
                    sample = Math.sin(2.0 * Math.PI * f * t) * env * 0.7
                           + Math.sin(4.0 * Math.PI * f * t) * env * 0.2;
                } else if ("login".equals(type)) {
                    // Rising portal chord: G5 (784Hz) -> C6 (1046Hz)
                    double f = (progress < 0.5) ? 783.99 : 1046.5;
                    double env = Math.exp(-5.0 * (progress % 0.5) * 2);
                    sample = Math.sin(2.0 * Math.PI * f * t) * env * 0.7;
                } else if ("clear".equals(type)) {
                    // Silky canvas wipe & airy shimmer:
                    // Soft white noise filtered sweep + uplifting dual chime
                    double wipeNoise = (Math.sin(37.3 * i) + Math.cos(61.7 * i) + Math.sin(103.1 * i)) * 0.18;
                    double wipeEnv = Math.sin(Math.PI * progress);
                    double toneF = 587.33 + progress * 587.33; // D5 -> D6 rising
                    double chime = 0.55 * Math.sin(2.0 * Math.PI * toneF * t)
                                 + 0.25 * Math.sin(4.0 * Math.PI * toneF * t);
                    sample = (chime * 0.65 + wipeNoise * 0.35) * wipeEnv * 0.85;
                } else if ("fill".equals(type)) {
                    // Resonant liquid paint drop (harmonic chord 523Hz + 784Hz + liquid bloom)
                    double env = Math.exp(-6.5 * progress);
                    double f = 523.25 + 160.0 * Math.sin(Math.PI * progress);
                    double harm = Math.sin(2.0 * Math.PI * 783.99 * t) * 0.35;
                    sample = (0.65 * Math.sin(2.0 * Math.PI * f * t) + harm) * env * 0.9;
                } else if ("bubble".equals(type)) {
                    // Water drop pitch slide (300Hz -> 750Hz)
                    double f = 300 + progress * 450;
                    double env = Math.sin(Math.PI * progress);
                    sample = Math.sin(2.0 * Math.PI * f * t) * env * 0.7;
                } else if ("snap".equals(type)) {
                    // Soft snap for shape placement and movement
                    double f = 450 - progress * 200;
                    double env = Math.exp(-12.0 * progress);
                    sample = Math.sin(2.0 * Math.PI * f * t) * env * 0.8;
                } else if ("pop".equals(type)) {
                    // Playful bubble pop
                    double f = 550 + progress * 300;
                    double env = Math.exp(-8.0 * progress);
                    sample = Math.sin(2.0 * Math.PI * f * t) * env * 0.7;
                } else if ("rotate".equals(type)) {
                    // Mechanical ratchet cog tick (sharp attack, metallic overtone)
                    double f = 820 + progress * 180;
                    double env = Math.exp(-24.0 * progress);
                    sample = (Math.sin(2.0 * Math.PI * f * t) * 0.7 + Math.sin(4.0 * Math.PI * f * t) * 0.3) * env * 0.75;
                } else if ("whoosh".equals(type)) {
                    // Airy whoosh sweep (smooth parabolic envelope)
                    double f = 650 - progress * 420;
                    double env = Math.sin(Math.PI * progress);
                    double noise = (Math.sin(23.7 * i) + Math.cos(41.3 * i)) * 0.15;
                    sample = (Math.sin(2.0 * Math.PI * f * t) + noise) * env * 0.65;
                } else if ("chime".equals(type)) {
                    // Dual crystal bell chime (1200Hz + 1800Hz)
                    double env = Math.exp(-6.5 * progress);
                    sample = (0.65 * Math.sin(2.0 * Math.PI * 1200.0 * t) + 0.35 * Math.sin(2.0 * Math.PI * 1800.0 * t)) * env * 0.75;
                } else if ("tap".equals(type)) {
                    // Organic resonant wood tap
                    double f = 480 - progress * 120;
                    double env = Math.exp(-18.0 * progress);
                    sample = Math.sin(2.0 * Math.PI * f * t) * env * 0.8;
                } else if ("brush".equals(type)) {
                    // Soft bristled stroke friction
                    double noise = (Math.sin(19.1 * i) + Math.sin(53.7 * i) + Math.cos(89.3 * i)) * 0.35;
                    double env = Math.sin(Math.PI * progress);
                    sample = noise * env * 0.7;
                } else if ("eraser".equals(type)) {
                    // Soft rubber eraser glide
                    double f = 260.0 - progress * 60.0;
                    double noise = (Math.sin(31.3 * i) + Math.cos(73.1 * i) + Math.sin(113.7 * i)) * 0.30;
                    double env = Math.sin(Math.PI * progress);
                    sample = (Math.sin(2.0 * Math.PI * f * t) * 0.45 + noise * 0.55) * env * 0.75;
                } else if ("tick".equals(type)) {
                    // Micro tactile ratchet tick for sliders
                    double f = 1400;
                    double env = Math.exp(-45.0 * progress);
                    sample = Math.sin(2.0 * Math.PI * f * t) * env * 0.5;
                } else if ("switch".equals(type)) {
                    // Crisp mechanical toggle switch sound
                    double f = 950 + progress * 300;
                    double env = Math.exp(-32.0 * progress);
                    sample = Math.sin(2.0 * Math.PI * f * t) * env * 0.6;
                } else { // "click"
                    double f = 1200;
                    double env = Math.exp(-30.0 * progress);
                    sample = Math.sin(2.0 * Math.PI * f * t) * env * 0.55;
                }

                short s = (short) Math.max(-32767, Math.min(32767, Math.round(sample * 24000)));
                buffer[2 * i] = (byte) (s & 0xff);
                buffer[2 * i + 1] = (byte) ((s >> 8) & 0xff);
            }
            return buffer;
        }
    }

    // =========================================================================
    // INNER CLASS: DrawnShape (Movable Vector Shape Entity with 360° Rotation)
    // =========================================================================
    public static class DrawnShape {
        public String tool;
        public int x1, y1, x2, y2;
        public Color fillColor;
        public Color borderColor;
        public String shapeStyle;
        public int strokeSize;
        public int opacity;
        public double rotationAngle; // In radians (0.0 = default unrotated)

        public DrawnShape(String tool, int x1, int y1, int x2, int y2, Color fillColor, Color borderColor, String shapeStyle, int strokeSize, int opacity) {
            this(tool, x1, y1, x2, y2, fillColor, borderColor, shapeStyle, strokeSize, opacity, 0.0);
        }

        public DrawnShape(String tool, int x1, int y1, int x2, int y2, Color fillColor, Color borderColor, String shapeStyle, int strokeSize, int opacity, double rotationAngle) {
            this.tool = tool;
            this.x1 = x1; this.y1 = y1;
            this.x2 = x2; this.y2 = y2;
            this.fillColor = fillColor;
            this.borderColor = borderColor;
            this.shapeStyle = shapeStyle;
            this.strokeSize = strokeSize;
            this.opacity = opacity;
            this.rotationAngle = rotationAngle;
        }

        public DrawnShape copy() {
            return new DrawnShape(tool, x1, y1, x2, y2, fillColor, borderColor, shapeStyle, strokeSize, opacity, rotationAngle);
        }

        public Point2D.Double getCenter() {
            return new Point2D.Double((x1 + x2) / 2.0, (y1 + y2) / 2.0);
        }

        public Rectangle getBounds() {
            int rx = Math.min(x1, x2), ry = Math.min(y1, y2);
            int rw = Math.max(10, Math.abs(x2 - x1)), rh = Math.max(10, Math.abs(y2 - y1));
            return new Rectangle(rx - strokeSize / 2, ry - strokeSize / 2, rw + strokeSize, rh + strokeSize);
        }

        public Point getUnrotatedPoint(Point p) {
            Point2D.Double c = getCenter();
            double cos = Math.cos(-rotationAngle);
            double sin = Math.sin(-rotationAngle);
            double dx = p.x - c.x;
            double dy = p.y - c.y;
            return new Point((int) Math.round(c.x + (dx * cos - dy * sin)), (int) Math.round(c.y + (dx * sin + dy * cos)));
        }

        public boolean contains(Point p) {
            if (Math.abs(rotationAngle) < 0.001) {
                return getBounds().contains(p);
            }
            Point unrot = getUnrotatedPoint(p);
            return getBounds().contains(unrot);
        }

        public boolean isOverRotationHandle(Point p) {
            Point unrot = getUnrotatedPoint(p);
            Rectangle b = getBounds();
            int handleX = b.x + b.width / 2;
            int handleY = b.y - 24;
            double distSq = (unrot.x - handleX) * (unrot.x - handleX) + (unrot.y - handleY) * (unrot.y - handleY);
            return distSq <= 120; // 11px radius tolerance
        }

        public void translate(int dx, int dy) {
            x1 += dx; y1 += dy;
            x2 += dx; y2 += dy;
        }

        public void rotate(double deltaRadians) {
            rotationAngle += deltaRadians;
            while (rotationAngle > Math.PI) rotationAngle -= 2 * Math.PI;
            while (rotationAngle < -Math.PI) rotationAngle += 2 * Math.PI;
        }
    }

    // =========================================================================
    // INNER CLASS: StudioLogo (High-End Vector Crest Logo)
    // =========================================================================
    public static class StudioLogo extends JComponent {
        public StudioLogo(int width, int height) {
            setPreferredSize(new Dimension(width, height));
            setMinimumSize(new Dimension(width, height));
            setMaximumSize(new Dimension(width, height));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            renderLogo((Graphics2D) g, getWidth(), getHeight());
        }

        public static void renderLogo(Graphics2D gOriginal, int w, int h) {
            Graphics2D g2 = (Graphics2D) gOriginal.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

            g2.setPaint(new GradientPaint(0, 0, new Color(48, 54, 70), w, h, new Color(18, 20, 26)));
            g2.fill(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, 12, 12));
            g2.setPaint(new GradientPaint(0, 0, ACCENT_CYAN, w, h, ACCENT_PINK));
            g2.setStroke(new BasicStroke(1.8f));
            g2.draw(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, 12, 12));

            float s = (w - 10) / 38.0f, ox = 5, oy = 5;
            Path2D.Double palette = new Path2D.Double();
            palette.moveTo(ox + 19 * s, oy + 4 * s);
            palette.curveTo(ox + 31 * s, oy + 4 * s, ox + 35 * s, oy + 16 * s, ox + 33 * s, oy + 24 * s);
            palette.curveTo(ox + 31 * s, oy + 32 * s, ox + 23 * s, oy + 34 * s, ox + 15 * s, oy + 32 * s);
            palette.curveTo(ox + 10 * s, oy + 31 * s, ox + 8 * s, oy + 26 * s, ox + 6 * s, oy + 26 * s);
            palette.curveTo(ox + 3 * s, oy + 26 * s, ox + 3 * s, oy + 16 * s, ox + 6 * s, oy + 10 * s);
            palette.curveTo(ox + 9 * s, oy + 5 * s, ox + 14 * s, oy + 4 * s, ox + 19 * s, oy + 4 * s);
            palette.closePath();

            g2.setPaint(new GradientPaint(ox, oy, new Color(255, 215, 150), ox + 30 * s, oy + 30 * s, new Color(205, 155, 90)));
            g2.fill(palette);
            g2.setColor(new Color(150, 105, 50));
            g2.setStroke(new BasicStroke(1.0f));
            g2.draw(palette);

            g2.setColor(new Color(22, 25, 33));
            g2.fill(new Ellipse2D.Double(ox + 8 * s, oy + 19 * s, 5.5 * s, 6.5 * s));

            Color[] drops = { new Color(255, 60, 60), new Color(255, 195, 0), new Color(0, 235, 175), new Color(40, 175, 255), new Color(195, 75, 255) };
            float[][] pos = { {ox + 13 * s, oy + 8 * s}, {ox + 21 * s, oy + 7 * s}, {ox + 28 * s, oy + 13 * s}, {ox + 26 * s, oy + 22 * s}, {ox + 19 * s, oy + 27 * s} };
            int dr = Math.max(3, Math.round(3.8f * s));
            for (int i = 0; i < drops.length; i++) {
                g2.setColor(drops[i]);
                g2.fillOval((int)pos[i][0] - dr / 2, (int)pos[i][1] - dr / 2, dr, dr);
                g2.setColor(new Color(255, 255, 255, 210));
                g2.fillOval((int)pos[i][0] - dr / 2 + 1, (int)pos[i][1] - dr / 2 + 1, 2, 2);
            }

            g2.setPaint(new GradientPaint(ox + 26 * s, oy + 4 * s, new Color(130, 80, 40), ox + 8 * s, oy + 28 * s, new Color(70, 40, 20)));
            g2.setStroke(new BasicStroke(2.2f * s, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.drawLine(Math.round(ox + 27 * s), Math.round(oy + 3 * s), Math.round(ox + 11 * s), Math.round(oy + 25 * s));

            g2.setColor(new Color(210, 215, 230));
            g2.setStroke(new BasicStroke(2.5f * s));
            g2.drawLine(Math.round(ox + 11 * s), Math.round(oy + 25 * s), Math.round(ox + 8 * s), Math.round(oy + 29 * s));

            g2.setColor(ACCENT_CYAN);
            g2.fillOval(Math.round(ox + 5.5f * s), Math.round(oy + 29.5f * s), Math.round(4 * s), Math.round(4 * s));

            g2.dispose();
        }
    }

    // =========================================================================
    // INNER CLASS: GradientBar
    // =========================================================================
    public class GradientBar extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            Color c1 = new Color(r1, g1, b1), c2 = new Color(r2, g2, b2);
            for (int x = 0; x < w; x++) {
                float t = (float) x / (float) w;
                g2d.setColor(blendColors(c1, c2, t, blendMode));
                g2d.drawLine(x, 0, x, h);
            }

            int mx = Math.round(ratio * w);
            g2d.setColor(Color.WHITE);
            Polygon poly = new Polygon(new int[]{mx - 6, mx + 6, mx}, new int[]{h, h, h - 8}, 3);
            g2d.fillPolygon(poly);
            g2d.setColor(Color.BLACK);
            g2d.drawPolygon(poly);
            g2d.setColor(Color.WHITE);
            g2d.drawLine(mx, 0, mx, h - 8);
        }
    }

    // =========================================================================
    // INNER CLASS: PaintCanvas (Interactive Drawing & Shape Movement Studio)
    // =========================================================================
    class PaintCanvas extends JPanel {
        private BufferedImage canvasImage;
        private Graphics2D g2d;
        public Color canvasBgColor = Color.WHITE;
        public String currentTool = "Select & Move Shape";
        public String shapeStyle = "Solid Fill";
        public Color shapeFillColor = new Color(255, 100, 100);
        public Color shapeBorderColor = Color.BLACK;
        public boolean isEraser = false;
        public boolean isEyedropper = false;
        public boolean syncFillWithMixed = true;
        public boolean isKaleidoscope = false;
        public int kaleidoscopeSlices = 8;
        public boolean isNeonGlow = false;
        public ArrayList<BufferedImage> timelapseFrames = new ArrayList<>();

        public BufferedImage getCompositeCanvasImage() {
            initBufferIfNeeded();
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) { w = 800; h = 600; }
            BufferedImage exportImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            Graphics2D gExport = exportImg.createGraphics();
            gExport.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            gExport.setColor(canvasBgColor);
            gExport.fillRect(0, 0, w, h);
            if (canvasImage != null) gExport.drawImage(canvasImage, 0, 0, null);
            for (DrawnShape s : shapes) renderShape(gExport, s);
            gExport.dispose();
            return exportImg;
        }

        public void recordTimelapseFrame() {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            BufferedImage comp = getCompositeCanvasImage();
            if (comp != null) {
                timelapseFrames.add(comp);
                if (timelapseFrames.size() > 80) {
                    timelapseFrames.remove(1);
                }
            }
        }

        public void cycleKaleidoscopeMode() {
            if (!isKaleidoscope) {
                isKaleidoscope = true;
                kaleidoscopeSlices = 8;
            } else if (kaleidoscopeSlices == 8) {
                kaleidoscopeSlices = 12;
            } else if (kaleidoscopeSlices == 12) {
                kaleidoscopeSlices = 16;
            } else if (kaleidoscopeSlices == 16) {
                kaleidoscopeSlices = 4;
            } else {
                isKaleidoscope = false;
                kaleidoscopeSlices = 8;
            }
            repaint();
        }

        // Movable Shape Architecture
        public final ArrayList<DrawnShape> shapes = new ArrayList<>();
        public DrawnShape selectedShape = null;
        private boolean isMovingShape = false;
        private boolean isRotatingShape = false;
        private double rotateMouseStartAngle = 0.0;
        private double lastSoundAngle = 0.0;

        private Point lastPoint = null;
        private Point dragStart = null, dragCurrent = null;
        private boolean isDraggingShape = false;

        private final Stack<CanvasSnapshot> undoStack = new Stack<>();
        private final Stack<CanvasSnapshot> redoStack = new Stack<>();

        // Quick rotation helpers for toolbar buttons
        public void rotateSelectedOrLast(double delta) {
            DrawnShape target = selectedShape;
            if (target == null && !shapes.isEmpty()) {
                target = shapes.get(shapes.size() - 1);
                selectedShape = target;
            }
            if (target != null) {
                saveSnapshot();
                target.rotate(delta);
                repaint();
            }
        }

        public void resetRotationSelectedOrLast() {
            DrawnShape target = selectedShape;
            if (target == null && !shapes.isEmpty()) {
                target = shapes.get(shapes.size() - 1);
                selectedShape = target;
            }
            if (target != null) {
                saveSnapshot();
                target.rotationAngle = 0.0;
                repaint();
            }
        }

        public void fillSelectedOrLastShape(Color col) {
            DrawnShape target = selectedShape;
            if (target == null && !shapes.isEmpty()) {
                target = shapes.get(shapes.size() - 1);
                selectedShape = target;
            }
            if (target != null) {
                saveSnapshot();
                target.fillColor = col;
                if ("Outline Only".equals(target.shapeStyle)) {
                    target.shapeStyle = "Fill + Outline";
                }
                SoundManager.play("fill");
                repaint();
            } else {
                currentTool = "Bucket";
                if (cbTools != null) cbTools.setSelectedItem("Paint Bucket (Flood Fill)");
                SoundManager.play("fill");
                JOptionPane.showMessageDialog(ColorMixingStudio.this,
                        "Paint Bucket is now ACTIVE!\nClick directly on any shape, line, or area of your image to fill it with color.",
                        "Paint Bucket Ready", JOptionPane.INFORMATION_MESSAGE);
            }
        }

        // Snapshot record storing raster buffer + vector shapes state
        private class CanvasSnapshot {
            BufferedImage img;
            ArrayList<DrawnShape> shapeList;
            CanvasSnapshot(BufferedImage img, ArrayList<DrawnShape> list) {
                this.img = img;
                this.shapeList = list;
            }
        }

        private int strokeSampleCount = 0;

        public PaintCanvas() {
            setBackground(canvasBgColor);
            setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));

            MouseAdapter ma = new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    initBufferIfNeeded();

                    // Eyedropper sampling
                    if (isEyedropper) {
                        int rgb = canvasImage.getRGB(Math.min(canvasImage.getWidth() - 1, Math.max(0, e.getX())),
                                Math.min(canvasImage.getHeight() - 1, Math.max(0, e.getY())));
                        r1 = (rgb >> 16) & 0xFF; g1 = (rgb >> 8) & 0xFF; b1 = rgb & 0xFF;
                        sR1.setValue(r1); sG1.setValue(g1); sB1.setValue(b1);
                        SoundManager.play("chime");
                        recalculateAndRepaint();
                        return;
                    }

                    // Paint Bucket flood fill / Shape vector fill
                    if ("Bucket".equals(currentTool)) {
                        for (int i = shapes.size() - 1; i >= 0; i--) {
                            if (shapes.get(i).contains(e.getPoint())) {
                                selectedShape = shapes.get(i);
                                fillSelectedOrLastShape(shapeFillColor);
                                return;
                            }
                        }
                        floodFill(e.getX(), e.getY(), shapeFillColor);
                        SoundManager.play("fill");
                        return;
                    }

                    // SELECT & MOVE / ROTATE SHAPE TOOL
                    if ("Select & Move Shape".equals(currentTool)) {
                        // 1. Check if clicking on rotation handle of selected shape
                        if (selectedShape != null && selectedShape.isOverRotationHandle(e.getPoint())) {
                            isRotatingShape = true;
                            Point2D.Double c = selectedShape.getCenter();
                            rotateMouseStartAngle = Math.atan2(e.getY() - c.y, e.getX() - c.x);
                            lastSoundAngle = selectedShape.rotationAngle;
                            SoundManager.play("click");
                            return;
                        }

                        // 2. Check if selecting a shape to move or rotate
                        selectedShape = null;
                        for (int i = shapes.size() - 1; i >= 0; i--) {
                            if (shapes.get(i).contains(e.getPoint())) {
                                selectedShape = shapes.get(i);
                                dragStart = e.getPoint();
                                isMovingShape = true;
                                SoundManager.play("click");
                                break;
                            }
                        }
                        repaint();
                        return;
                    }

                    // Freehand Brush / Eraser
                    if ("Brush".equals(currentTool) || isEraser) {
                        saveSnapshot();
                        lastPoint = e.getPoint();
                        drawBrushStroke(lastPoint, lastPoint);
                        strokeSampleCount = 0;
                        SoundManager.play(isEraser ? "eraser" : "brush");
                    } else {
                        // Drawing a new Vector Shape
                        dragStart = e.getPoint();
                        dragCurrent = dragStart;
                        isDraggingShape = true;
                        SoundManager.play("click");
                    }
                }

                @Override
                public void mouseDragged(MouseEvent e) {
                    if (isEyedropper || "Bucket".equals(currentTool)) return;
                    initBufferIfNeeded();

                    // Dragging: Rotating or Moving an existing Shape
                    if ("Select & Move Shape".equals(currentTool)) {
                        if (isRotatingShape && selectedShape != null) {
                            Point2D.Double c = selectedShape.getCenter();
                            double currentMouseAngle = Math.atan2(e.getY() - c.y, e.getX() - c.x);
                            double delta = currentMouseAngle - rotateMouseStartAngle;
                            while (delta > Math.PI) delta -= 2 * Math.PI;
                            while (delta < -Math.PI) delta -= 2 * Math.PI;

                            selectedShape.rotationAngle += delta;
                            rotateMouseStartAngle = currentMouseAngle;

                            while (selectedShape.rotationAngle > Math.PI) selectedShape.rotationAngle -= 2 * Math.PI;
                            while (selectedShape.rotationAngle < -Math.PI) selectedShape.rotationAngle += 2 * Math.PI;

                            if (Math.abs(selectedShape.rotationAngle - lastSoundAngle) >= 0.26) {
                                SoundManager.play("rotate");
                                lastSoundAngle = selectedShape.rotationAngle;
                            }
                            repaint();
                            return;
                        }

                        if (isMovingShape && selectedShape != null && dragStart != null) {
                            int dx = e.getX() - dragStart.x;
                            int dy = e.getY() - dragStart.y;
                            selectedShape.translate(dx, dy);
                            dragStart = e.getPoint();
                            repaint();
                            return;
                        }
                        return;
                    }

                    // Freehand Drawing
                    if ("Brush".equals(currentTool) || isEraser) {
                        Point cp = e.getPoint();
                        if (lastPoint != null) {
                            drawBrushStroke(lastPoint, cp);
                            strokeSampleCount++;
                            if (strokeSampleCount % 5 == 0) {
                                SoundManager.play(isEraser ? "eraser" : "brush");
                            }
                            repaint();
                        }
                        lastPoint = cp;
                    } else if (isDraggingShape) {
                        dragCurrent = e.getPoint();
                        repaint();
                    }
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    // Finished rotating or moving a shape
                    if ("Select & Move Shape".equals(currentTool)) {
                        if (isRotatingShape) {
                            isRotatingShape = false;
                            saveSnapshot();
                            SoundManager.play("snap");
                            repaint();
                            return;
                        }
                        if (isMovingShape) {
                            isMovingShape = false;
                            saveSnapshot();
                            SoundManager.play("snap");
                            repaint();
                            return;
                        }
                        return;
                    }

                    // Finished drawing a vector shape
                    if (isDraggingShape && dragStart != null && dragCurrent != null) {
                        if (Math.abs(dragCurrent.x - dragStart.x) > 3 || Math.abs(dragCurrent.y - dragStart.y) > 3) {
                            saveSnapshot();
                            DrawnShape ds = new DrawnShape(currentTool, dragStart.x, dragStart.y, dragCurrent.x, dragCurrent.y,
                                    shapeFillColor, shapeBorderColor, shapeStyle, brushSize, brushOpacity, 0.0);
                            shapes.add(ds);
                            selectedShape = ds;
                            SoundManager.play("snap");
                        }
                        isDraggingShape = false;
                        dragStart = null;
                        dragCurrent = null;
                        repaint();
                    }
                    if (lastPoint != null) {
                        recordTimelapseFrame();
                    }
                    lastPoint = null;
                }

                @Override
                public void mouseMoved(MouseEvent e) {
                    if ("Select & Move Shape".equals(currentTool)) {
                        if (selectedShape != null && selectedShape.isOverRotationHandle(e.getPoint())) {
                            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                        } else {
                            boolean overShape = false;
                            for (int i = shapes.size() - 1; i >= 0; i--) {
                                if (shapes.get(i).contains(e.getPoint())) {
                                    overShape = true;
                                    break;
                                }
                            }
                            setCursor(overShape ? Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR) : Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
                        }
                    } else if ("Bucket".equals(currentTool)) {
                        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                    } else {
                        setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
                    }
                }
            };
            addMouseListener(ma);
            addMouseMotionListener(ma);
        }

        public void floodFill(int startX, int startY, Color fillColor) {
            floodFill(startX, startY, fillColor, 65);
        }

        public void floodFill(int startX, int startY, Color fillColor, int tolerance) {
            initBufferIfNeeded();
            if (canvasImage == null) return;
            int w = canvasImage.getWidth(), h = canvasImage.getHeight();
            if (startX < 0 || startX >= w || startY < 0 || startY >= h) return;

            int targetRGB = canvasImage.getRGB(startX, startY);
            int newRGB = fillColor.getRGB();

            int tR = (targetRGB >> 16) & 0xFF, tG = (targetRGB >> 8) & 0xFF, tB = targetRGB & 0xFF;
            int nR = (newRGB >> 16) & 0xFF, nG = (newRGB >> 8) & 0xFF, nB = newRGB & 0xFF;

            // If the clicked pixel is already essentially identical to the fill color, return early
            if (Math.abs(tR - nR) + Math.abs(tG - nG) + Math.abs(tB - nB) <= 4) {
                return;
            }

            saveSnapshot();

            // Direct raster pixel access for maximum performance
            int[] pixels = null;
            try {
                if (canvasImage.getRaster().getDataBuffer() instanceof java.awt.image.DataBufferInt) {
                    pixels = ((java.awt.image.DataBufferInt) canvasImage.getRaster().getDataBuffer()).getData();
                }
            } catch (Exception ignored) {}

            int totalPixels = w * h;
            int[] queue = new int[totalPixels];
            boolean[] visited = new boolean[totalPixels];
            int head = 0, tail = 0;

            int startIdx = startY * w + startX;
            queue[tail++] = startIdx;
            visited[startIdx] = true;

            int tol = Math.max(20, tolerance);

            while (head < tail) {
                int idx = queue[head++];
                int x = idx % w;
                int y = idx / w;

                if (pixels != null) {
                    pixels[idx] = newRGB;
                } else {
                    canvasImage.setRGB(x, y, newRGB);
                }

                // Left
                if (x > 0) {
                    int nIdx = idx - 1;
                    if (!visited[nIdx]) {
                        int cRGB = (pixels != null) ? pixels[nIdx] : canvasImage.getRGB(x - 1, y);
                        int cr = (cRGB >> 16) & 0xFF, cg = (cRGB >> 8) & 0xFF, cb = cRGB & 0xFF;
                        if (Math.abs(cr - tR) + Math.abs(cg - tG) + Math.abs(cb - tB) <= tol) {
                            visited[nIdx] = true;
                            queue[tail++] = nIdx;
                        }
                    }
                }
                // Right
                if (x < w - 1) {
                    int nIdx = idx + 1;
                    if (!visited[nIdx]) {
                        int cRGB = (pixels != null) ? pixels[nIdx] : canvasImage.getRGB(x + 1, y);
                        int cr = (cRGB >> 16) & 0xFF, cg = (cRGB >> 8) & 0xFF, cb = cRGB & 0xFF;
                        if (Math.abs(cr - tR) + Math.abs(cg - tG) + Math.abs(cb - tB) <= tol) {
                            visited[nIdx] = true;
                            queue[tail++] = nIdx;
                        }
                    }
                }
                // Up
                if (y > 0) {
                    int nIdx = idx - w;
                    if (!visited[nIdx]) {
                        int cRGB = (pixels != null) ? pixels[nIdx] : canvasImage.getRGB(x, y - 1);
                        int cr = (cRGB >> 16) & 0xFF, cg = (cRGB >> 8) & 0xFF, cb = cRGB & 0xFF;
                        if (Math.abs(cr - tR) + Math.abs(cg - tG) + Math.abs(cb - tB) <= tol) {
                            visited[nIdx] = true;
                            queue[tail++] = nIdx;
                        }
                    }
                }
                // Down
                if (y < h - 1) {
                    int nIdx = idx + w;
                    if (!visited[nIdx]) {
                        int cRGB = (pixels != null) ? pixels[nIdx] : canvasImage.getRGB(x, y + 1);
                        int cr = (cRGB >> 16) & 0xFF, cg = (cRGB >> 8) & 0xFF, cb = cRGB & 0xFF;
                        if (Math.abs(cr - tR) + Math.abs(cg - tG) + Math.abs(cb - tB) <= tol) {
                            visited[nIdx] = true;
                            queue[tail++] = nIdx;
                        }
                    }
                }
            }
            repaint();
        }

        private void saveSnapshot() {
            initBufferIfNeeded();
            if (canvasImage != null) {
                BufferedImage copyImg = new BufferedImage(canvasImage.getWidth(), canvasImage.getHeight(), canvasImage.getType());
                Graphics2D g = copyImg.createGraphics();
                g.drawImage(canvasImage, 0, 0, null);
                g.dispose();

                ArrayList<DrawnShape> copyShapes = new ArrayList<>();
                for (DrawnShape s : shapes) copyShapes.add(s.copy());

                undoStack.push(new CanvasSnapshot(copyImg, copyShapes));
                if (undoStack.size() > 25) undoStack.remove(0);
                redoStack.clear();
                recordTimelapseFrame();
            }
        }

        public void undo() {
            if (!undoStack.isEmpty()) {
                initBufferIfNeeded();
                BufferedImage curImg = new BufferedImage(canvasImage.getWidth(), canvasImage.getHeight(), canvasImage.getType());
                Graphics2D g = curImg.createGraphics();
                g.drawImage(canvasImage, 0, 0, null);
                g.dispose();

                ArrayList<DrawnShape> curShapes = new ArrayList<>();
                for (DrawnShape s : shapes) curShapes.add(s.copy());
                redoStack.push(new CanvasSnapshot(curImg, curShapes));

                CanvasSnapshot prev = undoStack.pop();
                g2d.drawImage(prev.img, 0, 0, null);
                shapes.clear();
                for (DrawnShape s : prev.shapeList) shapes.add(s.copy());
                selectedShape = null;
                repaint();
            }
        }

        public void redo() {
            if (!redoStack.isEmpty()) {
                initBufferIfNeeded();
                BufferedImage curImg = new BufferedImage(canvasImage.getWidth(), canvasImage.getHeight(), canvasImage.getType());
                Graphics2D g = curImg.createGraphics();
                g.drawImage(canvasImage, 0, 0, null);
                g.dispose();

                ArrayList<DrawnShape> curShapes = new ArrayList<>();
                for (DrawnShape s : shapes) curShapes.add(s.copy());
                undoStack.push(new CanvasSnapshot(curImg, curShapes));

                CanvasSnapshot next = redoStack.pop();
                g2d.drawImage(next.img, 0, 0, null);
                shapes.clear();
                for (DrawnShape s : next.shapeList) shapes.add(s.copy());
                selectedShape = null;
                repaint();
            }
        }

        private void initBufferIfNeeded() {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            if (canvasImage == null || canvasImage.getWidth() != w || canvasImage.getHeight() != h) {
                BufferedImage newImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = newImg.createGraphics();
                g.setColor(canvasBgColor);
                g.fillRect(0, 0, w, h);
                if (canvasImage != null) g.drawImage(canvasImage, 0, 0, null);
                g.dispose();

                if (g2d != null) g2d.dispose();
                canvasImage = newImg;
                g2d = canvasImage.createGraphics();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            }
        }

        private void drawBrushStroke(Point p1, Point p2) {
            initBufferIfNeeded();
            if (g2d == null || p1 == null || p2 == null) return;

            int alpha = Math.min(255, Math.max(10, Math.round(brushOpacity * 2.55f)));
            Color baseColor = isEraser ? canvasBgColor : new Color(mixedR, mixedG, mixedB, alpha);

            if (!isKaleidoscope || isEraser) {
                renderSingleStroke(g2d, p1.x, p1.y, p2.x, p2.y, baseColor);
            } else {
                int w = getWidth(), h = getHeight();
                double cx = w / 2.0, cy = h / 2.0;
                int slices = Math.max(2, kaleidoscopeSlices);
                double angleStep = (2.0 * Math.PI) / slices;

                for (int s = 0; s < slices; s++) {
                    double theta = s * angleStep;

                    // Direct rotated stroke
                    double cosT = Math.cos(theta), sinT = Math.sin(theta);
                    int x1r = (int) Math.round(cx + (p1.x - cx) * cosT - (p1.y - cy) * sinT);
                    int y1r = (int) Math.round(cy + (p1.x - cx) * sinT + (p1.y - cy) * cosT);
                    int x2r = (int) Math.round(cx + (p2.x - cx) * cosT - (p2.y - cy) * sinT);
                    int y2r = (int) Math.round(cy + (p2.x - cx) * sinT + (p2.y - cy) * cosT);
                    renderSingleStroke(g2d, x1r, y1r, x2r, y2r, baseColor);

                    // Mirrored reflected stroke (bilateral symmetry per slice)
                    int x1m = (int) Math.round(cx - (p1.x - cx) * cosT - (p1.y - cy) * sinT);
                    int y1m = (int) Math.round(cy - (p1.x - cx) * sinT + (p1.y - cy) * cosT);
                    int x2m = (int) Math.round(cx - (p2.x - cx) * cosT - (p2.y - cy) * sinT);
                    int y2m = (int) Math.round(cy - (p2.x - cx) * sinT + (p2.y - cy) * cosT);
                    renderSingleStroke(g2d, x1m, y1m, x2m, y2m, baseColor);
                }
            }
            repaint();
        }

        private void renderSingleStroke(Graphics2D g, int x1, int y1, int x2, int y2, Color baseColor) {
            if (isEraser || !isNeonGlow) {
                g.setColor(baseColor);
                g.setStroke(new BasicStroke(brushSize, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                if (x1 == x2 && y1 == y2) {
                    int r = brushSize / 2;
                    g.fillOval(x1 - r, y1 - r, brushSize, brushSize);
                } else {
                    g.drawLine(x1, y1, x2, y2);
                }
            } else {
                // Multi-pass Neon Glow Bloom Effect
                int r = baseColor.getRed(), gr = baseColor.getGreen(), b = baseColor.getBlue();

                // Pass 1: Outer soft ethereal bloom aura
                g.setColor(new Color(r, gr, b, Math.max(10, baseColor.getAlpha() / 5)));
                g.setStroke(new BasicStroke(brushSize * 2.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.drawLine(x1, y1, x2, y2);

                // Pass 2: Vibrant mid-radiance aura
                g.setColor(new Color(r, gr, b, Math.max(30, baseColor.getAlpha() / 2)));
                g.setStroke(new BasicStroke(brushSize * 1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.drawLine(x1, y1, x2, y2);

                // Pass 3: Saturated core line
                g.setColor(new Color(r, gr, b, Math.min(255, baseColor.getAlpha())));
                g.setStroke(new BasicStroke(brushSize * 0.9f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.drawLine(x1, y1, x2, y2);

                // Pass 4: Intense white-hot luminescence center line
                int whiteTintR = Math.min(255, r + 160);
                int whiteTintG = Math.min(255, gr + 160);
                int whiteTintB = Math.min(255, b + 160);
                g.setColor(new Color(whiteTintR, whiteTintG, whiteTintB, Math.min(255, baseColor.getAlpha() + 40)));
                g.setStroke(new BasicStroke(Math.max(1.0f, brushSize * 0.32f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.drawLine(x1, y1, x2, y2);
            }
        }

        public void generateProceduralArt(String styleName) {
            initBufferIfNeeded();
            if (g2d == null) return;
            saveSnapshot();

            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) { w = 800; h = 600; }
            double cx = w / 2.0, cy = h / 2.0;
            double maxR = Math.min(w, h) * 0.42;

            Color cA = new Color(r1, g1, b1);
            Color cB = new Color(r2, g2, b2);
            Color cMix = new Color(mixedR, mixedG, mixedB);

            // Automatically switch to dark contrast canvas for maximum luminescence
            if (canvasBgColor == Color.WHITE) {
                canvasBgColor = BG_WINDOW;
                setBackground(canvasBgColor);
                if (btnThemeToggle != null) btnThemeToggle.setText("Light Canvas");
            }
            g2d.setColor(canvasBgColor);
            g2d.fillRect(0, 0, w, h);

            if ("Sacred Rosette Mandala".equals(styleName)) {
                // Sacred rosette with 12 harmonic petals and concentric interlace
                int totalPoints = 3600;
                double loops = 12.0;
                g2d.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

                Point2D.Double prev = null;
                for (int i = 0; i <= totalPoints; i++) {
                    double theta = (i / (double) totalPoints) * Math.PI * 2.0 * loops;
                    double r = maxR * (0.35 + 0.35 * Math.cos(7.0 * theta / loops) + 0.30 * Math.sin(11.0 * theta / loops));
                    double x = cx + r * Math.cos(theta);
                    double y = cy + r * Math.sin(theta);

                    float t = (float) i / totalPoints;
                    Color strokeColor = interpolate3(cA, cMix, cB, t);
                    g2d.setColor(new Color(strokeColor.getRed(), strokeColor.getGreen(), strokeColor.getBlue(), 190));

                    if (prev != null) {
                        g2d.drawLine((int) prev.x, (int) prev.y, (int) x, (int) y);
                    }
                    prev = new Point2D.Double(x, y);
                }

                // Inner sacred geometry rings
                for (int ring = 1; ring <= 6; ring++) {
                    double ringR = maxR * (ring / 6.0);
                    g2d.setColor(new Color(ACCENT_GOLD.getRed(), ACCENT_GOLD.getGreen(), ACCENT_GOLD.getBlue(), 80));
                    g2d.drawOval((int) (cx - ringR), (int) (cy - ringR), (int) (ringR * 2), (int) (ringR * 2));
                }

            } else if ("Galactic Fibonacci Spiral".equals(styleName)) {
                // Vogel's Golden Angle Phyllotaxis Spiral
                int particles = 1200;
                double goldenAngle = Math.toRadians(137.50776405);
                double c = maxR / Math.sqrt(particles);

                for (int n = 0; n < particles; n++) {
                    double r = c * Math.sqrt(n);
                    double theta = n * goldenAngle;
                    int x = (int) Math.round(cx + r * Math.cos(theta));
                    int y = (int) Math.round(cy + r * Math.sin(theta));

                    float t = (float) n / particles;
                    Color col = interpolate3(cMix, cB, ACCENT_GOLD, t);
                    int dotSize = Math.max(3, (int) Math.round(2 + 6 * t));

                    // Glowing dot aura
                    g2d.setColor(new Color(col.getRed(), col.getGreen(), col.getBlue(), 40));
                    g2d.fillOval(x - dotSize, y - dotSize, dotSize * 2, dotSize * 2);

                    // Solid core
                    g2d.setColor(new Color(col.getRed(), col.getGreen(), col.getBlue(), 230));
                    g2d.fillOval(x - dotSize / 2, y - dotSize / 2, dotSize, dotSize);
                }

            } else if ("Harmonic Fourier Spirograph".equals(styleName)) {
                // 3-Harmonic Fourier Epicycloid
                int steps = 4000;
                double R1 = maxR * 0.45, R2 = maxR * 0.30, R3 = maxR * 0.25;
                Point2D.Double prev = null;
                g2d.setStroke(new BasicStroke(1.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

                for (int i = 0; i <= steps; i++) {
                    double t = (i / (double) steps) * Math.PI * 2.0 * 8.0;
                    double x = cx + R1 * Math.cos(t) + R2 * Math.cos(-5.0 * t) + R3 * Math.cos(9.0 * t);
                    double y = cy + R1 * Math.sin(t) + R2 * Math.sin(-5.0 * t) + R3 * Math.sin(9.0 * t);

                    float progress = (float) i / steps;
                    Color col = interpolate3(cA, ACCENT_CYAN, cMix, progress);
                    g2d.setColor(new Color(col.getRed(), col.getGreen(), col.getBlue(), 180));

                    if (prev != null) {
                        g2d.drawLine((int) prev.x, (int) prev.y, (int) x, (int) y);
                    }
                    prev = new Point2D.Double(x, y);
                }

            } else {
                // Cosmic Aurora Wave Symphony
                int ribbons = 22;
                int xSteps = 200;
                g2d.setStroke(new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

                for (int rib = 0; rib < ribbons; rib++) {
                    float ribFraction = (float) rib / ribbons;
                    Color ribColor = interpolate3(cA, cMix, cB, ribFraction);
                    g2d.setColor(new Color(ribColor.getRed(), ribColor.getGreen(), ribColor.getBlue(), 75));

                    Point2D.Double prev = null;
                    double phase = rib * 0.32;
                    double yOffset = (rib - ribbons / 2.0) * (h * 0.035);

                    for (int s = 0; s <= xSteps; s++) {
                        double x = (s / (double) xSteps) * w;
                        double wave1 = Math.sin((x / w) * Math.PI * 4.0 + phase) * (h * 0.12);
                        double wave2 = Math.cos((x / w) * Math.PI * 7.0 - phase * 0.7) * (h * 0.06);
                        double wave3 = Math.sin((x / w) * Math.PI * 11.0 + phase * 1.3) * (h * 0.03);
                        double y = cy + yOffset + wave1 + wave2 + wave3;

                        if (prev != null) {
                            g2d.drawLine((int) prev.x, (int) prev.y, (int) x, (int) y);
                        }
                        prev = new Point2D.Double(x, y);
                    }
                }
            }

            repaint();
            SoundManager.play("chime");
        }

        private Color interpolate3(Color c1, Color c2, Color c3, float t) {
            if (t <= 0.5f) {
                float f = t * 2.0f;
                return new Color(
                        (int) (c1.getRed() + f * (c2.getRed() - c1.getRed())),
                        (int) (c1.getGreen() + f * (c2.getGreen() - c1.getGreen())),
                        (int) (c1.getBlue() + f * (c2.getBlue() - c1.getBlue()))
                );
            } else {
                float f = (t - 0.5f) * 2.0f;
                return new Color(
                        (int) (c2.getRed() + f * (c3.getRed() - c2.getRed())),
                        (int) (c2.getGreen() + f * (c3.getGreen() - c2.getGreen())),
                        (int) (c2.getBlue() + f * (c3.getBlue() - c2.getBlue()))
                );
            }
        }

        private void renderShape(Graphics2D g, DrawnShape ds) {
            Graphics2D g2 = (Graphics2D) g.create();
            Point2D.Double c = ds.getCenter();
            if (Math.abs(ds.rotationAngle) > 0.0001) {
                g2.rotate(ds.rotationAngle, c.x, c.y);
            }
            int rx = Math.min(ds.x1, ds.x2), ry = Math.min(ds.y1, ds.y2);
            int rw = Math.abs(ds.x2 - ds.x1), rh = Math.abs(ds.y2 - ds.y1);
            int alpha = Math.min(255, Math.max(10, Math.round(ds.opacity * 2.55f)));
            Color fillCol = new Color(ds.fillColor.getRed(), ds.fillColor.getGreen(), ds.fillColor.getBlue(), alpha);
            Color borderCol = new Color(ds.borderColor.getRed(), ds.borderColor.getGreen(), ds.borderColor.getBlue(), alpha);

            g2.setStroke(new BasicStroke(Math.max(1.0f, (float) ds.strokeSize), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            if ("Line".equals(ds.tool)) {
                g2.setColor(borderCol);
                g2.drawLine(ds.x1, ds.y1, ds.x2, ds.y2);
                g2.dispose();
                return;
            }
            if (rw == 0 && rh == 0) {
                g2.dispose();
                return;
            }

            Shape s = createShapeGeometry(ds.tool, ds.x1, ds.y1, ds.x2, ds.y2, rx, ry, rw, rh);
            if (s != null) {
                if ("Solid Fill".equals(ds.shapeStyle)) { g2.setColor(fillCol); g2.fill(s); }
                else if ("Fill + Outline".equals(ds.shapeStyle)) { g2.setColor(fillCol); g2.fill(s); g2.setColor(borderCol); g2.draw(s); }
                else { g2.setColor(borderCol); g2.draw(s); }
            }
            g2.dispose();
        }

        private Shape createShapeGeometry(String tool, int x1, int y1, int x2, int y2, int rx, int ry, int rw, int rh) {
            if ("Rectangle".equals(tool) || "Square".equals(tool)) return new Rectangle2D.Double(rx, ry, rw, rh);
            if ("Ellipse".equals(tool)) return new Ellipse2D.Double(rx, ry, rw, rh);
            if ("Circle".equals(tool)) {
                int d = Math.max(rw, rh);
                return new Ellipse2D.Double(x2 >= x1 ? x1 : x1 - d, y2 >= y1 ? y1 : y1 - d, d, d);
            }
            if ("Triangle".equals(tool)) return new Polygon(new int[]{rx + rw / 2, rx, rx + rw}, new int[]{ry, ry + rh, ry + rh}, 3);
            if ("Right Triangle".equals(tool)) return new Polygon(new int[]{rx, rx, rx + rw}, new int[]{ry, ry + rh, ry + rh}, 3);
            if ("Diamond".equals(tool)) return new Polygon(new int[]{rx + rw / 2, rx + rw, rx + rw / 2, rx}, new int[]{ry, ry + rh / 2, ry + rh, ry + rh / 2}, 4);
            if ("Rounded Rectangle".equals(tool)) {
                int arc = Math.min(32, Math.max(8, Math.min(rw, rh) / 3));
                return new RoundRectangle2D.Double(rx, ry, rw, rh, arc, arc);
            }
            if ("Star".equals(tool)) return createStar(rx + rw / 2.0, ry + rh / 2.0, Math.min(rw, rh) / 2.0, Math.min(rw, rh) * 0.22);
            if ("Arrow".equals(tool)) return createArrow(rx, ry, rw, rh, x2 >= x1);
            if ("Heart".equals(tool)) return createHeart(rx, ry, rw, rh);
            return null;
        }

        private Shape createStar(double cx, double cy, double outerR, double innerR) {
            Path2D.Double p = new Path2D.Double();
            for (int i = 0; i < 10; i++) {
                double r = (i % 2 == 0) ? outerR : innerR;
                double angle = -Math.PI / 2.0 + i * Math.PI / 5.0;
                double x = cx + r * Math.cos(angle), y = cy + r * Math.sin(angle);
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            p.closePath();
            return p;
        }

        private Shape createArrow(int x, int y, int w, int h, boolean right) {
            Path2D.Double p = new Path2D.Double();
            float bh = h * 0.38f, by = y + (h - bh) / 2.0f, hw = w * 0.42f;
            if (right) {
                p.moveTo(x, by); p.lineTo(x + w - hw, by); p.lineTo(x + w - hw, y);
                p.lineTo(x + w, y + h / 2.0f); p.lineTo(x + w - hw, y + h);
                p.lineTo(x + w - hw, by + bh); p.lineTo(x, by + bh);
            } else {
                p.moveTo(x + w, by); p.lineTo(x + hw, by); p.lineTo(x + hw, y);
                p.lineTo(x, y + h / 2.0f); p.lineTo(x + hw, y + h);
                p.lineTo(x + hw, by + bh); p.lineTo(x + w, by + bh);
            }
            p.closePath();
            return p;
        }

        private Shape createHeart(int x, int y, int w, int h) {
            Path2D.Double p = new Path2D.Double();
            double cx = x + w / 2.0;
            p.moveTo(cx, y + h * 0.28);
            p.curveTo(cx - w * 0.28, y - h * 0.05, x, y + h * 0.12, x, y + h * 0.38);
            p.curveTo(x, y + h * 0.65, cx - w * 0.2, y + h * 0.82, cx, y + h);
            p.curveTo(cx + w * 0.2, y + h * 0.82, x + w, y + h * 0.65, x + w, y + h * 0.38);
            p.curveTo(x + w, y + h * 0.12, cx + w * 0.28, y - h * 0.05, cx, y + h * 0.28);
            p.closePath();
            return p;
        }

        public void toggleCanvasTheme() {
            saveSnapshot();
            canvasBgColor = (canvasBgColor == Color.WHITE) ? Color.BLACK : Color.WHITE;
            setBackground(canvasBgColor);
            initBufferIfNeeded();
            if (canvasImage != null) {
                g2d.setColor(canvasBgColor);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                repaint();
            }
        }

        public void fillBackground(Color c) {
            saveSnapshot();
            initBufferIfNeeded();
            if (canvasImage != null) {
                g2d.setColor(c);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                repaint();
            }
            SoundManager.play("fill");
        }

        public void clear() {
            saveSnapshot();
            initBufferIfNeeded();
            shapes.clear();
            selectedShape = null;
            if (canvasImage != null) {
                g2d.setColor(canvasBgColor);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                repaint();
            }
            SoundManager.play("clear");
        }

        public void openFileToEdit() {
            initBufferIfNeeded();
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Open Saved Image or Artwork to Edit");
            chooser.setFileFilter(new FileNameExtensionFilter("Image Files (*.png, *.jpg, *.jpeg, *.bmp)", "png", "jpg", "jpeg", "bmp"));
            File defDir = new File(".");
            if (defDir.exists()) chooser.setCurrentDirectory(defDir);

            if (chooser.showOpenDialog(ColorMixingStudio.this) == JFileChooser.APPROVE_OPTION) {
                File f = chooser.getSelectedFile();
                try {
                    BufferedImage loaded = ImageIO.read(f);
                    if (loaded == null) {
                        JOptionPane.showMessageDialog(ColorMixingStudio.this,
                                "Unsupported or corrupted image file.\nPlease choose a valid PNG, JPG, or BMP file.",
                                "Cannot Open Image", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Save snapshot to undo stack so user can Ctrl+Z if opened by mistake
                    saveSnapshot();
                    shapes.clear();
                    selectedShape = null;

                    int w = getWidth(), h = getHeight();
                    if (w <= 0 || h <= 0) { w = 800; h = 600; }

                    // Fill canvas with background first
                    g2d.setColor(canvasBgColor);
                    g2d.fillRect(0, 0, w, h);

                    // Scale to fit proportionally if image is larger than canvas
                    int imgW = loaded.getWidth(), imgH = loaded.getHeight();
                    int targetW = imgW, targetH = imgH;
                    if (targetW > w || targetH > h) {
                        double scale = Math.min((double) w / targetW, (double) h / targetH);
                        targetW = Math.max(1, (int) Math.round(targetW * scale));
                        targetH = Math.max(1, (int) Math.round(targetH * scale));
                    }
                    int posX = Math.max(0, (w - targetW) / 2);
                    int posY = Math.max(0, (h - targetH) / 2);

                    g2d.drawImage(loaded, posX, posY, targetW, targetH, null);

                    // Activate Paint Bucket tool so user can immediately click and fill colors on the loaded image!
                    currentTool = "Bucket";
                    if (cbTools != null) cbTools.setSelectedItem("Paint Bucket (Flood Fill)");
                    shapeFillColor = new Color(mixedR, mixedG, mixedB);
                    if (pnlShapeFillSwatch != null) pnlShapeFillSwatch.setBackground(shapeFillColor);
                    syncFillWithMixed = true;
                    repaint();

                    recordTimelapseFrame();
                    SoundManager.play("chime");

                    int prompt = JOptionPane.showConfirmDialog(ColorMixingStudio.this,
                            "Artwork loaded successfully for editing!\n\n"
                            + "Would you like to automatically extract its Top 5 Dominant Colors into your Palette?",
                            "Extract Palette From Image?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if (prompt == JOptionPane.YES_OPTION) {
                        extractDominantColors(ColorMixingStudio.this);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(ColorMixingStudio.this,
                            "Error opening file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

        public void saveToFile() {
            initBufferIfNeeded();
            JFileChooser chooser = new JFileChooser();
            chooser.setSelectedFile(new File("chill_paint_masterpiece.png"));
            chooser.setFileFilter(new FileNameExtensionFilter("PNG Images (*.png)", "png"));
            if (chooser.showSaveDialog(ColorMixingStudio.this) == JFileChooser.APPROVE_OPTION) {
                File f = chooser.getSelectedFile();
                if (!f.getName().toLowerCase().endsWith(".png")) f = new File(f.getAbsolutePath() + ".png");
                try {
                    BufferedImage exportImg = getCompositeCanvasImage();
                    ImageIO.write(exportImg, "png", f);
                    SoundManager.play("save"); // Triple bell chime on saving!
                    JOptionPane.showMessageDialog(ColorMixingStudio.this, "Artwork saved successfully!\n" + f.getAbsolutePath(), "Image Saved", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(ColorMixingStudio.this, "Error saving image: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

        public void applyArtistWatermark(String username) {
            initBufferIfNeeded();
            if (g2d == null) return;
            saveSnapshot();

            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;

            int pillW = 270, pillH = 46;
            int x = Math.max(10, w - pillW - 16);
            int y = Math.max(10, h - pillH - 16);

            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Capsule badge background
            g2d.setColor(new Color(15, 17, 23, 220));
            g2d.fillRoundRect(x, y, pillW, pillH, 14, 14);

            // Border
            g2d.setColor(ACCENT_CYAN);
            g2d.setStroke(new BasicStroke(1.4f));
            g2d.drawRoundRect(x, y, pillW, pillH, 14, 14);

            // Mini Studio Logo on left
            Graphics2D logoG = (Graphics2D) g2d.create(x + 8, y + 7, 32, 32);
            StudioLogo.renderLogo(logoG, 32, 32);
            logoG.dispose();

            // Text
            String dateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy"));
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 12));
            g2d.setColor(ACCENT_GOLD);
            g2d.drawString("Artwork by: " + username, x + 46, y + 20);

            g2d.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            g2d.setColor(new Color(210, 220, 240));
            g2d.drawString("Chill Paint Master \u2022 " + dateStr, x + 46, y + 36);

            recordTimelapseFrame();
            repaint();
            SoundManager.play("chime");
            JOptionPane.showMessageDialog(ColorMixingStudio.this,
                    "Official Artist Watermark & Timestamp stamped at bottom-right corner!\n(Press Ctrl+Z to undo anytime).",
                    "Watermark Stamped", JOptionPane.INFORMATION_MESSAGE);
        }

        public void applyFilter(String filterName) {
            initBufferIfNeeded();
            if (canvasImage == null) return;
            saveSnapshot();
            int w = canvasImage.getWidth(), h = canvasImage.getHeight();
            if (w <= 0 || h <= 0) return;

            if ("8-Bit Retro Pixelate".equals(filterName)) {
                int blockSize = 10;
                for (int y = 0; y < h; y += blockSize) {
                    for (int x = 0; x < w; x += blockSize) {
                        int blockW = Math.min(blockSize, w - x);
                        int blockH = Math.min(blockSize, h - y);
                        long sumR = 0, sumG = 0, sumB = 0, count = 0;
                        for (int by = 0; by < blockH; by++) {
                            for (int bx = 0; bx < blockW; bx++) {
                                int rgb = canvasImage.getRGB(x + bx, y + by);
                                sumR += (rgb >> 16) & 0xFF;
                                sumG += (rgb >> 8) & 0xFF;
                                sumB += rgb & 0xFF;
                                count++;
                            }
                        }
                        if (count == 0) continue;
                        int avgRGB = (0xFF << 24) | ((int)(sumR/count) << 16) | ((int)(sumG/count) << 8) | (int)(sumB/count);
                        for (int by = 0; by < blockH; by++) {
                            for (int bx = 0; bx < blockW; bx++) {
                                canvasImage.setRGB(x + bx, y + by, avgRGB);
                            }
                        }
                    }
                }
            } else if ("Cinematic Vignette".equals(filterName)) {
                double cx = w / 2.0, cy = h / 2.0;
                double maxDist = Math.sqrt(cx * cx + cy * cy);
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        int rgb = canvasImage.getRGB(x, y);
                        int a = (rgb >> 24) & 0xFF;
                        int r = (rgb >> 16) & 0xFF;
                        int g = (rgb >> 8) & 0xFF;
                        int b = rgb & 0xFF;
                        double dist = Math.sqrt((x - cx)*(x - cx) + (y - cy)*(y - cy));
                        double factor = Math.max(0.0, 1.0 - Math.pow(dist / maxDist, 1.8) * 0.75);
                        int nr = Math.min(255, (int)(r * factor));
                        int ng = Math.min(255, (int)(g * factor));
                        int nb = Math.min(255, (int)(b * factor));
                        canvasImage.setRGB(x, y, (a << 24) | (nr << 16) | (ng << 8) | nb);
                    }
                }
            } else if ("Vintage Sepia".equals(filterName)) {
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        int rgb = canvasImage.getRGB(x, y);
                        int a = (rgb >> 24) & 0xFF;
                        int r = (rgb >> 16) & 0xFF;
                        int g = (rgb >> 8) & 0xFF;
                        int b = rgb & 0xFF;
                        int tr = Math.min(255, (int)(0.393 * r + 0.769 * g + 0.189 * b));
                        int tg = Math.min(255, (int)(0.349 * r + 0.686 * g + 0.168 * b));
                        int tb = Math.min(255, (int)(0.272 * r + 0.534 * g + 0.131 * b));
                        canvasImage.setRGB(x, y, (a << 24) | (tr << 16) | (tg << 8) | tb);
                    }
                }
            } else if ("Invert / Negative FX".equals(filterName)) {
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        int rgb = canvasImage.getRGB(x, y);
                        int a = (rgb >> 24) & 0xFF;
                        int r = 255 - ((rgb >> 16) & 0xFF);
                        int g = 255 - ((rgb >> 8) & 0xFF);
                        int b = 255 - (rgb & 0xFF);
                        canvasImage.setRGB(x, y, (a << 24) | (r << 16) | (g << 8) | b);
                    }
                }
            } else if ("Cyberpunk Neon Boost".equals(filterName)) {
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        int rgb = canvasImage.getRGB(x, y);
                        int a = (rgb >> 24) & 0xFF;
                        int r = (rgb >> 16) & 0xFF;
                        int g = (rgb >> 8) & 0xFF;
                        int b = rgb & 0xFF;
                        int nr = Math.min(255, (int)(Math.pow(r / 255.0, 0.8) * 260));
                        int ng = Math.min(255, (int)(g * 0.85));
                        int nb = Math.min(255, (int)(Math.pow(b / 255.0, 0.75) * 270));
                        canvasImage.setRGB(x, y, (a << 24) | (nr << 16) | (ng << 8) | nb);
                    }
                }
            } else if ("Monochrome Grayscale".equals(filterName)) {
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        int rgb = canvasImage.getRGB(x, y);
                        int a = (rgb >> 24) & 0xFF;
                        int r = (rgb >> 16) & 0xFF;
                        int g = (rgb >> 8) & 0xFF;
                        int b = rgb & 0xFF;
                        int gray = (int)(0.299 * r + 0.587 * g + 0.114 * b);
                        canvasImage.setRGB(x, y, (a << 24) | (gray << 16) | (gray << 8) | gray);
                    }
                }
            }
            recordTimelapseFrame();
            repaint();
            SoundManager.play("chime");
        }

        public void extractDominantColors(ColorMixingStudio studio) {
            initBufferIfNeeded();
            if (canvasImage == null) return;
            int w = canvasImage.getWidth(), h = canvasImage.getHeight();
            if (w <= 0 || h <= 0) return;

            Map<Integer, Integer> colorCounts = new HashMap<>();
            int step = Math.max(1, (int) Math.sqrt((w * h) / 3000.0));
            for (int y = 0; y < h; y += step) {
                for (int x = 0; x < w; x += step) {
                    int rgb = canvasImage.getRGB(x, y);
                    int a = (rgb >> 24) & 0xFF;
                    if (a < 120) continue;
                    int r = (rgb >> 16) & 0xFF;
                    int g = (rgb >> 8) & 0xFF;
                    int b = rgb & 0xFF;
                    int qr = (r >> 3) << 3;
                    int qg = (g >> 3) << 3;
                    int qb = (b >> 3) << 3;
                    int key = (qr << 16) | (qg << 8) | qb;
                    colorCounts.put(key, colorCounts.getOrDefault(key, 0) + 1);
                }
            }

            java.util.List<Map.Entry<Integer, Integer>> sorted = new ArrayList<>(colorCounts.entrySet());
            sorted.sort((e1, e2) -> e2.getValue().compareTo(e1.getValue()));

            ArrayList<Color> distinctColors = new ArrayList<>();
            for (Map.Entry<Integer, Integer> entry : sorted) {
                int rgb = entry.getKey();
                Color c = new Color((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF);
                boolean distinct = true;
                for (Color sel : distinctColors) {
                    double dist = Math.sqrt(
                            2 * Math.pow(c.getRed() - sel.getRed(), 2) +
                            4 * Math.pow(c.getGreen() - sel.getGreen(), 2) +
                            3 * Math.pow(c.getBlue() - sel.getBlue(), 2)
                    );
                    if (dist < 40) { distinct = false; break; }
                }
                if (distinct) {
                    distinctColors.add(c);
                    if (distinctColors.size() >= 5) break;
                }
            }

            if (distinctColors.isEmpty()) {
                JOptionPane.showMessageDialog(studio, "No distinct colors found on canvas.", "Palette Extractor", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            for (Color c : distinctColors) {
                if (!studio.savedColors.contains(c)) studio.savedColors.add(0, c);
            }
            studio.updatePalettePanel();
            SoundManager.play("chime");

            DominantColorsDialog dlg = new DominantColorsDialog(studio, distinctColors);
            dlg.setVisible(true);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            initBufferIfNeeded();
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // 1. Draw raster background and freehand marks
            if (canvasImage != null) g2.drawImage(canvasImage, 0, 0, null);

            // 1b. Draw subtle golden radial symmetry guides when Kaleidoscope is active
            if (isKaleidoscope) {
                Graphics2D gK = (Graphics2D) g2.create();
                gK.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                gK.setColor(new Color(255, 215, 0, 45));
                gK.setStroke(new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, new float[]{4.0f, 6.0f}, 0.0f));
                int w = getWidth(), h = getHeight();
                double cx = w / 2.0, cy = h / 2.0;
                double maxDim = Math.hypot(w, h);
                int slices = Math.max(2, kaleidoscopeSlices);
                for (int s = 0; s < slices; s++) {
                    double theta = s * (2.0 * Math.PI / slices);
                    int ex = (int) (cx + maxDim * Math.cos(theta));
                    int ey = (int) (cy + maxDim * Math.sin(theta));
                    gK.drawLine((int) cx, (int) cy, ex, ey);
                }
                gK.drawOval((int) cx - 16, (int) cy - 16, 32, 32);
                gK.drawOval((int) cx - 3, (int) cy - 3, 6, 6);
                gK.dispose();
            }

            // 2. Draw all vector movable shapes
            for (DrawnShape s : shapes) renderShape(g2, s);

            // 3. Highlight currently selected shape with transformation bounds & rotation handle
            if (selectedShape != null && "Select & Move Shape".equals(currentTool)) {
                Graphics2D gSel = (Graphics2D) g2.create();
                Point2D.Double c = selectedShape.getCenter();
                if (Math.abs(selectedShape.rotationAngle) > 0.0001) {
                    gSel.rotate(selectedShape.rotationAngle, c.x, c.y);
                }
                Rectangle b = selectedShape.getBounds();
                gSel.setColor(ACCENT_CYAN);
                gSel.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, new float[]{5.0f, 5.0f}, 0.0f));
                gSel.drawRect(b.x - 2, b.y - 2, b.width + 4, b.height + 4);

                // Small corner drag handles
                gSel.setColor(Color.WHITE);
                gSel.fillRect(b.x - 5, b.y - 5, 6, 6);
                gSel.fillRect(b.x + b.width - 1, b.y - 5, 6, 6);
                gSel.fillRect(b.x - 5, b.y + b.height - 1, 6, 6);
                gSel.fillRect(b.x + b.width - 1, b.y + b.height - 1, 6, 6);
                gSel.setColor(Color.BLACK);
                gSel.setStroke(new BasicStroke(1.0f));
                gSel.drawRect(b.x - 5, b.y - 5, 6, 6);
                gSel.drawRect(b.x + b.width - 1, b.y - 5, 6, 6);
                gSel.drawRect(b.x - 5, b.y + b.height - 1, 6, 6);
                gSel.drawRect(b.x + b.width - 1, b.y + b.height - 1, 6, 6);

                // Stem line connecting top edge to rotation knob
                int centerX = b.x + b.width / 2;
                int stemTopY = b.y - 24;
                gSel.setColor(ACCENT_CYAN);
                gSel.setStroke(new BasicStroke(1.8f));
                gSel.drawLine(centerX, b.y - 2, centerX, stemTopY);

                // Circular Rotation Knob Handle
                gSel.setColor(ACCENT_GOLD);
                gSel.fillOval(centerX - 7, stemTopY - 7, 14, 14);
                gSel.setColor(Color.BLACK);
                gSel.setStroke(new BasicStroke(1.5f));
                gSel.drawOval(centerX - 7, stemTopY - 7, 14, 14);

                // Rotation icon inside knob
                gSel.setColor(Color.BLACK);
                gSel.drawArc(centerX - 4, stemTopY - 4, 8, 8, 45, 270);

                gSel.dispose();
            }

            // 4. Draw interactive preview while dragging a new shape
            if (isDraggingShape && dragStart != null && dragCurrent != null) {
                DrawnShape previewShape = new DrawnShape(currentTool, dragStart.x, dragStart.y, dragCurrent.x, dragCurrent.y,
                        shapeFillColor, shapeBorderColor, shapeStyle, brushSize, brushOpacity, 0.0);
                renderShape(g2, previewShape);
            }

            g2.dispose();
        }
    }

    // =========================================================================
    // INNER CLASS: PersonaIcon (Visible Colorful Vector Avatar Badges)
    // =========================================================================
    public static class PersonaIcon implements Icon {
        private final String type;
        private final int size;

        public PersonaIcon(String type, int size) {
            this.type = type;
            this.size = size;
        }

        @Override public int getIconWidth() { return size; }
        @Override public int getIconHeight() { return size; }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            Color bg;
            if ("Artist".equals(type)) bg = new Color(255, 95, 120);
            else if ("Painter".equals(type)) bg = new Color(50, 190, 255);
            else if ("Master".equals(type)) bg = new Color(255, 205, 50);
            else if ("Design".equals(type)) bg = new Color(175, 90, 255);
            else if ("Studio".equals(type)) bg = new Color(0, 230, 160);
            else bg = new Color(255, 130, 45);

            g2.setColor(bg);
            g2.fillRoundRect(x + 1, y + 1, size - 2, size - 2, 6, 6);
            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

            int cx = x + size / 2, cy = y + size / 2;
            if ("Artist".equals(type)) {
                g2.fillOval(cx - 4, cy - 4, 8, 8);
                g2.setColor(bg);
                g2.fillOval(cx - 2, cy - 2, 4, 4);
            } else if ("Painter".equals(type)) {
                g2.drawLine(x + 4, y + size - 4, x + size - 4, y + 4);
            } else if ("Master".equals(type)) {
                g2.drawPolygon(new int[]{cx - 5, cx - 2, cx, cx + 2, cx + 5, cx + 4, cx - 4},
                        new int[]{cy + 3, cy - 3, cy + 1, cy - 3, cy + 3, cy + 4, cy + 4}, 7);
            } else if ("Design".equals(type)) {
                g2.drawRect(cx - 4, cy - 4, 8, 8);
            } else if ("Studio".equals(type)) {
                g2.drawOval(cx - 5, cy - 5, 10, 10);
                g2.drawLine(cx, cy - 5, cx, cy + 5);
            } else {
                g2.drawLine(cx - 4, cy + 4, cx, cy - 4);
                g2.drawLine(cx, cy - 4, cx + 4, cy + 4);
            }
            g2.dispose();
        }
    }

    // =========================================================================
    // INNER CLASS: StudioLoginDialog (Executive Obsidian Studio Portal)
    // =========================================================================
    public static class StudioLoginDialog extends JDialog {
        public static final String USERS_FILE = "users.txt";
        public static final String REMEMBERED_USER_FILE = "remembered_user.txt";

        private final String[] AVATARS = { "Artist", "Painter", "Master", "Design", "Studio", "Pro" };
        private String selectedAvatar = "Artist";
        private boolean isRegisterMode = false, isPasswordVisible = false;

        private JTextField tfUsername, tfPhone;
        private JPasswordField tfPassword, tfConfirmPassword;
        private JCheckBox cbRememberMe;
        private JProgressBar strengthBar;
        private JLabel lblStrengthText, lblStatus;
        private JButton btnPrimaryAction, btnToggleEye, btnTabSignIn, btnTabRegister, btnForgotPassword;
        private JPanel phoneRow, confirmPassRow, strengthPanel, avatarPanel, forgotRow;
        public String authenticatedUser = null;

        public StudioLoginDialog(Frame owner) {
            super(owner, "Chill Paint Master - Studio Access", true);
            setIconImages(ColorMixingStudio.getAppIconImages());
            ColorMixingStudio.applyTaskbarIcon();
            setSize(490, 710);
            setResizable(false);
            setLocationRelativeTo(owner);
            getContentPane().setBackground(BG_WINDOW);

            initDatabase();
            buildUI();
            loadRememberedUser();
        }

        private void initDatabase() {
            File f = new File(USERS_FILE);
            if (!f.exists()) {
                try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8))) {
                    pw.println("admin,admin123,Artist,9876543210");
                    pw.println("artist,paint123,Painter,9876543210");
                    pw.println("master,studio2026,Master,9876543210");
                } catch (Exception ignored) {}
            }
        }

        private void buildUI() {
            final int FORM_WIDTH = 390;

            JPanel card = new JPanel();
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setBackground(BG_CARD);
            card.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(60, 68, 88), 1, true),
                    new EmptyBorder(16, 20, 16, 20)
            ));

            // 1. Studio Crest Header (Strictly Centered & Prominent)
            JPanel logoWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
            logoWrapper.setOpaque(false);
            logoWrapper.setMaximumSize(new Dimension(FORM_WIDTH, 62));
            logoWrapper.setPreferredSize(new Dimension(FORM_WIDTH, 62));
            logoWrapper.setAlignmentX(Component.CENTER_ALIGNMENT);

            StudioLogo logo = new StudioLogo(60, 60);
            logoWrapper.add(logo);
            card.add(logoWrapper);
            card.add(Box.createVerticalStrut(4));

            JLabel title = new JLabel("CHILL PAINT MASTER", SwingConstants.CENTER);
            title.setFont(new Font("Segoe UI", Font.BOLD, 22));
            title.setForeground(ACCENT_GOLD);
            title.setAlignmentX(Component.CENTER_ALIGNMENT);
            title.setHorizontalAlignment(SwingConstants.CENTER);
            title.setMaximumSize(new Dimension(FORM_WIDTH, 28));

            JLabel subtitle = new JLabel("Interactive Color Mixing & Creative Canvas Studio", SwingConstants.CENTER);
            subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            subtitle.setForeground(TEXT_MUTED);
            subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
            subtitle.setHorizontalAlignment(SwingConstants.CENTER);
            subtitle.setMaximumSize(new Dimension(FORM_WIDTH, 18));

            card.add(title);
            card.add(subtitle);
            card.add(Box.createVerticalStrut(12));

            // 2. Centered Segmented Mode Switcher (Sign In vs Create Account)
            JPanel segmentedNav = new JPanel(new GridLayout(1, 2, 8, 0));
            segmentedNav.setOpaque(false);
            segmentedNav.setMaximumSize(new Dimension(FORM_WIDTH, 36));
            segmentedNav.setPreferredSize(new Dimension(FORM_WIDTH, 36));
            segmentedNav.setAlignmentX(Component.CENTER_ALIGNMENT);

            btnTabSignIn = new JButton("Sign In");
            btnTabRegister = new JButton("Create Account");

            styleSegmentedTab(btnTabSignIn, true);
            styleSegmentedTab(btnTabRegister, false);

            btnTabSignIn.addActionListener(e -> { setDialogMode(false); SoundManager.play("click"); });
            btnTabRegister.addActionListener(e -> { setDialogMode(true); SoundManager.play("click"); });

            segmentedNav.add(btnTabSignIn);
            segmentedNav.add(btnTabRegister);
            card.add(segmentedNav);
            card.add(Box.createVerticalStrut(10));

            // 3. Centered Persona Title (Clean Cyan)
            JLabel lblAv = new JLabel("CHOOSE YOUR ARTIST PERSONA", SwingConstants.CENTER);
            lblAv.setFont(new Font("Segoe UI", Font.BOLD, 11));
            lblAv.setForeground(ACCENT_CYAN);
            lblAv.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblAv.setHorizontalAlignment(SwingConstants.CENTER);
            lblAv.setMaximumSize(new Dimension(FORM_WIDTH, 18));
            card.add(lblAv);
            card.add(Box.createVerticalStrut(6));

            // 4. Centered Persona Selection Grid (2x3 with visible icons & black text)
            avatarPanel = new JPanel(new GridLayout(2, 3, 8, 8));
            avatarPanel.setOpaque(false);
            avatarPanel.setMaximumSize(new Dimension(FORM_WIDTH, 74));
            avatarPanel.setPreferredSize(new Dimension(FORM_WIDTH, 74));
            avatarPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

            ButtonGroup ag = new ButtonGroup();
            for (String av : AVATARS) {
                JToggleButton tb = new JToggleButton(av);
                tb.setUI(new javax.swing.plaf.basic.BasicToggleButtonUI());
                tb.setFont(new Font("Segoe UI", Font.BOLD, 11));
                tb.setBackground(new Color(230, 236, 246));
                tb.setForeground(Color.BLACK);
                tb.setOpaque(true);
                tb.setFocusPainted(false);
                tb.setCursor(new Cursor(Cursor.HAND_CURSOR));
                tb.setIcon(new PersonaIcon(av, 18));
                tb.setBorder(BorderFactory.createLineBorder(new Color(180, 192, 212), 1, true));
                if (av.equals(selectedAvatar)) tb.setSelected(true);
                tb.addActionListener(e -> {
                    selectedAvatar = av;
                    updateAvatarStyles();
                    SoundManager.play("snap");
                });
                ag.add(tb);
                avatarPanel.add(tb);
            }
            card.add(avatarPanel);
            card.add(Box.createVerticalStrut(10));

            // 5. Centered Artist Username
            JLabel lblU = new JLabel("Artist Username", SwingConstants.CENTER);
            lblU.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblU.setForeground(TEXT_LIGHT);
            lblU.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblU.setHorizontalAlignment(SwingConstants.CENTER);
            lblU.setMaximumSize(new Dimension(FORM_WIDTH, 18));

            tfUsername = new JTextField();
            styleTextField(tfUsername);
            tfUsername.setHorizontalAlignment(JTextField.LEFT);
            tfUsername.setAlignmentX(Component.CENTER_ALIGNMENT);
            tfUsername.setMaximumSize(new Dimension(FORM_WIDTH, 34));

            card.add(lblU);
            card.add(Box.createVerticalStrut(3));
            card.add(tfUsername);
            card.add(Box.createVerticalStrut(6));

            // 5b. Centered Mobile Phone Row (Registration Mode)
            phoneRow = new JPanel();
            phoneRow.setLayout(new BoxLayout(phoneRow, BoxLayout.Y_AXIS));
            phoneRow.setOpaque(false);
            phoneRow.setAlignmentX(Component.CENTER_ALIGNMENT);
            phoneRow.setMaximumSize(new Dimension(FORM_WIDTH, 56));
            phoneRow.setVisible(false);

            JLabel lblPhone = new JLabel("Mobile Number (For Password Recovery)", SwingConstants.CENTER);
            lblPhone.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblPhone.setForeground(TEXT_LIGHT);
            lblPhone.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblPhone.setHorizontalAlignment(SwingConstants.CENTER);
            lblPhone.setMaximumSize(new Dimension(FORM_WIDTH, 18));

            tfPhone = new JTextField();
            styleTextField(tfPhone);
            tfPhone.setToolTipText("Enter 10-digit phone number for password recovery");
            tfPhone.setHorizontalAlignment(JTextField.LEFT);
            tfPhone.setAlignmentX(Component.CENTER_ALIGNMENT);
            tfPhone.setMaximumSize(new Dimension(FORM_WIDTH, 34));

            phoneRow.add(lblPhone);
            phoneRow.add(Box.createVerticalStrut(3));
            phoneRow.add(tfPhone);
            card.add(phoneRow);

            // 6. Centered Studio Password
            JLabel lblP = new JLabel("Studio Password", SwingConstants.CENTER);
            lblP.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblP.setForeground(TEXT_LIGHT);
            lblP.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblP.setHorizontalAlignment(SwingConstants.CENTER);
            lblP.setMaximumSize(new Dimension(FORM_WIDTH, 18));

            JPanel passRow = new JPanel(new BorderLayout(6, 0));
            passRow.setOpaque(false);
            passRow.setMaximumSize(new Dimension(FORM_WIDTH, 34));
            passRow.setPreferredSize(new Dimension(FORM_WIDTH, 34));
            passRow.setAlignmentX(Component.CENTER_ALIGNMENT);

            tfPassword = new JPasswordField();
            styleTextField(tfPassword);
            tfPassword.setHorizontalAlignment(JTextField.LEFT);

            btnToggleEye = new JButton("Show");
            btnToggleEye.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            btnToggleEye.setFont(new Font("Segoe UI", Font.BOLD, 11));
            btnToggleEye.setBackground(new Color(225, 232, 245));
            btnToggleEye.setForeground(Color.BLACK);
            btnToggleEye.setOpaque(true);
            btnToggleEye.setFocusPainted(false);
            btnToggleEye.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnToggleEye.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(170, 185, 205), 1, true),
                    new EmptyBorder(4, 10, 4, 10)
            ));
            btnToggleEye.addActionListener(e -> {
                togglePassVisibility();
                SoundManager.play("click");
            });

            passRow.add(tfPassword, BorderLayout.CENTER);
            passRow.add(btnToggleEye, BorderLayout.EAST);
            card.add(lblP);
            card.add(Box.createVerticalStrut(3));
            card.add(passRow);

            // 6b. Forgot Password Row (Sign In Mode)
            forgotRow = new JPanel(new BorderLayout());
            forgotRow.setOpaque(false);
            forgotRow.setAlignmentX(Component.CENTER_ALIGNMENT);
            forgotRow.setMaximumSize(new Dimension(FORM_WIDTH, 22));
            forgotRow.setPreferredSize(new Dimension(FORM_WIDTH, 22));

            btnForgotPassword = new JButton("Forgot Password? Reset via Phone");
            btnForgotPassword.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            btnForgotPassword.setFont(new Font("Segoe UI", Font.BOLD, 11));
            btnForgotPassword.setForeground(ACCENT_CYAN);
            btnForgotPassword.setContentAreaFilled(false);
            btnForgotPassword.setBorderPainted(false);
            btnForgotPassword.setFocusPainted(false);
            btnForgotPassword.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnForgotPassword.setHorizontalAlignment(SwingConstants.RIGHT);
            btnForgotPassword.setToolTipText("Reset your forgotten password using your registered phone number");
            btnForgotPassword.addActionListener(e -> {
                SoundManager.play("click");
                openForgotPasswordDialog();
            });
            forgotRow.add(btnForgotPassword, BorderLayout.EAST);
            card.add(Box.createVerticalStrut(4));
            card.add(forgotRow);

            // 7. Password Strength Indicator (Registration Mode)
            strengthPanel = new JPanel();
            strengthPanel.setLayout(new BoxLayout(strengthPanel, BoxLayout.Y_AXIS));
            strengthPanel.setOpaque(false);
            strengthPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            strengthPanel.setMaximumSize(new Dimension(FORM_WIDTH, 22));
            strengthPanel.setVisible(false);

            strengthBar = new JProgressBar(0, 100);
            strengthBar.setPreferredSize(new Dimension(FORM_WIDTH, 5));
            strengthBar.setMaximumSize(new Dimension(FORM_WIDTH, 5));
            strengthBar.setAlignmentX(Component.CENTER_ALIGNMENT);
            strengthBar.setBorderPainted(false);

            lblStrengthText = new JLabel("Password Strength: None", SwingConstants.CENTER);
            lblStrengthText.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            lblStrengthText.setForeground(TEXT_MUTED);
            lblStrengthText.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblStrengthText.setHorizontalAlignment(SwingConstants.CENTER);
            lblStrengthText.setMaximumSize(new Dimension(FORM_WIDTH, 16));

            tfPassword.addKeyListener(new KeyAdapter() {
                @Override public void keyReleased(KeyEvent e) { updateStrength(); }
            });
            strengthPanel.add(Box.createVerticalStrut(3));
            strengthPanel.add(strengthBar);
            strengthPanel.add(lblStrengthText);
            card.add(strengthPanel);

            // 8. Confirm Password Field (Registration Mode)
            confirmPassRow = new JPanel();
            confirmPassRow.setLayout(new BoxLayout(confirmPassRow, BoxLayout.Y_AXIS));
            confirmPassRow.setOpaque(false);
            confirmPassRow.setAlignmentX(Component.CENTER_ALIGNMENT);
            confirmPassRow.setMaximumSize(new Dimension(FORM_WIDTH, 58));
            confirmPassRow.setVisible(false);

            JLabel lblCp = new JLabel("Confirm Password", SwingConstants.CENTER);
            lblCp.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblCp.setForeground(TEXT_LIGHT);
            lblCp.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblCp.setHorizontalAlignment(SwingConstants.CENTER);
            lblCp.setMaximumSize(new Dimension(FORM_WIDTH, 18));

            tfConfirmPassword = new JPasswordField();
            styleTextField(tfConfirmPassword);
            tfConfirmPassword.setHorizontalAlignment(JTextField.LEFT);
            tfConfirmPassword.setAlignmentX(Component.CENTER_ALIGNMENT);
            tfConfirmPassword.setMaximumSize(new Dimension(FORM_WIDTH, 34));

            confirmPassRow.add(Box.createVerticalStrut(4));
            confirmPassRow.add(lblCp);
            confirmPassRow.add(Box.createVerticalStrut(3));
            confirmPassRow.add(tfConfirmPassword);
            card.add(confirmPassRow);
            card.add(Box.createVerticalStrut(6));

            // 9. Centered Remember Me Checkbox
            JPanel rememberPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
            rememberPanel.setOpaque(false);
            rememberPanel.setMaximumSize(new Dimension(FORM_WIDTH, 26));
            rememberPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

            cbRememberMe = new JCheckBox("Remember My Login on this computer");
            cbRememberMe.setFont(new Font("Segoe UI", Font.BOLD, 12));
            cbRememberMe.setForeground(TEXT_LIGHT);
            cbRememberMe.setOpaque(false);
            cbRememberMe.setFocusPainted(false);
            cbRememberMe.setSelected(true);
            cbRememberMe.addActionListener(e -> SoundManager.play("switch"));
            rememberPanel.add(cbRememberMe);

            card.add(rememberPanel);
            card.add(Box.createVerticalStrut(8));

            // 10. Centered Status Message Banner
            lblStatus = new JLabel("Demo Account: admin / admin123 (Phone: 9876543210)", SwingConstants.CENTER);
            lblStatus.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblStatus.setForeground(ACCENT_GOLD);
            lblStatus.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblStatus.setHorizontalAlignment(SwingConstants.CENTER);
            lblStatus.setMaximumSize(new Dimension(FORM_WIDTH, 18));
            card.add(lblStatus);
            card.add(Box.createVerticalStrut(10));

            // 11. Centered Primary Action Button (Gold with Black Text)
            btnPrimaryAction = createDlgButton("Sign In to Studio", ACCENT_GOLD, Color.BLACK);
            btnPrimaryAction.setMaximumSize(new Dimension(FORM_WIDTH, 40));
            btnPrimaryAction.setPreferredSize(new Dimension(FORM_WIDTH, 40));
            btnPrimaryAction.setFont(new Font("Segoe UI", Font.BOLD, 14));
            btnPrimaryAction.setAlignmentX(Component.CENTER_ALIGNMENT);
            btnPrimaryAction.addActionListener(e -> handleSubmit());
            card.add(btnPrimaryAction);
            card.add(Box.createVerticalStrut(8));

            // 12. Centered Continue as Guest Button (Cyan with Black Text)
            JButton btnGuest = createDlgButton("Continue as Guest Artist", ACCENT_CYAN, Color.BLACK);
            btnGuest.setFont(new Font("Segoe UI", Font.BOLD, 12));
            btnGuest.setMaximumSize(new Dimension(FORM_WIDTH, 36));
            btnGuest.setPreferredSize(new Dimension(FORM_WIDTH, 36));
            btnGuest.setAlignmentX(Component.CENTER_ALIGNMENT);
            btnGuest.addActionListener(e -> {
                authenticatedUser = "Guest (" + selectedAvatar + ")";
                SoundManager.play("login");
                dispose();
            });
            card.add(btnGuest);

            // Centered Wrapper for Card
            JPanel wrapper = new JPanel(new GridBagLayout());
            wrapper.setBackground(BG_WINDOW);
            wrapper.add(card);
            setContentPane(wrapper);

            updateAvatarStyles();
        }

        private void setDialogMode(boolean register) {
            this.isRegisterMode = register;
            styleSegmentedTab(btnTabSignIn, !register);
            styleSegmentedTab(btnTabRegister, register);
            phoneRow.setVisible(register);
            confirmPassRow.setVisible(register);
            strengthPanel.setVisible(register);
            forgotRow.setVisible(!register);
            btnPrimaryAction.setText(register ? "Create Account & Enter" : "Sign In to Studio");
            lblStatus.setText(register ? "Enter credentials & 10-digit mobile number" : "Demo Account: admin / admin123 (Phone: 9876543210)");
            lblStatus.setForeground(ACCENT_GOLD);
            revalidate();
            repaint();
        }

        private void styleSegmentedTab(JButton btn, boolean active) {
            btn.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
            btn.setFocusPainted(false);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.setOpaque(true);
            if (active) {
                btn.setBackground(new Color(235, 240, 252));
                btn.setForeground(Color.BLACK);
                btn.setBorder(BorderFactory.createCompoundBorder(
                        new LineBorder(ACCENT_CYAN, 2, true),
                        new EmptyBorder(6, 12, 6, 12)
                ));
            } else {
                btn.setBackground(new Color(36, 42, 58));
                btn.setForeground(new Color(175, 185, 205));
                btn.setBorder(BorderFactory.createCompoundBorder(
                        new LineBorder(CARD_BORDER, 1, true),
                        new EmptyBorder(6, 12, 6, 12)
                ));
            }
        }

        private void styleTextField(JTextField tf) {
            tf.setBackground(BG_INPUT);
            tf.setForeground(Color.WHITE);
            tf.setCaretColor(ACCENT_CYAN);
            tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            tf.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(55, 65, 88), 1, true),
                    new EmptyBorder(6, 10, 6, 10)
            ));
        }

        private JButton createDlgButton(String text, Color bg, Color fg) {
            JButton b = new JButton(text);
            b.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            b.setBackground(bg);
            b.setForeground(fg);
            b.setOpaque(true);
            b.setFocusPainted(false);
            b.setCursor(new Cursor(Cursor.HAND_CURSOR));
            b.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(40, 45, 60), 1, true),
                    new EmptyBorder(6, 14, 6, 14)
            ));
            return b;
        }

        private void togglePassVisibility() {
            isPasswordVisible = !isPasswordVisible;
            tfPassword.setEchoChar(isPasswordVisible ? (char) 0 : '•');
            tfConfirmPassword.setEchoChar(isPasswordVisible ? (char) 0 : '•');
            btnToggleEye.setText(isPasswordVisible ? "Hide" : "Show");
            btnToggleEye.setBackground(isPasswordVisible ? new Color(255, 215, 140) : new Color(225, 232, 245));
        }

        private void updateAvatarStyles() {
            if (avatarPanel == null) return;
            for (Component c : avatarPanel.getComponents()) {
                if (c instanceof JToggleButton) {
                    JToggleButton b = (JToggleButton) c;
                    boolean sel = b.getText().equals(selectedAvatar);
                    b.setBackground(sel ? new Color(255, 235, 150) : new Color(230, 236, 246));
                    b.setBorder(BorderFactory.createCompoundBorder(
                            new LineBorder(sel ? ACCENT_GOLD : new Color(180, 192, 212), sel ? 2 : 1, true),
                            new EmptyBorder(4, 6, 4, 6)
                    ));
                }
            }
        }

        private void updateStrength() {
            String p = new String(tfPassword.getPassword());
            int score = 0;
            if (p.length() >= 6) score += 25;
            if (p.length() >= 9) score += 25;
            if (p.matches(".*[A-Z].*")) score += 20;
            if (p.matches(".*[0-9].*")) score += 15;
            if (p.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*")) score += 15;

            strengthBar.setValue(score);
            if (score < 40) {
                strengthBar.setForeground(new Color(255, 90, 90));
                lblStrengthText.setText("Password Strength: Weak");
                lblStrengthText.setForeground(new Color(255, 120, 120));
            } else if (score < 75) {
                strengthBar.setForeground(new Color(255, 195, 45));
                lblStrengthText.setText("Password Strength: Moderate");
                lblStrengthText.setForeground(new Color(255, 210, 110));
            } else {
                strengthBar.setForeground(new Color(60, 235, 130));
                lblStrengthText.setText("Password Strength: Strong & Secure");
                lblStrengthText.setForeground(new Color(90, 245, 150));
            }
        }

        private void handleSubmit() {
            String u = tfUsername.getText().trim();
            String p = new String(tfPassword.getPassword());

            if (u.isEmpty() || p.isEmpty()) {
                lblStatus.setText("Please fill in all fields.");
                lblStatus.setForeground(new Color(255, 100, 100));
                SoundManager.play("click");
                return;
            }

            if (isRegisterMode) {
                String cp = new String(tfConfirmPassword.getPassword());
                String ph = tfPhone.getText().trim();
                String cleanPhone = ph.replaceAll("[^0-9]", "");

                if (u.length() < 3 || p.length() < 4) {
                    lblStatus.setText("Username >= 3 & Password >= 4 chars required.");
                    lblStatus.setForeground(new Color(255, 100, 100));
                    SoundManager.play("click");
                    return;
                }
                if (cleanPhone.length() < 10) {
                    lblStatus.setText("Valid 10-digit mobile number required.");
                    lblStatus.setForeground(new Color(255, 100, 100));
                    SoundManager.play("click");
                    return;
                }
                if (!p.equals(cp)) {
                    lblStatus.setText("Passwords do not match.");
                    lblStatus.setForeground(new Color(255, 100, 100));
                    SoundManager.play("click");
                    return;
                }
                if (findUser(u) != null) {
                    lblStatus.setText("Username is already taken.");
                    lblStatus.setForeground(new Color(255, 100, 100));
                    SoundManager.play("click");
                    return;
                }

                saveUser(u, p, selectedAvatar, cleanPhone);
                lblStatus.setText("Account created! Please Sign In.");
                lblStatus.setForeground(new Color(90, 240, 120));
                SoundManager.play("login");
                setDialogMode(false);
                tfUsername.setText(u);
                tfPassword.setText(p);
            } else {
                String rec = findUser(u);
                if (rec != null) {
                    String[] parts = parseUserRecord(rec);
                    if (parts[1].equals(p)) {
                        authenticatedUser = u;
                        if (cbRememberMe.isSelected()) saveRemembered(u, parts[2]);
                        else clearRemembered();
                        SoundManager.play("login");
                        dispose();
                        return;
                    }
                }
                lblStatus.setText("Invalid username or password.");
                lblStatus.setForeground(new Color(255, 100, 100));
                SoundManager.play("click");
            }
        }

        public static String[] parseUserRecord(String record) {
            if (record == null) return null;
            String[] parts = record.split(",");
            String u = parts.length > 0 ? parts[0].trim() : "";
            String p = parts.length > 1 ? parts[1].trim() : "";
            String av = parts.length > 2 ? parts[2].trim() : "Artist";
            String ph = parts.length > 3 ? parts[3].trim() : "9876543210";
            return new String[]{ u, p, av, ph };
        }

        public static String findUser(String username) {
            File f = new File(USERS_FILE);
            if (!f.exists()) return null;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    String[] parts = line.split(",");
                    if (parts.length >= 2 && parts[0].trim().equalsIgnoreCase(username.trim())) return line;
                }
            } catch (Exception ignored) {}
            return null;
        }

        public static void saveUser(String u, String p, String av, String ph) {
            try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(USERS_FILE, true), StandardCharsets.UTF_8))) {
                pw.println(u + "," + p + "," + av + "," + ph);
            } catch (Exception ignored) {}
        }

        public static boolean updateUserPassword(String username, String newPassword) {
            File f = new File(USERS_FILE);
            if (!f.exists()) return false;
            ArrayList<String> lines = new ArrayList<>();
            boolean updated = false;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    String[] parts = line.split(",");
                    if (parts.length >= 2 && parts[0].trim().equalsIgnoreCase(username.trim())) {
                        String av = parts.length > 2 ? parts[2].trim() : "Artist";
                        String ph = parts.length > 3 ? parts[3].trim() : "9876543210";
                        lines.add(parts[0].trim() + "," + newPassword + "," + av + "," + ph);
                        updated = true;
                    } else {
                        lines.add(line);
                    }
                }
            } catch (Exception e) {
                return false;
            }
            if (!updated) return false;
            try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f, false), StandardCharsets.UTF_8))) {
                for (String l : lines) pw.println(l);
            } catch (Exception e) {
                return false;
            }
            return true;
        }

        public static boolean checkPhoneMatch(String registeredPhone, String enteredPhone) {
            if (registeredPhone == null || enteredPhone == null) return false;
            String regDigits = registeredPhone.replaceAll("[^0-9]", "");
            String entDigits = enteredPhone.replaceAll("[^0-9]", "");
            if (regDigits.isEmpty() || entDigits.isEmpty()) return false;
            if (regDigits.equals(entDigits)) return true;
            if (regDigits.length() >= 10 && entDigits.length() >= 10) {
                String reg10 = regDigits.substring(regDigits.length() - 10);
                String ent10 = entDigits.substring(entDigits.length() - 10);
                return reg10.equals(ent10);
            }
            return false;
        }

        private void openForgotPasswordDialog() {
            String initialUser = tfUsername.getText().trim();
            StudioForgotPasswordDialog dlg = new StudioForgotPasswordDialog(this, initialUser);
            dlg.setVisible(true);
            if (dlg.wasResetSuccessful()) {
                tfUsername.setText(dlg.getResetUsername());
                tfPassword.setText(dlg.getResetPassword());
                lblStatus.setText("Password reset successfully! Click Sign In.");
                lblStatus.setForeground(new Color(90, 240, 120));
            }
        }

        private void loadRememberedUser() {
            File f = new File(REMEMBERED_USER_FILE);
            if (!f.exists()) return;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line = br.readLine();
                if (line != null && !line.trim().isEmpty()) {
                    String[] parts = line.split(",");
                    if (parts.length >= 1) tfUsername.setText(parts[0]);
                    if (parts.length >= 2) {
                        selectedAvatar = parts[1];
                        updateAvatarStyles();
                    }
                    cbRememberMe.setSelected(true);
                }
            } catch (Exception ignored) {}
        }

        private void saveRemembered(String u, String av) {
            try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(REMEMBERED_USER_FILE), StandardCharsets.UTF_8))) {
                pw.println(u + "," + av);
            } catch (Exception ignored) {}
        }

        private void clearRemembered() {
            File f = new File(REMEMBERED_USER_FILE);
            if (f.exists()) f.delete();
        }
    }

    // =========================================================================
    // INNER CLASS: StudioForgotPasswordDialog (Phone-Based Password Reset)
    // =========================================================================
    public static class StudioForgotPasswordDialog extends JDialog {
        private final JTextField tfResetUser;
        private final JTextField tfResetPhone;
        private final JPasswordField tfNewPass;
        private final JPasswordField tfConfirmNewPass;
        private final JLabel lblStatus;
        private boolean resetSuccess = false;
        private String resetUsername = "";
        private String resetPassword = "";

        public StudioForgotPasswordDialog(Dialog owner, String initialUser) {
            super(owner, "Chill Paint Master - Password Recovery", true);
            setIconImages(ColorMixingStudio.getAppIconImages());
            ColorMixingStudio.applyTaskbarIcon();
            setSize(470, 560);
            setResizable(false);
            setLocationRelativeTo(owner);
            getContentPane().setBackground(BG_WINDOW);

            final int FORM_WIDTH = 380;
            JPanel card = new JPanel();
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setBackground(BG_CARD);
            card.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(60, 68, 88), 1, true),
                    new EmptyBorder(16, 22, 16, 22)
            ));

            // Header Logo
            JPanel logoWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
            logoWrapper.setOpaque(false);
            logoWrapper.setMaximumSize(new Dimension(FORM_WIDTH, 48));
            StudioLogo logo = new StudioLogo(46, 46);
            logoWrapper.add(logo);
            card.add(logoWrapper);
            card.add(Box.createVerticalStrut(4));

            JLabel title = new JLabel("FORGOT PASSWORD RECOVERY", SwingConstants.CENTER);
            title.setFont(new Font("Segoe UI", Font.BOLD, 18));
            title.setForeground(ACCENT_GOLD);
            title.setAlignmentX(Component.CENTER_ALIGNMENT);
            title.setMaximumSize(new Dimension(FORM_WIDTH, 24));
            card.add(title);

            JLabel subtitle = new JLabel("Verify registered mobile number to reset password", SwingConstants.CENTER);
            subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            subtitle.setForeground(TEXT_MUTED);
            subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
            subtitle.setMaximumSize(new Dimension(FORM_WIDTH, 18));
            card.add(subtitle);
            card.add(Box.createVerticalStrut(14));

            // 1. Username
            JLabel lblU = new JLabel("Artist Username", SwingConstants.LEFT);
            lblU.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblU.setForeground(TEXT_LIGHT);
            lblU.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblU.setMaximumSize(new Dimension(FORM_WIDTH, 18));
            tfResetUser = new JTextField(initialUser != null ? initialUser : "");
            styleField(tfResetUser);
            tfResetUser.setAlignmentX(Component.CENTER_ALIGNMENT);
            tfResetUser.setMaximumSize(new Dimension(FORM_WIDTH, 34));
            card.add(lblU);
            card.add(Box.createVerticalStrut(3));
            card.add(tfResetUser);
            card.add(Box.createVerticalStrut(8));

            // 2. Phone Number
            JLabel lblP = new JLabel("Registered Mobile Number (10 Digits)", SwingConstants.LEFT);
            lblP.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblP.setForeground(TEXT_LIGHT);
            lblP.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblP.setMaximumSize(new Dimension(FORM_WIDTH, 18));
            tfResetPhone = new JTextField();
            styleField(tfResetPhone);
            tfResetPhone.setToolTipText("Enter 10-digit phone registered with this account");
            tfResetPhone.setAlignmentX(Component.CENTER_ALIGNMENT);
            tfResetPhone.setMaximumSize(new Dimension(FORM_WIDTH, 34));
            card.add(lblP);
            card.add(Box.createVerticalStrut(3));
            card.add(tfResetPhone);
            card.add(Box.createVerticalStrut(8));

            // 3. New Password
            JLabel lblNp = new JLabel("New Password", SwingConstants.LEFT);
            lblNp.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblNp.setForeground(TEXT_LIGHT);
            lblNp.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblNp.setMaximumSize(new Dimension(FORM_WIDTH, 18));
            tfNewPass = new JPasswordField();
            styleField(tfNewPass);
            tfNewPass.setAlignmentX(Component.CENTER_ALIGNMENT);
            tfNewPass.setMaximumSize(new Dimension(FORM_WIDTH, 34));
            card.add(lblNp);
            card.add(Box.createVerticalStrut(3));
            card.add(tfNewPass);
            card.add(Box.createVerticalStrut(8));

            // 4. Confirm Password
            JLabel lblCnp = new JLabel("Confirm New Password", SwingConstants.LEFT);
            lblCnp.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblCnp.setForeground(TEXT_LIGHT);
            lblCnp.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblCnp.setMaximumSize(new Dimension(FORM_WIDTH, 18));
            tfConfirmNewPass = new JPasswordField();
            styleField(tfConfirmNewPass);
            tfConfirmNewPass.setAlignmentX(Component.CENTER_ALIGNMENT);
            tfConfirmNewPass.setMaximumSize(new Dimension(FORM_WIDTH, 34));
            card.add(lblCnp);
            card.add(Box.createVerticalStrut(3));
            card.add(tfConfirmNewPass);
            card.add(Box.createVerticalStrut(8));

            // Hint / Status Label
            lblStatus = new JLabel("Demo Accounts (admin/artist) Phone: 9876543210", SwingConstants.CENTER);
            lblStatus.setFont(new Font("Segoe UI", Font.BOLD, 11));
            lblStatus.setForeground(ACCENT_GOLD);
            lblStatus.setAlignmentX(Component.CENTER_ALIGNMENT);
            lblStatus.setMaximumSize(new Dimension(FORM_WIDTH, 20));
            card.add(lblStatus);
            card.add(Box.createVerticalStrut(10));

            // Reset Button
            JButton btnReset = new JButton("Verify Mobile & Reset Password");
            btnReset.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            btnReset.setBackground(ACCENT_GOLD);
            btnReset.setForeground(Color.BLACK);
            btnReset.setFont(new Font("Segoe UI", Font.BOLD, 13));
            btnReset.setOpaque(true);
            btnReset.setFocusPainted(false);
            btnReset.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnReset.setAlignmentX(Component.CENTER_ALIGNMENT);
            btnReset.setMaximumSize(new Dimension(FORM_WIDTH, 38));
            btnReset.setPreferredSize(new Dimension(FORM_WIDTH, 38));
            btnReset.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(40, 45, 60), 1, true),
                    new EmptyBorder(6, 14, 6, 14)
            ));
            btnReset.addActionListener(e -> handleReset());
            card.add(btnReset);
            card.add(Box.createVerticalStrut(8));

            // Cancel Button
            JButton btnCancel = new JButton("Back to Sign In");
            btnCancel.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            btnCancel.setBackground(new Color(38, 44, 60));
            btnCancel.setForeground(TEXT_LIGHT);
            btnCancel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            btnCancel.setOpaque(true);
            btnCancel.setFocusPainted(false);
            btnCancel.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnCancel.setAlignmentX(Component.CENTER_ALIGNMENT);
            btnCancel.setMaximumSize(new Dimension(FORM_WIDTH, 32));
            btnCancel.setPreferredSize(new Dimension(FORM_WIDTH, 32));
            btnCancel.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(CARD_BORDER, 1, true),
                    new EmptyBorder(4, 10, 4, 10)
            ));
            btnCancel.addActionListener(e -> dispose());
            card.add(btnCancel);

            JPanel wrapper = new JPanel(new GridBagLayout());
            wrapper.setBackground(BG_WINDOW);
            wrapper.add(card);
            setContentPane(wrapper);
        }

        private void styleField(JTextField tf) {
            tf.setBackground(BG_INPUT);
            tf.setForeground(Color.WHITE);
            tf.setCaretColor(ACCENT_CYAN);
            tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            tf.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(55, 65, 88), 1, true),
                    new EmptyBorder(5, 10, 5, 10)
            ));
        }

        private void handleReset() {
            String u = tfResetUser.getText().trim();
            String ph = tfResetPhone.getText().trim();
            String p1 = new String(tfNewPass.getPassword());
            String p2 = new String(tfConfirmNewPass.getPassword());

            if (u.isEmpty() || ph.isEmpty() || p1.isEmpty() || p2.isEmpty()) {
                lblStatus.setText("Please fill in all recovery fields.");
                lblStatus.setForeground(new Color(255, 100, 100));
                SoundManager.play("click");
                return;
            }

            String rec = StudioLoginDialog.findUser(u);
            if (rec == null) {
                lblStatus.setText("Artist username '" + u + "' not found.");
                lblStatus.setForeground(new Color(255, 100, 100));
                SoundManager.play("click");
                return;
            }

            String[] parts = StudioLoginDialog.parseUserRecord(rec);
            String regPhone = parts[3];

            if (!StudioLoginDialog.checkPhoneMatch(regPhone, ph)) {
                lblStatus.setText("Phone number does not match registered records!");
                lblStatus.setForeground(new Color(255, 100, 100));
                SoundManager.play("click");
                return;
            }

            if (p1.length() < 4) {
                lblStatus.setText("New password must be at least 4 characters.");
                lblStatus.setForeground(new Color(255, 100, 100));
                SoundManager.play("click");
                return;
            }

            if (!p1.equals(p2)) {
                lblStatus.setText("New passwords do not match.");
                lblStatus.setForeground(new Color(255, 100, 100));
                SoundManager.play("click");
                return;
            }

            boolean ok = StudioLoginDialog.updateUserPassword(u, p1);
            if (ok) {
                SoundManager.play("login");
                resetSuccess = true;
                resetUsername = u;
                resetPassword = p1;
                JOptionPane.showMessageDialog(this,
                        "Password for artist '" + u + "' successfully reset!\nYou can now sign in with your new password.",
                        "Password Reset Verified",
                        JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                lblStatus.setText("Failed to update password. Try again.");
                lblStatus.setForeground(new Color(255, 100, 100));
                SoundManager.play("click");
            }
        }

        public boolean wasResetSuccessful() { return resetSuccess; }
        public String getResetUsername() { return resetUsername; }
        public String getResetPassword() { return resetPassword; }
    }

    // =========================================================================
    // INNER CLASS: MagicArtGeneratorDialog (Procedural Mathematical Art Engine)
    // =========================================================================

    public static class MagicArtGeneratorDialog extends JDialog {
        private final PaintCanvas canvas;
        private final JComboBox<String> cbStyles;
        private final JTextArea txtFormula;

        private static final String[] STYLES = {
            "Sacred Rosette Mandala",
            "Galactic Fibonacci Spiral",
            "Harmonic Fourier Spirograph",
            "Cosmic Aurora Wave Symphony"
        };

        public MagicArtGeneratorDialog(JFrame parent, PaintCanvas canvas) {
            super(parent, "Procedural Mathematical Art Studio (Algorithmic Generator)", true);
            this.canvas = canvas;
            applyTaskbarIcon();
            setSize(660, 530);
            setLocationRelativeTo(parent);
            setResizable(false);

            JPanel root = new JPanel(new BorderLayout(15, 15));
            root.setBackground(BG_CARD);
            root.setBorder(new EmptyBorder(20, 24, 20, 24));

            // Header Banner
            JPanel pnlHeader = new JPanel(new BorderLayout(5, 5));
            pnlHeader.setBackground(BG_CARD);
            JLabel lblTitle = new JLabel("Procedural Mathematical Canvas Generator");
            lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
            lblTitle.setForeground(ACCENT_GOLD);
            JLabel lblSubtitle = new JLabel("Renders live algorithmic masterpieces mapped dynamically to your mixed colors.");
            lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            lblSubtitle.setForeground(TEXT_MUTED);
            pnlHeader.add(lblTitle, BorderLayout.NORTH);
            pnlHeader.add(lblSubtitle, BorderLayout.SOUTH);
            root.add(pnlHeader, BorderLayout.NORTH);

            // Center: Style Selector & Math Formula Explanation
            JPanel pnlCenter = new JPanel(new BorderLayout(12, 12));
            pnlCenter.setBackground(BG_CARD);

            JPanel pnlSelect = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
            pnlSelect.setBackground(BG_CARD);
            JLabel lblPrompt = new JLabel("Select Algorithm:");
            lblPrompt.setFont(new Font("Segoe UI", Font.BOLD, 13));
            lblPrompt.setForeground(TEXT_LIGHT);
            cbStyles = new JComboBox<>(STYLES);
            cbStyles.setUI(new javax.swing.plaf.basic.BasicComboBoxUI() {
                @Override
                protected JButton createArrowButton() {
                    JButton btn = super.createArrowButton();
                    btn.setBackground(Color.WHITE);
                    btn.setBorder(BorderFactory.createEmptyBorder());
                    return btn;
                }
            });
            cbStyles.setBackground(Color.WHITE);
            cbStyles.setForeground(Color.BLACK);
            cbStyles.setOpaque(true);
            cbStyles.setFont(new Font("Segoe UI", Font.BOLD, 12));
            cbStyles.setRenderer(createBlackTextRenderer());
            cbStyles.setPreferredSize(new Dimension(300, 34));
            cbStyles.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(180, 190, 210), 1, true),
                    new EmptyBorder(2, 6, 2, 6)
            ));
            pnlSelect.add(lblPrompt);
            pnlSelect.add(cbStyles);
            pnlCenter.add(pnlSelect, BorderLayout.NORTH);

            txtFormula = new JTextArea();
            txtFormula.setEditable(false);
            txtFormula.setFont(new Font("Consolas", Font.PLAIN, 12));
            txtFormula.setBackground(BG_INPUT);
            txtFormula.setForeground(ACCENT_CYAN);
            txtFormula.setLineWrap(true);
            txtFormula.setWrapStyleWord(true);
            txtFormula.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(CARD_BORDER, 1),
                    new EmptyBorder(12, 12, 12, 12)
            ));
            JScrollPane spFormula = new JScrollPane(txtFormula);
            spFormula.setBorder(null);
            pnlCenter.add(spFormula, BorderLayout.CENTER);

            root.add(pnlCenter, BorderLayout.CENTER);

            // Bottom Buttons
            JPanel pnlButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
            pnlButtons.setBackground(BG_CARD);

            JButton btnGenerate = new JButton("Render On Canvas");
            btnGenerate.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            btnGenerate.setFont(new Font("Segoe UI", Font.BOLD, 13));
            btnGenerate.setBackground(Color.WHITE);
            btnGenerate.setForeground(Color.BLACK);
            btnGenerate.setOpaque(true);
            btnGenerate.setFocusPainted(false);
            btnGenerate.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnGenerate.setPreferredSize(new Dimension(175, 36));
            btnGenerate.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(180, 190, 210), 1, true),
                    new EmptyBorder(6, 12, 6, 12)
            ));

            JButton btnClose = new JButton("Close");
            btnClose.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            btnClose.setFont(new Font("Segoe UI", Font.BOLD, 13));
            btnClose.setBackground(Color.WHITE);
            btnClose.setForeground(Color.BLACK);
            btnClose.setOpaque(true);
            btnClose.setFocusPainted(false);
            btnClose.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnClose.setPreferredSize(new Dimension(90, 36));
            btnClose.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(180, 190, 210), 1, true),
                    new EmptyBorder(6, 12, 6, 12)
            ));

            pnlButtons.add(btnGenerate);
            pnlButtons.add(btnClose);
            root.add(pnlButtons, BorderLayout.SOUTH);

            // Event Handlers
            cbStyles.addActionListener(e -> updateFormulaExplanation());
            updateFormulaExplanation();

            btnGenerate.addActionListener(e -> {
                String style = (String) cbStyles.getSelectedItem();
                if (canvas != null && style != null) {
                    canvas.generateProceduralArt(style);
                }
                SoundManager.play("chime");
                dispose();
            });

            btnClose.addActionListener(e -> dispose());

            setContentPane(root);
        }

        private void updateFormulaExplanation() {
            String selected = (String) cbStyles.getSelectedItem();
            if (selected == null) return;
            StringBuilder sb = new StringBuilder();
            if (selected.contains("Mandala")) {
                sb.append("ALGORITHM: SACRED ROSETTE MANDALA\n");
                sb.append("--------------------------------------------------\n");
                sb.append("Mathematics: Multi-Harmonic Polar Trigonometry\n");
                sb.append("Formula: r(\u03b8) = R_max \u00d7 [0.35 + 0.35\u00b7cos(7\u03b8/L) + 0.30\u00b7sin(11\u03b8/L)]\n");
                sb.append("Coordinates: x = c_x + r\u00b7cos(\u03b8), y = c_y + r\u00b7sin(\u03b8)\n\n");
                sb.append("Properties:\n");
                sb.append("\u2022 3,600 parametric sample points interpolated across 12 harmonic loops.\n");
                sb.append("\u2022 Concentric sacred geometric aura rings with golden ratio distribution.\n");
                sb.append("\u2022 Continuous color-lerp mapping between Primary, Mix, and Secondary tones.");
            } else if (selected.contains("Fibonacci")) {
                sb.append("ALGORITHM: GALACTIC FIBONACCI SPIRAL\n");
                sb.append("--------------------------------------------------\n");
                sb.append("Mathematics: Vogel's Golden Angle Phyllotaxis Spiral\n");
                sb.append("Golden Angle: \u03c6 = 137.50776405\u00b0 (\u03c0 \u00d7 (3 - \u221a5))\n");
                sb.append("Formula: r = c \u00d7 \u221an,  \u03b8 = n \u00d7 \u03c6\n");
                sb.append("Coordinates: x = c_x + r\u00b7cos(\u03b8), y = c_y + r\u00b7sin(\u03b8)\n\n");
                sb.append("Properties:\n");
                sb.append("\u2022 Simulates optimal biological phyllotaxis (sunflowers, galaxy arms).\n");
                sb.append("\u2022 1,200 particle nodes rendered with dual-pass alpha glow auras.\n");
                sb.append("\u2022 Color gradients mapped from mixed color core to golden starlight.");
            } else if (selected.contains("Fourier")) {
                sb.append("ALGORITHM: HARMONIC FOURIER SPIROGRAPH\n");
                sb.append("--------------------------------------------------\n");
                sb.append("Mathematics: 3-Frequency Epicycloid Parametric Curve\n");
                sb.append("Formula: x(t) = c_x + R1\u00b7cos(t) + R2\u00b7cos(-5t) + R3\u00b7cos(9t)\n");
                sb.append("         y(t) = c_y + R1\u00b7sin(t) + R2\u00b7sin(-5t) + R3\u00b7sin(9t)\n\n");
                sb.append("Properties:\n");
                sb.append("\u2022 4,000 continuous line vectors simulating orbiting geometric gears.\n");
                sb.append("\u2022 Higher-order Fourier frequency ratios produce intricate symmetry.\n");
                sb.append("\u2022 Cyan-infused dynamic luminescence across full angular progression.");
            } else {
                sb.append("ALGORITHM: COSMIC AURORA WAVE SYMPHONY\n");
                sb.append("--------------------------------------------------\n");
                sb.append("Mathematics: Interlaced Harmonic Sinusoidal Wave Packets\n");
                sb.append("Formula: y(x) = c_y + \u0394y + \u03a3 [A_k \u00b7 sin(\u03c9_k\u00b7x + \u03d5_k)]\n");
                sb.append("Frequencies: 4\u03c0 (fundamental), 7\u03c0 (harmonic 1), 11\u03c0 (harmonic 2)\n\n");
                sb.append("Properties:\n");
                sb.append("\u2022 22 multi-phase translucent ribbon waves with progressive depth.\n");
                sb.append("\u2022 Simulates solar wind aurora borealis ion atmospheric ionization.\n");
                sb.append("\u2022 Rich tri-color blend interpolating smoothly from Color 1 to Color 2.");
            }
            txtFormula.setText(sb.toString());
            txtFormula.setCaretPosition(0);
        }
    }

    // =========================================================================
    // INNER CLASS: ColorTheoryLabDialog (WCAG 2.1 & Color Vision Science Lab)
    // =========================================================================

    public static class ColorTheoryLabDialog extends JDialog {
        private final Color c1, c2, cMix;
        private final double lum1, lum2, lumMix;
        private final double contrastWhite, contrastBlack;
        private final Color protanopiaMix, deuteranopiaMix, tritanopiaMix;

        public ColorTheoryLabDialog(JFrame parent, Color c1, Color c2, Color cMix) {
            super(parent, "Scientific Color Theory & WCAG 2.1 Accessibility Lab", true);
            this.c1 = c1;
            this.c2 = c2;
            this.cMix = cMix;

            applyTaskbarIcon();
            setSize(780, 680);
            setLocationRelativeTo(parent);
            setResizable(false);

            // Calculations
            lum1 = calculateLuminance(c1);
            lum2 = calculateLuminance(c2);
            lumMix = calculateLuminance(cMix);

            contrastWhite = calculateContrast(lumMix, 1.0); // White L = 1.0
            contrastBlack = calculateContrast(lumMix, 0.0); // Black L = 0.0

            protanopiaMix = simulateProtanopia(cMix);
            deuteranopiaMix = simulateDeuteranopia(cMix);
            tritanopiaMix = simulateTritanopia(cMix);

            JPanel root = new JPanel(new BorderLayout(14, 14));
            root.setBackground(BG_CARD);
            root.setBorder(new EmptyBorder(20, 24, 20, 24));

            // Header Banner
            JPanel pnlHeader = new JPanel(new BorderLayout(4, 4));
            pnlHeader.setBackground(BG_CARD);
            JLabel lblTitle = new JLabel("Scientific Color Metrics & WCAG Accessibility Audit");
            lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
            lblTitle.setForeground(ACCENT_CYAN);
            JLabel lblSubtitle = new JLabel("Academic spectrophotometric luminance, WCAG 2.1 contrast formulas, and CVD simulations.");
            lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            lblSubtitle.setForeground(TEXT_MUTED);
            pnlHeader.add(lblTitle, BorderLayout.NORTH);
            pnlHeader.add(lblSubtitle, BorderLayout.SOUTH);
            root.add(pnlHeader, BorderLayout.NORTH);

            // Main Content Panel (3 cards)
            JPanel pnlBody = new JPanel();
            pnlBody.setLayout(new BoxLayout(pnlBody, BoxLayout.Y_AXIS));
            pnlBody.setBackground(BG_CARD);

            pnlBody.add(createMetricsCard());
            pnlBody.add(Box.createVerticalStrut(12));
            pnlBody.add(createWcagCard());
            pnlBody.add(Box.createVerticalStrut(12));
            pnlBody.add(createCvdCard());

            JScrollPane spBody = new JScrollPane(pnlBody);
            spBody.setBorder(null);
            spBody.setBackground(BG_CARD);
            spBody.getViewport().setBackground(BG_CARD);
            spBody.getVerticalScrollBar().setUnitIncrement(16);
            root.add(spBody, BorderLayout.CENTER);

            // Bottom Actions
            JPanel pnlBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
            pnlBottom.setBackground(BG_CARD);

            JButton btnCopyReport = new JButton("Copy Full Audit Report");
            btnCopyReport.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            btnCopyReport.setFont(new Font("Segoe UI", Font.BOLD, 13));
            btnCopyReport.setBackground(Color.WHITE);
            btnCopyReport.setForeground(Color.BLACK);
            btnCopyReport.setOpaque(true);
            btnCopyReport.setFocusPainted(false);
            btnCopyReport.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnCopyReport.setPreferredSize(new Dimension(205, 36));
            btnCopyReport.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(180, 190, 210), 1, true),
                    new EmptyBorder(6, 12, 6, 12)
            ));

            JButton btnClose = new JButton("Close");
            btnClose.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            btnClose.setFont(new Font("Segoe UI", Font.BOLD, 13));
            btnClose.setBackground(Color.WHITE);
            btnClose.setForeground(Color.BLACK);
            btnClose.setOpaque(true);
            btnClose.setFocusPainted(false);
            btnClose.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnClose.setPreferredSize(new Dimension(90, 36));
            btnClose.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(180, 190, 210), 1, true),
                    new EmptyBorder(6, 12, 6, 12)
            ));

            pnlBottom.add(btnCopyReport);
            pnlBottom.add(btnClose);
            root.add(pnlBottom, BorderLayout.SOUTH);

            // Copy Report Action
            btnCopyReport.addActionListener(e -> {
                String report = buildAuditReport();
                Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(report), null);
                SoundManager.play("chime");
                JOptionPane.showMessageDialog(this,
                        "Full Academic Color & WCAG 2.1 Audit Report copied to clipboard!\nReady to paste into your project documentation or report.",
                        "Report Copied", JOptionPane.INFORMATION_MESSAGE);
            });

            btnClose.addActionListener(e -> dispose());

            setContentPane(root);
        }

        private JPanel createMetricsCard() {
            JPanel card = new JPanel(new BorderLayout(8, 8));
            card.setBackground(BG_WINDOW);
            card.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(CARD_BORDER, 1),
                    new EmptyBorder(12, 16, 12, 16)
            ));

            JLabel lblSection = new JLabel("1. PHOTOMETRIC COLOR METRICS");
            lblSection.setFont(new Font("Segoe UI", Font.BOLD, 13));
            lblSection.setForeground(ACCENT_GOLD);
            card.add(lblSection, BorderLayout.NORTH);

            JPanel pnlSwatches = new JPanel(new GridLayout(1, 3, 14, 0));
            pnlSwatches.setOpaque(false);
            pnlSwatches.add(createColorPill("Primary Tone (C1)", c1, lum1));
            pnlSwatches.add(createColorPill("Secondary Tone (C2)", c2, lum2));
            pnlSwatches.add(createColorPill("Mixed Output (Result)", cMix, lumMix));

            card.add(pnlSwatches, BorderLayout.CENTER);
            return card;
        }

        private JPanel createColorPill(String title, Color c, double lum) {
            JPanel pnl = new JPanel(new BorderLayout(6, 6));
            pnl.setBackground(BG_CARD);
            pnl.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(CARD_BORDER, 1),
                    new EmptyBorder(8, 10, 8, 10)
            ));

            JLabel lblT = new JLabel(title, SwingConstants.CENTER);
            lblT.setFont(new Font("Segoe UI", Font.BOLD, 11));
            lblT.setForeground(TEXT_LIGHT);
            pnl.add(lblT, BorderLayout.NORTH);

            JPanel swatch = new JPanel();
            swatch.setPreferredSize(new Dimension(100, 36));
            swatch.setBackground(c);
            swatch.setBorder(new LineBorder(Color.BLACK, 1));
            pnl.add(swatch, BorderLayout.CENTER);

            String hex = String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
            JLabel lblInfo = new JLabel("<html><center style='color:#9ba5b9; font-size:10px;'>"
                    + "<b>" + hex + "</b><br/>"
                    + "RGB(" + c.getRed() + "," + c.getGreen() + "," + c.getBlue() + ")<br/>"
                    + "Luminance: " + String.format("%.3f", lum)
                    + "</center></html>", SwingConstants.CENTER);
            pnl.add(lblInfo, BorderLayout.SOUTH);

            return pnl;
        }

        private JPanel createWcagCard() {
            JPanel card = new JPanel(new BorderLayout(8, 8));
            card.setBackground(BG_WINDOW);
            card.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(CARD_BORDER, 1),
                    new EmptyBorder(12, 16, 12, 16)
            ));

            JLabel lblSection = new JLabel("2. WCAG 2.1 ACCESSIBILITY COMPLIANCE AUDIT");
            lblSection.setFont(new Font("Segoe UI", Font.BOLD, 13));
            lblSection.setForeground(ACCENT_CYAN);
            card.add(lblSection, BorderLayout.NORTH);

            JPanel pnlGrid = new JPanel(new GridLayout(2, 2, 12, 8));
            pnlGrid.setOpaque(false);

            boolean aaWhite = contrastWhite >= 4.5;
            boolean aaaWhite = contrastWhite >= 7.0;
            boolean aaBlack = contrastBlack >= 4.5;
            boolean aaaBlack = contrastBlack >= 7.0;

            pnlGrid.add(createCompliancePill("Against Pure White (#FFFFFF)",
                    String.format("%.2f : 1", contrastWhite),
                    aaWhite ? "PASS (AA)" : "FAIL (AA)", aaWhite,
                    aaaWhite ? "PASS (AAA)" : "FAIL (AAA)", aaaWhite));

            pnlGrid.add(createCompliancePill("Against Pure Black (#000000)",
                    String.format("%.2f : 1", contrastBlack),
                    aaBlack ? "PASS (AA)" : "FAIL (AA)", aaBlack,
                    aaaBlack ? "PASS (AAA)" : "FAIL (AAA)", aaaBlack));

            // Perceptual Delta-E between C1 and C2
            double deltaE = Math.sqrt(
                    2 * Math.pow(c1.getRed() - c2.getRed(), 2) +
                    4 * Math.pow(c1.getGreen() - c2.getGreen(), 2) +
                    3 * Math.pow(c1.getBlue() - c2.getBlue(), 2)
            );
            String deltaDesc = (deltaE < 30) ? "Subtle / Low Contrast" : (deltaE < 120 ? "Harmonious Contrast" : "Vivid / High Contrast");

            JPanel pnlDelta = new JPanel(new BorderLayout(4, 4));
            pnlDelta.setBackground(BG_CARD);
            pnlDelta.setBorder(new EmptyBorder(6, 10, 6, 10));
            JLabel lblDeltaTitle = new JLabel("Perceptual Difference (\u0394E):");
            lblDeltaTitle.setFont(new Font("Segoe UI", Font.BOLD, 11));
            lblDeltaTitle.setForeground(TEXT_LIGHT);
            JLabel lblDeltaVal = new JLabel(String.format("\u0394E = %.1f (%s)", deltaE, deltaDesc));
            lblDeltaVal.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            lblDeltaVal.setForeground(ACCENT_GOLD);
            pnlDelta.add(lblDeltaTitle, BorderLayout.NORTH);
            pnlDelta.add(lblDeltaVal, BorderLayout.CENTER);
            pnlGrid.add(pnlDelta);

            // Estimated Color Temperature (Kelvin)
            int kelvin = estimateColorTemperature(cMix);
            String tempType = (kelvin < 4000) ? "Warm Tones (Infrared Dominant)" : (kelvin < 6500 ? "Neutral Daylight" : "Cool Tones (Blue Sky Dominant)");

            JPanel pnlTemp = new JPanel(new BorderLayout(4, 4));
            pnlTemp.setBackground(BG_CARD);
            pnlTemp.setBorder(new EmptyBorder(6, 10, 6, 10));
            JLabel lblTempTitle = new JLabel("Correlated Color Temperature (CCT):");
            lblTempTitle.setFont(new Font("Segoe UI", Font.BOLD, 11));
            lblTempTitle.setForeground(TEXT_LIGHT);
            JLabel lblTempVal = new JLabel("~" + kelvin + "K (" + tempType + ")");
            lblTempVal.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            lblTempVal.setForeground(ACCENT_CYAN);
            pnlTemp.add(lblTempTitle, BorderLayout.NORTH);
            pnlTemp.add(lblTempVal, BorderLayout.CENTER);
            pnlGrid.add(pnlTemp);

            card.add(pnlGrid, BorderLayout.CENTER);
            return card;
        }

        private JPanel createCompliancePill(String title, String ratio, String aaStatus, boolean aaPass, String aaaStatus, boolean aaaPass) {
            JPanel p = new JPanel(new BorderLayout(4, 4));
            p.setBackground(BG_CARD);
            p.setBorder(new EmptyBorder(6, 10, 6, 10));

            JLabel lblT = new JLabel(title);
            lblT.setFont(new Font("Segoe UI", Font.BOLD, 11));
            lblT.setForeground(TEXT_LIGHT);

            JLabel lblRatio = new JLabel("Ratio: " + ratio + "  |  AA: " + (aaPass ? "PASS" : "FAIL") + "  |  AAA: " + (aaaPass ? "PASS" : "FAIL"));
            lblRatio.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            lblRatio.setForeground(aaPass ? new Color(120, 240, 140) : new Color(255, 120, 120));

            p.add(lblT, BorderLayout.NORTH);
            p.add(lblRatio, BorderLayout.CENTER);
            return p;
        }

        private JPanel createCvdCard() {
            JPanel card = new JPanel(new BorderLayout(8, 8));
            card.setBackground(BG_WINDOW);
            card.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(CARD_BORDER, 1),
                    new EmptyBorder(12, 16, 12, 16)
            ));

            JLabel lblSection = new JLabel("3. COLOR VISION DEFICIENCY (DALTONISM) LIVE SIMULATION");
            lblSection.setFont(new Font("Segoe UI", Font.BOLD, 13));
            lblSection.setForeground(ACCENT_PINK);
            card.add(lblSection, BorderLayout.NORTH);

            JPanel pnlCvdSwatches = new JPanel(new GridLayout(1, 4, 10, 0));
            pnlCvdSwatches.setOpaque(false);

            pnlCvdSwatches.add(createCvdPill("Normal", cMix, "Trichromatic Standard"));
            pnlCvdSwatches.add(createCvdPill("Protanopia", protanopiaMix, "Red-Weak (~1% Males)"));
            pnlCvdSwatches.add(createCvdPill("Deuteranopia", deuteranopiaMix, "Green-Weak (~5% Males)"));
            pnlCvdSwatches.add(createCvdPill("Tritanopia", tritanopiaMix, "Blue-Weak (<0.01%)"));

            card.add(pnlCvdSwatches, BorderLayout.CENTER);
            return card;
        }

        private JPanel createCvdPill(String title, Color c, String subtitle) {
            JPanel pnl = new JPanel(new BorderLayout(4, 4));
            pnl.setBackground(BG_CARD);
            pnl.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(CARD_BORDER, 1),
                    new EmptyBorder(6, 6, 6, 6)
            ));

            JLabel lblT = new JLabel(title, SwingConstants.CENTER);
            lblT.setFont(new Font("Segoe UI", Font.BOLD, 11));
            lblT.setForeground(TEXT_LIGHT);
            pnl.add(lblT, BorderLayout.NORTH);

            JPanel swatch = new JPanel();
            swatch.setPreferredSize(new Dimension(80, 30));
            swatch.setBackground(c);
            swatch.setBorder(new LineBorder(Color.BLACK, 1));
            pnl.add(swatch, BorderLayout.CENTER);

            String hex = String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
            JLabel lblB = new JLabel("<html><center style='color:#9ba5b9; font-size:9px;'>"
                    + "<b>" + hex + "</b><br/>"
                    + subtitle + "</center></html>", SwingConstants.CENTER);
            pnl.add(lblB, BorderLayout.SOUTH);

            return pnl;
        }

        private String buildAuditReport() {
            StringBuilder sb = new StringBuilder();
            sb.append("=================================================================\n");
            sb.append("CHILL PAINT MASTER - COLOR THEORY & WCAG 2.1 AUDIT REPORT\n");
            sb.append("=================================================================\n\n");
            sb.append("1. SPECTROPHOTOMETRIC CHROMATICITY:\n");
            sb.append(String.format("   Primary Color (C1)   : #%02X%02X%02X  RGB(%d, %d, %d)  Rel. Luminance: %.4f\n",
                    c1.getRed(), c1.getGreen(), c1.getBlue(), c1.getRed(), c1.getGreen(), c1.getBlue(), lum1));
            sb.append(String.format("   Secondary Color (C2) : #%02X%02X%02X  RGB(%d, %d, %d)  Rel. Luminance: %.4f\n",
                    c2.getRed(), c2.getGreen(), c2.getBlue(), c2.getRed(), c2.getGreen(), c2.getBlue(), lum2));
            sb.append(String.format("   Mixed Result (Mix)   : #%02X%02X%02X  RGB(%d, %d, %d)  Rel. Luminance: %.4f\n\n",
                    cMix.getRed(), cMix.getGreen(), cMix.getBlue(), cMix.getRed(), cMix.getGreen(), cMix.getBlue(), lumMix));

            sb.append("2. WCAG 2.1 ACCESSIBILITY COMPLIANCE (MIXED COLOR):\n");
            sb.append(String.format("   Contrast Ratio vs Pure White (#FFFFFF): %.2f:1\n", contrastWhite));
            sb.append("      - WCAG AA (>= 4.5:1) : ").append(contrastWhite >= 4.5 ? "PASS" : "FAIL").append("\n");
            sb.append("      - WCAG AAA (>= 7.0:1): ").append(contrastWhite >= 7.0 ? "PASS" : "FAIL").append("\n");
            sb.append(String.format("   Contrast Ratio vs Pure Black (#000000): %.2f:1\n", contrastBlack));
            sb.append("      - WCAG AA (>= 4.5:1) : ").append(contrastBlack >= 4.5 ? "PASS" : "FAIL").append("\n");
            sb.append("      - WCAG AAA (>= 7.0:1): ").append(contrastBlack >= 7.0 ? "PASS" : "FAIL").append("\n\n");

            sb.append("3. COLOR BLINDNESS VISION SIMULATION (VIENOT/BRETTEL MODEL):\n");
            sb.append(String.format("   Normal Vision (Trichromat): #%02X%02X%02X\n", cMix.getRed(), cMix.getGreen(), cMix.getBlue()));
            sb.append(String.format("   Protanopia   (L-Cone Void): #%02X%02X%02X\n", protanopiaMix.getRed(), protanopiaMix.getGreen(), protanopiaMix.getBlue()));
            sb.append(String.format("   Deuteranopia (M-Cone Void): #%02X%02X%02X\n", deuteranopiaMix.getRed(), deuteranopiaMix.getGreen(), deuteranopiaMix.getBlue()));
            sb.append(String.format("   Tritanopia   (S-Cone Void): #%02X%02X%02X\n\n", tritanopiaMix.getRed(), tritanopiaMix.getGreen(), tritanopiaMix.getBlue()));

            sb.append("4. COLOR TEMPERATURE & PERCEPTION:\n");
            int k = estimateColorTemperature(cMix);
            sb.append(String.format("   Estimated Correlated Color Temperature: ~%d K\n", k));
            sb.append("=================================================================\n");
            return sb.toString();
        }

        // --- Scientific Helper Calculations ---

        public static double calculateLuminance(Color c) {
            double r = c.getRed() / 255.0;
            double g = c.getGreen() / 255.0;
            double b = c.getBlue() / 255.0;

            double rLin = (r <= 0.03928) ? r / 12.92 : Math.pow((r + 0.055) / 1.055, 2.4);
            double gLin = (g <= 0.03928) ? g / 12.92 : Math.pow((g + 0.055) / 1.055, 2.4);
            double bLin = (b <= 0.03928) ? b / 12.92 : Math.pow((b + 0.055) / 1.055, 2.4);

            return 0.2126 * rLin + 0.7152 * gLin + 0.0722 * bLin;
        }

        public static double calculateContrast(double l1, double l2) {
            double brighter = Math.max(l1, l2);
            double darker = Math.min(l1, l2);
            return (brighter + 0.05) / (darker + 0.05);
        }

        public static Color simulateProtanopia(Color c) {
            double r = c.getRed(), g = c.getGreen(), b = c.getBlue();
            double nr = 0.56667 * r + 0.43333 * g;
            double ng = 0.55833 * r + 0.44167 * g;
            double nb = 0.24167 * g + 0.75833 * b;
            return new Color(clamp(nr), clamp(ng), clamp(nb));
        }

        public static Color simulateDeuteranopia(Color c) {
            double r = c.getRed(), g = c.getGreen(), b = c.getBlue();
            double nr = 0.62500 * r + 0.37500 * g;
            double ng = 0.70000 * r + 0.30000 * g;
            double nb = 0.30000 * g + 0.70000 * b;
            return new Color(clamp(nr), clamp(ng), clamp(nb));
        }

        public static Color simulateTritanopia(Color c) {
            double r = c.getRed(), g = c.getGreen(), b = c.getBlue();
            double nr = 0.95000 * r + 0.05000 * g;
            double ng = 0.43333 * g + 0.56667 * b;
            double nb = 0.47500 * g + 0.52500 * b;
            return new Color(clamp(nr), clamp(ng), clamp(nb));
        }

        private static int estimateColorTemperature(Color c) {
            int r = c.getRed(), b = c.getBlue();
            if (r + b == 0) return 5500;
            double balance = (double) b / (r + b);
            return (int) Math.round(2000 + balance * 7000);
        }

        private static int clamp(double val) {
            return (int) Math.max(0, Math.min(255, Math.round(val)));
        }
    }

    // =========================================================================
    // INNER CLASS: ColorIQGameDialog (Interactive Color Matching Tournament)
    // =========================================================================
    public static class ColorIQGameDialog extends JDialog {
        private final ColorMixingStudio studio;
        private final Random rng = new Random();

        private int currentRound = 1;
        private final int TOTAL_ROUNDS = 5;
        private int totalScore = 0;
        private static int topHighScore = 0;
        private double totalAccuracySum = 0;

        private int roundDuration = 35; // default 35s
        private int timeRemaining;
        private javax.swing.Timer countdownTimer;

        private Color targetColor;
        private final java.util.List<Color> tournamentTargetColors = new ArrayList<>();
        private int playerR = 128, playerG = 128, playerB = 128;
        private boolean hintUsedThisRound = false;
        private boolean roundActive = false;

        // UI Components
        private JLabel lblRoundBadge, lblScoreBadge, lblHighScoreBadge, lblTimerText;
        private JProgressBar pbTimer;
        private JComboBox<String> cbDifficulty;
        private JPanel pnlTargetSwatch, pnlPlayerSwatch;
        private JLabel lblTargetDetails, lblPlayerDetails, lblPerceptualHint;
        private JSlider sliderR, sliderG, sliderB;
        private JLabel lblValR, lblValG, lblValB;
        private JButton btnSubmit, btnHint, btnSendColorToStudio;

        public ColorIQGameDialog(ColorMixingStudio studio) {
            super(studio, "Color IQ Challenge — Visual Perception & Chroma Matching Tournament", true);
            this.studio = studio;

            setSize(880, 740);
            setLocationRelativeTo(studio);
            setResizable(false);
            getContentPane().setBackground(BG_CARD);

            buildUI();
            startNewTournament();
        }

        private void buildUI() {
            JPanel root = new JPanel(new BorderLayout(14, 14));
            root.setBackground(BG_CARD);
            root.setBorder(new EmptyBorder(18, 22, 18, 22));

            // --- NORTH: Header Banner, Score Badges & Timer Bar ---
            JPanel pnlNorth = new JPanel(new BorderLayout(10, 10));
            pnlNorth.setOpaque(false);

            JPanel pnlHeaderTop = new JPanel(new BorderLayout(12, 0));
            pnlHeaderTop.setOpaque(false);

            JPanel pnlTitle = new JPanel(new GridLayout(2, 1, 0, 2));
            pnlTitle.setOpaque(false);
            JLabel lblTitle = new JLabel("Color IQ Challenge");
            lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
            lblTitle.setForeground(ACCENT_CYAN);
            JLabel lblSubtitle = new JLabel("Scientific Chroma Matching, Visual Perception & Rapid Calibration Tournament");
            lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            lblSubtitle.setForeground(TEXT_MUTED);
            pnlTitle.add(lblTitle);
            pnlTitle.add(lblSubtitle);
            pnlHeaderTop.add(pnlTitle, BorderLayout.WEST);

            // Right Badges & Difficulty
            JPanel pnlBadges = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4));
            pnlBadges.setOpaque(false);

            lblRoundBadge = createBadge("Round 1/5", new Color(40, 50, 75), ACCENT_CYAN);
            lblScoreBadge = createBadge("Score: 0 pts", new Color(40, 60, 50), new Color(100, 255, 160));
            lblHighScoreBadge = createBadge("Best: " + topHighScore + " pts", new Color(60, 50, 30), ACCENT_GOLD);

            cbDifficulty = new JComboBox<>(new String[]{"Easy (45s)", "Normal (35s)", "Master Artist (18s)"});
            cbDifficulty.setSelectedIndex(1);
            cbDifficulty.setFont(new Font("Segoe UI", Font.BOLD, 12));
            cbDifficulty.setBackground(BG_INPUT);
            cbDifficulty.setForeground(TEXT_LIGHT);
            cbDifficulty.setToolTipText("Select challenge difficulty limit");
            cbDifficulty.addActionListener(e -> {
                int idx = cbDifficulty.getSelectedIndex();
                if (idx == 0) roundDuration = 45;
                else if (idx == 1) roundDuration = 35;
                else roundDuration = 18;
                if (!roundActive) {
                    timeRemaining = roundDuration;
                    pbTimer.setMaximum(roundDuration);
                    pbTimer.setValue(timeRemaining);
                    lblTimerText.setText("Time Limit: " + timeRemaining + "s");
                }
            });

            pnlBadges.add(lblRoundBadge);
            pnlBadges.add(lblScoreBadge);
            pnlBadges.add(lblHighScoreBadge);
            pnlBadges.add(cbDifficulty);
            pnlHeaderTop.add(pnlBadges, BorderLayout.EAST);

            // Timer Panel
            JPanel pnlTimer = new JPanel(new BorderLayout(8, 0));
            pnlTimer.setOpaque(false);
            pnlTimer.setBorder(new EmptyBorder(4, 0, 0, 0));

            lblTimerText = new JLabel("Time Remaining: 35s");
            lblTimerText.setFont(new Font("Segoe UI", Font.BOLD, 13));
            lblTimerText.setForeground(TEXT_LIGHT);
            lblTimerText.setPreferredSize(new Dimension(170, 22));

            pbTimer = new JProgressBar(0, roundDuration);
            pbTimer.setValue(roundDuration);
            pbTimer.setForeground(new Color(50, 205, 120));
            pbTimer.setBackground(BG_INPUT);
            pbTimer.setPreferredSize(new Dimension(500, 14));
            pbTimer.setBorder(new LineBorder(CARD_BORDER, 1));

            pnlTimer.add(lblTimerText, BorderLayout.WEST);
            pnlTimer.add(pbTimer, BorderLayout.CENTER);

            pnlNorth.add(pnlHeaderTop, BorderLayout.NORTH);
            pnlNorth.add(pnlTimer, BorderLayout.SOUTH);
            root.add(pnlNorth, BorderLayout.NORTH);

            // --- CENTER: Visual Swatch Arena & Mixing Sliders ---
            JPanel pnlCenter = new JPanel(new BorderLayout(14, 14));
            pnlCenter.setOpaque(false);

            // 1. Swatch Comparison Panel (Side-by-Side Arena)
            JPanel pnlSwatchesCard = new JPanel(new GridLayout(1, 2, 16, 0));
            pnlSwatchesCard.setOpaque(false);
            pnlSwatchesCard.setPreferredSize(new Dimension(800, 165));

            // Target Swatch Box
            JPanel pnlTargetCard = new JPanel(new BorderLayout(6, 6));
            pnlTargetCard.setBackground(BG_INPUT);
            pnlTargetCard.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(CARD_BORDER, 1, true),
                    new EmptyBorder(10, 14, 10, 14)));

            JLabel lblTargetHeading = new JLabel("TARGET MYSTERY COLOR  [Goal]");
            lblTargetHeading.setFont(new Font("Segoe UI", Font.BOLD, 13));
            lblTargetHeading.setForeground(ACCENT_GOLD);
            lblTargetHeading.setHorizontalAlignment(SwingConstants.CENTER);

            pnlTargetSwatch = new JPanel() {
                @Override protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    if (targetColor != null) {
                        g2.setColor(targetColor);
                        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                    }
                    g2.setColor(new Color(255, 255, 255, 60));
                    g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                    g2.dispose();
                }
            };
            pnlTargetSwatch.setPreferredSize(new Dimension(360, 95));

            lblTargetDetails = new JLabel("Target: [ Hidden — Match visually! ]");
            lblTargetDetails.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblTargetDetails.setForeground(TEXT_MUTED);
            lblTargetDetails.setHorizontalAlignment(SwingConstants.CENTER);

            pnlTargetCard.add(lblTargetHeading, BorderLayout.NORTH);
            pnlTargetCard.add(pnlTargetSwatch, BorderLayout.CENTER);
            pnlTargetCard.add(lblTargetDetails, BorderLayout.SOUTH);

            // Player Swatch Box
            JPanel pnlPlayerCard = new JPanel(new BorderLayout(6, 6));
            pnlPlayerCard.setBackground(BG_INPUT);
            pnlPlayerCard.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(CARD_BORDER, 1, true),
                    new EmptyBorder(10, 14, 10, 14)));

            JLabel lblPlayerHeading = new JLabel("YOUR LIVE MIXTURE  [Adjust Below]");
            lblPlayerHeading.setFont(new Font("Segoe UI", Font.BOLD, 13));
            lblPlayerHeading.setForeground(ACCENT_CYAN);
            lblPlayerHeading.setHorizontalAlignment(SwingConstants.CENTER);

            pnlPlayerSwatch = new JPanel() {
                @Override protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(new Color(playerR, playerG, playerB));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                    g2.setColor(new Color(255, 255, 255, 60));
                    g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                    g2.dispose();
                }
            };
            pnlPlayerSwatch.setPreferredSize(new Dimension(360, 95));

            lblPlayerDetails = new JLabel("Mix: #808080 | RGB(128, 128, 128)");
            lblPlayerDetails.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblPlayerDetails.setForeground(TEXT_LIGHT);
            lblPlayerDetails.setHorizontalAlignment(SwingConstants.CENTER);

            pnlPlayerCard.add(lblPlayerHeading, BorderLayout.NORTH);
            pnlPlayerCard.add(pnlPlayerSwatch, BorderLayout.CENTER);
            pnlPlayerCard.add(lblPlayerDetails, BorderLayout.SOUTH);

            pnlSwatchesCard.add(pnlTargetCard);
            pnlSwatchesCard.add(pnlPlayerCard);
            pnlCenter.add(pnlSwatchesCard, BorderLayout.NORTH);

            // 2. Sliders and Nudge Controls (Interactive Studio Mixing)
            JPanel pnlControlsCard = new JPanel();
            pnlControlsCard.setLayout(new BoxLayout(pnlControlsCard, BoxLayout.Y_AXIS));
            pnlControlsCard.setBackground(BG_INPUT);
            pnlControlsCard.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(CARD_BORDER, 1, true),
                    new EmptyBorder(12, 16, 12, 16)));

            // Red Slider Row
            sliderR = new JSlider(0, 255, playerR);
            lblValR = new JLabel("128", SwingConstants.CENTER);
            JPanel pnlRedRow = createSliderRow("RED CHANNEL", new Color(255, 95, 95), sliderR, lblValR, val -> {
                playerR = val;
                updatePlayerMix();
            });

            // Green Slider Row
            sliderG = new JSlider(0, 255, playerG);
            lblValG = new JLabel("128", SwingConstants.CENTER);
            JPanel pnlGreenRow = createSliderRow("GREEN CHANNEL", new Color(75, 240, 140), sliderG, lblValG, val -> {
                playerG = val;
                updatePlayerMix();
            });

            // Blue Slider Row
            sliderB = new JSlider(0, 255, playerB);
            lblValB = new JLabel("128", SwingConstants.CENTER);
            JPanel pnlBlueRow = createSliderRow("BLUE CHANNEL", new Color(90, 175, 255), sliderB, lblValB, val -> {
                playerB = val;
                updatePlayerMix();
            });

            pnlControlsCard.add(pnlRedRow);
            pnlControlsCard.add(Box.createVerticalStrut(6));
            pnlControlsCard.add(pnlGreenRow);
            pnlControlsCard.add(Box.createVerticalStrut(6));
            pnlControlsCard.add(pnlBlueRow);
            pnlControlsCard.add(Box.createVerticalStrut(10));

            // Quick Primary Tint Nudges
            JPanel pnlQuickNudges = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
            pnlQuickNudges.setOpaque(false);

            JLabel lblQuickLabel = new JLabel("Quick Primary Nudges:");
            lblQuickLabel.setFont(new Font("Segoe UI", Font.BOLD, 11));
            lblQuickLabel.setForeground(TEXT_MUTED);
            pnlQuickNudges.add(lblQuickLabel);

            pnlQuickNudges.add(createNudgeButton("+ Red", new Color(255, 95, 95), () -> nudgeChannels(30, 0, 0)));
            pnlQuickNudges.add(createNudgeButton("+ Green", new Color(75, 240, 140), () -> nudgeChannels(0, 30, 0)));
            pnlQuickNudges.add(createNudgeButton("+ Blue", new Color(90, 175, 255), () -> nudgeChannels(0, 0, 30)));
            pnlQuickNudges.add(createNudgeButton("+ Yellow", new Color(255, 220, 60), () -> nudgeChannels(25, 25, 0)));
            pnlQuickNudges.add(createNudgeButton("+ Cyan", new Color(0, 240, 220), () -> nudgeChannels(0, 25, 25)));
            pnlQuickNudges.add(createNudgeButton("+ Magenta", new Color(245, 90, 230), () -> nudgeChannels(25, 0, 25)));
            pnlQuickNudges.add(createNudgeButton("Reset (128)", Color.WHITE, () -> {
                playerR = 128; playerG = 128; playerB = 128;
                sliderR.setValue(128); sliderG.setValue(128); sliderB.setValue(128);
                updatePlayerMix();
            }));

            pnlControlsCard.add(pnlQuickNudges);
            pnlCenter.add(pnlControlsCard, BorderLayout.CENTER);

            // 3. Hint Banner
            JPanel pnlHintCard = new JPanel(new BorderLayout(10, 0));
            pnlHintCard.setBackground(new Color(24, 28, 40));
            pnlHintCard.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(new Color(60, 70, 95), 1, true),
                    new EmptyBorder(8, 12, 8, 12)));

            btnHint = new JButton("Get Perceptual Hint (-20 pts)");
            btnHint.setFont(new Font("Segoe UI", Font.BOLD, 12));
            btnHint.setBackground(new Color(50, 60, 85));
            btnHint.setForeground(ACCENT_GOLD);
            btnHint.setFocusPainted(false);
            btnHint.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnHint.addActionListener(e -> requestPerceptualHint());

            lblPerceptualHint = new JLabel("Tip: Use the RGB sliders and nudge buttons to match the target swatch visually.");
            lblPerceptualHint.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            lblPerceptualHint.setForeground(TEXT_LIGHT);

            pnlHintCard.add(btnHint, BorderLayout.WEST);
            pnlHintCard.add(lblPerceptualHint, BorderLayout.CENTER);
            pnlCenter.add(pnlHintCard, BorderLayout.SOUTH);

            root.add(pnlCenter, BorderLayout.CENTER);

            // --- SOUTH: Action Toolbar ---
            JPanel pnlSouth = new JPanel(new BorderLayout(10, 0));
            pnlSouth.setOpaque(false);
            pnlSouth.setBorder(new EmptyBorder(6, 0, 0, 0));

            btnSendColorToStudio = new JButton("Save Color to Studio Palette");
            btnSendColorToStudio.setFont(new Font("Segoe UI", Font.BOLD, 12));
            btnSendColorToStudio.setBackground(BG_INPUT);
            btnSendColorToStudio.setForeground(ACCENT_CYAN);
            btnSendColorToStudio.setFocusPainted(false);
            btnSendColorToStudio.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnSendColorToStudio.addActionListener(e -> saveTargetColorToStudio());
            pnlSouth.add(btnSendColorToStudio, BorderLayout.WEST);

            JPanel pnlSouthRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
            pnlSouthRight.setOpaque(false);

            JButton btnRestart = new JButton("Restart Tournament");
            btnRestart.setFont(new Font("Segoe UI", Font.BOLD, 12));
            btnRestart.setBackground(BG_INPUT);
            btnRestart.setForeground(TEXT_LIGHT);
            btnRestart.setFocusPainted(false);
            btnRestart.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnRestart.addActionListener(e -> {
                SoundManager.play("click");
                startNewTournament();
            });

            JButton btnClose = new JButton("Close");
            btnClose.setFont(new Font("Segoe UI", Font.BOLD, 12));
            btnClose.setBackground(BG_INPUT);
            btnClose.setForeground(TEXT_MUTED);
            btnClose.setFocusPainted(false);
            btnClose.addActionListener(e -> {
                if (countdownTimer != null) countdownTimer.stop();
                dispose();
            });

            btnSubmit = new JButton("SUBMIT MATCH  [Enter]");
            btnSubmit.setFont(new Font("Segoe UI", Font.BOLD, 14));
            btnSubmit.setBackground(ACCENT_CYAN);
            btnSubmit.setForeground(Color.BLACK);
            btnSubmit.setFocusPainted(false);
            btnSubmit.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnSubmit.setPreferredSize(new Dimension(220, 36));
            btnSubmit.addActionListener(e -> submitMatch(false));

            pnlSouthRight.add(btnRestart);
            pnlSouthRight.add(btnClose);
            pnlSouthRight.add(btnSubmit);
            pnlSouth.add(pnlSouthRight, BorderLayout.EAST);

            root.add(pnlSouth, BorderLayout.SOUTH);

            setContentPane(root);

            // Enter key shortcut to submit
            getRootPane().registerKeyboardAction(e -> submitMatch(false),
                    KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
                    JComponent.WHEN_IN_FOCUSED_WINDOW);

            addWindowListener(new WindowAdapter() {
                @Override public void windowClosing(WindowEvent e) {
                    if (countdownTimer != null) countdownTimer.stop();
                }
            });
        }

        private JLabel createBadge(String text, Color bg, Color fg) {
            JLabel badge = new JLabel(text);
            badge.setFont(new Font("Segoe UI", Font.BOLD, 12));
            badge.setOpaque(true);
            badge.setBackground(bg);
            badge.setForeground(fg);
            badge.setBorder(new EmptyBorder(5, 12, 5, 12));
            return badge;
        }

        private JPanel createSliderRow(String title, Color col, JSlider slider, JLabel lblVal, java.util.function.IntConsumer onValChange) {
            JPanel row = new JPanel(new BorderLayout(8, 0));
            row.setOpaque(false);

            JLabel lblName = new JLabel(title);
            lblName.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblName.setForeground(col);
            lblName.setPreferredSize(new Dimension(130, 26));

            JPanel pnlSliderBox = new JPanel(new BorderLayout(6, 0));
            pnlSliderBox.setOpaque(false);

            JButton btnMinus10 = createStepButton("-10", () -> slider.setValue(slider.getValue() - 10));
            JButton btnMinus1  = createStepButton("-1",  () -> slider.setValue(slider.getValue() - 1));
            JButton btnPlus1   = createStepButton("+1",  () -> slider.setValue(slider.getValue() + 1));
            JButton btnPlus10  = createStepButton("+10", () -> slider.setValue(slider.getValue() + 10));

            JPanel pnlLeftBtns = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
            pnlLeftBtns.setOpaque(false);
            pnlLeftBtns.add(btnMinus10);
            pnlLeftBtns.add(btnMinus1);

            JPanel pnlRightBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 2, 0));
            pnlRightBtns.setOpaque(false);
            pnlRightBtns.add(btnPlus1);
            pnlRightBtns.add(btnPlus10);

            slider.setOpaque(false);
            slider.setPaintTrack(true);
            slider.setPaintTicks(false);
            slider.addChangeListener(e -> {
                int v = slider.getValue();
                lblVal.setText(String.valueOf(v));
                onValChange.accept(v);
            });

            pnlSliderBox.add(pnlLeftBtns, BorderLayout.WEST);
            pnlSliderBox.add(slider, BorderLayout.CENTER);
            pnlSliderBox.add(pnlRightBtns, BorderLayout.EAST);

            lblVal.setFont(new Font("Segoe UI", Font.BOLD, 13));
            lblVal.setForeground(TEXT_LIGHT);
            lblVal.setPreferredSize(new Dimension(36, 26));

            row.add(lblName, BorderLayout.WEST);
            row.add(pnlSliderBox, BorderLayout.CENTER);
            row.add(lblVal, BorderLayout.EAST);

            return row;
        }

        private JButton createStepButton(String text, Runnable action) {
            JButton b = new JButton(text);
            b.setFont(new Font("Segoe UI", Font.BOLD, 10));
            b.setBackground(new Color(36, 42, 58));
            b.setForeground(TEXT_LIGHT);
            b.setFocusPainted(false);
            b.setPreferredSize(new Dimension(34, 24));
            b.setMargin(new Insets(1, 1, 1, 1));
            b.addActionListener(e -> {
                SoundManager.play("tick");
                action.run();
            });
            return b;
        }

        private JButton createNudgeButton(String text, Color fg, Runnable action) {
            JButton b = new JButton(text);
            b.setFont(new Font("Segoe UI", Font.BOLD, 11));
            b.setBackground(new Color(32, 38, 52));
            b.setForeground(fg);
            b.setFocusPainted(false);
            b.setCursor(new Cursor(Cursor.HAND_CURSOR));
            b.addActionListener(e -> {
                SoundManager.play("click");
                action.run();
            });
            return b;
        }

        private void nudgeChannels(int dr, int dg, int db) {
            if (dr != 0) sliderR.setValue(Math.max(0, Math.min(255, sliderR.getValue() + dr)));
            if (dg != 0) sliderG.setValue(Math.max(0, Math.min(255, sliderG.getValue() + dg)));
            if (db != 0) sliderB.setValue(Math.max(0, Math.min(255, sliderB.getValue() + db)));
        }

        private void updatePlayerMix() {
            pnlPlayerSwatch.repaint();
            lblPlayerDetails.setText(String.format("Mix: #%02X%02X%02X | RGB(%d, %d, %d)",
                    playerR, playerG, playerB, playerR, playerG, playerB));
        }

        public void startNewTournament() {
            currentRound = 1;
            totalScore = 0;
            totalAccuracySum = 0;
            tournamentTargetColors.clear();
            lblScoreBadge.setText("Score: 0 pts");
            lblHighScoreBadge.setText("Best: " + topHighScore + " pts");
            startRound();
        }

        private void startRound() {
            if (countdownTimer != null) countdownTimer.stop();

            // Generate an interesting and vibrant challenge target color
            int tr = rng.nextInt(225) + 18;
            int tg = rng.nextInt(225) + 18;
            int tb = rng.nextInt(225) + 18;
            targetColor = new Color(tr, tg, tb);
            tournamentTargetColors.add(targetColor);

            // Reset player mix to middle gray
            playerR = 128; playerG = 128; playerB = 128;
            sliderR.setValue(128);
            sliderG.setValue(128);
            sliderB.setValue(128);
            lblValR.setText("128");
            lblValG.setText("128");
            lblValB.setText("128");

            hintUsedThisRound = false;
            btnHint.setEnabled(true);
            lblPerceptualHint.setText("Tip: Use the RGB sliders and nudge buttons to match the target swatch visually.");
            lblTargetDetails.setText("Target: [ Hidden — Match visually! ]");

            lblRoundBadge.setText(String.format("Round %d/%d", currentRound, TOTAL_ROUNDS));

            // Set duration based on difficulty
            int diffIdx = cbDifficulty.getSelectedIndex();
            if (diffIdx == 0) roundDuration = 45;
            else if (diffIdx == 1) roundDuration = 35;
            else roundDuration = 18;

            timeRemaining = roundDuration;
            pbTimer.setMaximum(roundDuration);
            pbTimer.setValue(timeRemaining);
            lblTimerText.setText("Time Remaining: " + timeRemaining + "s");
            pbTimer.setForeground(new Color(50, 205, 120));

            pnlTargetSwatch.repaint();
            updatePlayerMix();

            roundActive = true;
            btnSubmit.setEnabled(true);

            countdownTimer = new javax.swing.Timer(1000, e -> {
                timeRemaining--;
                pbTimer.setValue(timeRemaining);
                lblTimerText.setText("Time Remaining: " + timeRemaining + "s");

                if (timeRemaining <= 10 && timeRemaining > 5) {
                    pbTimer.setForeground(new Color(255, 180, 40));
                } else if (timeRemaining <= 5) {
                    pbTimer.setForeground(new Color(255, 80, 80));
                    SoundManager.play("tick");
                }

                if (timeRemaining <= 0) {
                    countdownTimer.stop();
                    submitMatch(true);
                }
            });
            countdownTimer.start();
        }

        private void requestPerceptualHint() {
            if (!roundActive || hintUsedThisRound) return;
            hintUsedThisRound = true;
            btnHint.setEnabled(false);
            SoundManager.play("snap");

            int dr = targetColor.getRed() - playerR;
            int dg = targetColor.getGreen() - playerG;
            int db = targetColor.getBlue() - playerB;

            int maxDiff = Math.max(Math.abs(dr), Math.max(Math.abs(dg), Math.abs(db)));
            String hint;
            if (maxDiff == Math.abs(dr)) {
                hint = (dr > 0) ? "[HINT] Add more RED to warm up the tone!" : "[HINT] Reduce RED, tone is too fiery!";
            } else if (maxDiff == Math.abs(dg)) {
                hint = (dg > 0) ? "[HINT] Add more GREEN to lift brightness!" : "[HINT] Reduce GREEN, tone is too acidic!";
            } else {
                hint = (db > 0) ? "[HINT] Add more BLUE for cooler chroma!" : "[HINT] Reduce BLUE to clear up the warmth!";
            }
            lblPerceptualHint.setText(hint + " (-20 pts penalty applied)");
        }

        private void submitMatch(boolean isTimeout) {
            if (!roundActive) return;
            roundActive = false;
            btnSubmit.setEnabled(false);
            if (countdownTimer != null) countdownTimer.stop();

            // Reveal Target
            lblTargetDetails.setText(String.format("Target: #%02X%02X%02X | RGB(%d, %d, %d)",
                    targetColor.getRed(), targetColor.getGreen(), targetColor.getBlue(),
                    targetColor.getRed(), targetColor.getGreen(), targetColor.getBlue()));

            // Human Optical Sensitivity Weighted Distance:
            // Delta C = sqrt(2*dR^2 + 4*dG^2 + 3*dB^2) / 765.0
            double dr = targetColor.getRed() - playerR;
            double dg = targetColor.getGreen() - playerG;
            double db = targetColor.getBlue() - playerB;
            double dist = Math.sqrt(2.0 * dr * dr + 4.0 * dg * dg + 3.0 * db * db);
            double maxDist = 765.0; // sqrt(2*255^2 + 4*255^2 + 3*255^2)
            double accuracy = Math.max(0.0, 100.0 * (1.0 - (dist / maxDist)));

            // Points formula
            int basePts = (int) Math.round(accuracy * 10.0);
            int speedBonus = isTimeout ? 0 : (timeRemaining * 8);
            int perfectBonus = (accuracy >= 98.0) ? 200 : 0;
            int roundPts = basePts + speedBonus + perfectBonus;
            if (hintUsedThisRound) roundPts = Math.max(0, roundPts - 20);

            totalScore += roundPts;
            totalAccuracySum += accuracy;
            if (totalScore > topHighScore) topHighScore = totalScore;

            lblScoreBadge.setText("Score: " + totalScore + " pts");
            lblHighScoreBadge.setText("Best: " + topHighScore + " pts");

            // Audio & Rating
            String rating;
            if (accuracy >= 98.0) {
                rating = "*** FLAWLESS MATCH! (Tetrachromat Vision) ***";
                SoundManager.play("save");
            } else if (accuracy >= 90.0) {
                rating = "** MASTER ARTIST! (Exceptional Perception) **";
                SoundManager.play("chime");
            } else if (accuracy >= 80.0) {
                rating = "* GREAT EYE! (Sharp Acuity) *";
                SoundManager.play("chime");
            } else if (accuracy >= 65.0) {
                rating = "GOOD TRY! (Getting Closer)";
                SoundManager.play("snap");
            } else {
                rating = "PRACTICE NEEDED (Keep Training!)";
                SoundManager.play("snap");
            }

            // Show Round Summary Modal
            String roundMsg = String.format("<html><body style='font-family:Segoe UI; padding:8px; width:360px;'>"
                    + "<h2 style='color:#00ffff; margin-bottom:4px;'>Round %d of %d Summary</h2>"
                    + "<p style='font-size:14px; font-weight:bold; color:#ffdd55;'>%s</p>"
                    + "<hr style='border:0; border-top:1px solid #444; margin:8px 0;'/>"
                    + "<table style='width:100%%; font-size:12px;'>"
                    + "<tr><td><b>Match Accuracy:</b></td><td style='color:#64ffa0; font-weight:bold;'>%.1f%%</td></tr>"
                    + "<tr><td><b>Accuracy Base Points:</b></td><td>+%d pts</td></tr>"
                    + "<tr><td><b>Speed Bonus:</b></td><td>+%d pts</td></tr>"
                    + (perfectBonus > 0 ? "<tr><td style='color:#ffd700;'><b>Flawless Bonus:</b></td><td style='color:#ffd700;'>+200 pts</td></tr>" : "")
                    + (hintUsedThisRound ? "<tr><td style='color:#ff8888;'><b>Hint Penalty:</b></td><td style='color:#ff8888;'>-20 pts</td></tr>" : "")
                    + "<tr><td><b>Total Round Score:</b></td><td style='font-weight:bold; color:#00ffff;'>+%d pts</td></tr>"
                    + "<tr><td><b>Cumulative Score:</b></td><td style='font-weight:bold;'>%d pts</td></tr>"
                    + "</table>"
                    + "<p style='font-size:11px; color:#aaa; margin-top:10px;'>Target: RGB(%d,%d,%d) | Your Mix: RGB(%d,%d,%d)</p>"
                    + "</body></html>",
                    currentRound, TOTAL_ROUNDS, rating, accuracy, basePts, speedBonus,
                    roundPts, totalScore,
                    targetColor.getRed(), targetColor.getGreen(), targetColor.getBlue(),
                    playerR, playerG, playerB);

            JOptionPane.showMessageDialog(this, roundMsg, "Round " + currentRound + " Results", JOptionPane.INFORMATION_MESSAGE);

            if (currentRound < TOTAL_ROUNDS) {
                currentRound++;
                startRound();
            } else {
                showTournamentResults();
            }
        }

        private void showTournamentResults() {
            double avgAccuracy = totalAccuracySum / TOTAL_ROUNDS;

            String rankTitle;
            String rankBadge;
            if (avgAccuracy >= 95.0) {
                rankTitle = "Tetrachromat Vision Prodigy (Top 0.1% Visual Acuity)";
                rankBadge = "=== S+ RANK TOURNAMENT CHAMPION ===";
                SoundManager.play("save");
            } else if (avgAccuracy >= 88.0) {
                rankTitle = "Grandmaster Colorist (Master Studio Eye)";
                rankBadge = "=== S RANK MASTER COLORIST ===";
                SoundManager.play("save");
            } else if (avgAccuracy >= 78.0) {
                rankTitle = "Expert Chromaticist (Sharp Eye)";
                rankBadge = "=== A RANK EXPERT ===";
                SoundManager.play("chime");
            } else if (avgAccuracy >= 65.0) {
                rankTitle = "Skilled Studio Painter (Solid Eye)";
                rankBadge = "=== B RANK PAINTER ===";
                SoundManager.play("chime");
            } else {
                rankTitle = "Apprentice Mixer (Calibration Recommended)";
                rankBadge = "=== C RANK APPRENTICE ===";
                SoundManager.play("snap");
            }

            String certHtml = String.format("<html><body style='font-family:Segoe UI; padding:12px; width:420px;'>"
                    + "<h1 style='color:#ffd700; text-align:center; margin-bottom:2px;'>TOURNAMENT COMPLETE!</h1>"
                    + "<p style='text-align:center; font-size:15px; font-weight:bold; color:#00ffff;'>%s</p>"
                    + "<hr style='border:0; border-top:1px solid #555; margin:10px 0;'/>"
                    + "<p><b>Artist Name:</b> %s</p>"
                    + "<p><b>Honorary Title:</b> <span style='color:#ffdd55; font-weight:bold;'>%s</span></p>"
                    + "<p><b>Total Tournament Score:</b> <span style='font-size:16px; font-weight:bold; color:#64ffa0;'>%d pts</span></p>"
                    + "<p><b>Average Match Accuracy:</b> <span style='font-size:15px; font-weight:bold; color:#00ffff;'>%.1f%%</span></p>"
                    + "<p><b>Studio High Score Record:</b> %d pts</p>"
                    + "<hr style='border:0; border-top:1px solid #555; margin:10px 0;'/>"
                    + "<p style='font-size:12px; color:#aaa;'>Would you like to copy your score card to the clipboard or play another round?</p>"
                    + "</body></html>",
                    rankBadge, studio.loggedInUser, rankTitle, totalScore, avgAccuracy, topHighScore);

            Object[] options = {"Copy Scorecard", "Save Colors to Studio", "Play Again", "Done"};
            int choice = JOptionPane.showOptionDialog(this, certHtml, "Color IQ Tournament Results",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            if (choice == 0) {
                String clipboardText = String.format("🎮 [Color IQ Challenge Results]\nArtist: %s\nRank: %s (%s)\nFinal Score: %d pts\nAverage Accuracy: %.1f%%\nPlayed on: Chill Paint Master — Color Mixing Studio",
                        studio.loggedInUser, rankBadge, rankTitle, totalScore, avgAccuracy);
                Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(clipboardText), null);
                SoundManager.play("save");
                JOptionPane.showMessageDialog(this, "Score card copied to clipboard! You can paste it anywhere.", "Scorecard Copied", JOptionPane.INFORMATION_MESSAGE);
            } else if (choice == 1) {
                saveAllTournamentColorsToStudio();
            } else if (choice == 2) {
                startNewTournament();
            }
        }

        private void saveTargetColorToStudio() {
            if (targetColor == null) return;
            if (!studio.savedColors.contains(targetColor)) {
                studio.savedColors.add(0, targetColor);
            }
            studio.updatePalettePanel();
            SoundManager.play("fill");
            JOptionPane.showMessageDialog(this,
                    "Target color #" + String.format("%02X%02X%02X", targetColor.getRed(), targetColor.getGreen(), targetColor.getBlue())
                    + " successfully added to your Studio Saved Palette!",
                    "Palette Updated", JOptionPane.INFORMATION_MESSAGE);
        }

        private void saveAllTournamentColorsToStudio() {
            int added = 0;
            for (Color c : tournamentTargetColors) {
                if (!studio.savedColors.contains(c)) {
                    studio.savedColors.add(0, c);
                    added++;
                }
            }
            studio.updatePalettePanel();
            SoundManager.play("fill");
            JOptionPane.showMessageDialog(this,
                    added + " tournament colors successfully exported to your Studio Saved Palette!",
                    "Palette Updated", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // =========================================================================
    // INNER CLASS: ImageTransferable (System Clipboard Image Provider)
    // =========================================================================
    public static class ImageTransferable implements Transferable {
        private final Image image;

        public ImageTransferable(Image image) {
            this.image = image;
        }

        @Override
        public DataFlavor[] getTransferDataFlavors() {
            return new DataFlavor[] { DataFlavor.imageFlavor };
        }

        @Override
        public boolean isDataFlavorSupported(DataFlavor flavor) {
            return DataFlavor.imageFlavor.equals(flavor);
        }

        @Override
        public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException {
            if (!DataFlavor.imageFlavor.equals(flavor)) {
                throw new UnsupportedFlavorException(flavor);
            }
            return image;
        }
    }

    // =========================================================================
    // INNER CLASS: DominantColorsDialog (Image-to-Palette Extractor Modal)
    // =========================================================================
    public static class DominantColorsDialog extends JDialog {
        public DominantColorsDialog(ColorMixingStudio studio, java.util.List<Color> colors) {
            super(studio, "Dominant Color Palette Extractor", true);
            setIconImages(ColorMixingStudio.getAppIconImages());
            ColorMixingStudio.applyTaskbarIcon();
            setSize(590, 480);
            setLocationRelativeTo(studio);
            setResizable(false);

            JPanel root = new JPanel(new BorderLayout(12, 12));
            root.setBackground(BG_CARD);
            root.setBorder(new EmptyBorder(20, 24, 20, 24));

            // Header
            JPanel pnlHeader = new JPanel(new BorderLayout(4, 4));
            pnlHeader.setBackground(BG_CARD);
            JLabel lblTitle = new JLabel("Top Dominant Artwork Colors Extracted");
            lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 17));
            lblTitle.setForeground(ACCENT_CYAN);
            JLabel lblSub = new JLabel("Quantized distinct color tones extracted directly from current canvas/image.");
            lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            lblSub.setForeground(TEXT_MUTED);
            pnlHeader.add(lblTitle, BorderLayout.NORTH);
            pnlHeader.add(lblSub, BorderLayout.SOUTH);
            root.add(pnlHeader, BorderLayout.NORTH);

            // Center: Color list
            JPanel pnlList = new JPanel();
            pnlList.setLayout(new BoxLayout(pnlList, BoxLayout.Y_AXIS));
            pnlList.setBackground(BG_CARD);

            for (int i = 0; i < colors.size(); i++) {
                final Color c = colors.get(i);
                String hex = String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
                String rgb = String.format("RGB(%d, %d, %d)", c.getRed(), c.getGreen(), c.getBlue());

                JPanel card = new JPanel(new BorderLayout(12, 0));
                card.setBackground(BG_DARK);
                card.setBorder(BorderFactory.createCompoundBorder(
                        new LineBorder(new Color(60, 68, 85), 1, true),
                        new EmptyBorder(8, 12, 8, 12)
                ));
                card.setMaximumSize(new Dimension(540, 52));

                // Left: Swatch + Hex/RGB
                JPanel pnlLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
                pnlLeft.setBackground(BG_DARK);

                JPanel swatch = new JPanel() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        g2.setColor(c);
                        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                        g2.setColor(Color.WHITE);
                        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                        g2.dispose();
                    }
                };
                swatch.setPreferredSize(new Dimension(36, 32));
                swatch.setOpaque(false);

                JPanel pnlInfo = new JPanel();
                pnlInfo.setLayout(new BoxLayout(pnlInfo, BoxLayout.Y_AXIS));
                pnlInfo.setBackground(BG_DARK);
                JLabel lblHex = new JLabel(hex);
                lblHex.setFont(new Font("Consolas", Font.BOLD, 13));
                lblHex.setForeground(Color.WHITE);
                JLabel lblRgb = new JLabel(rgb);
                lblRgb.setFont(new Font("Segoe UI", Font.PLAIN, 11));
                lblRgb.setForeground(TEXT_MUTED);
                pnlInfo.add(lblHex);
                pnlInfo.add(lblRgb);

                pnlLeft.add(swatch);
                pnlLeft.add(pnlInfo);
                card.add(pnlLeft, BorderLayout.WEST);

                // Right: Action buttons (White background, Black text)
                JPanel pnlActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
                pnlActions.setBackground(BG_DARK);

                JButton btnC1 = new JButton("Set Color 1");
                styleButton(btnC1, Color.WHITE);
                btnC1.setFont(new Font("Segoe UI", Font.BOLD, 11));
                btnC1.addActionListener(e -> {
                    studio.r1 = c.getRed(); studio.g1 = c.getGreen(); studio.b1 = c.getBlue();
                    studio.sR1.setValue(studio.r1); studio.sG1.setValue(studio.g1); studio.sB1.setValue(studio.b1);
                    studio.recalculateAndRepaint();
                    SoundManager.play("click");
                });

                JButton btnC2 = new JButton("Set Color 2");
                styleButton(btnC2, Color.WHITE);
                btnC2.setFont(new Font("Segoe UI", Font.BOLD, 11));
                btnC2.addActionListener(e -> {
                    studio.r2 = c.getRed(); studio.g2 = c.getGreen(); studio.b2 = c.getBlue();
                    studio.sR2.setValue(studio.r2); studio.sG2.setValue(studio.g2); studio.sB2.setValue(studio.b2);
                    studio.recalculateAndRepaint();
                    SoundManager.play("click");
                });

                JButton btnBrush = new JButton("Set Brush");
                styleButton(btnBrush, Color.WHITE);
                btnBrush.setFont(new Font("Segoe UI", Font.BOLD, 11));
                btnBrush.addActionListener(e -> {
                    if (studio.paintCanvas != null) {
                        studio.paintCanvas.shapeFillColor = c;
                        studio.paintCanvas.syncFillWithMixed = false;
                        if (studio.pnlShapeFillSwatch != null) studio.pnlShapeFillSwatch.setBackground(c);
                        studio.paintCanvas.fillSelectedOrLastShape(c);
                    }
                    SoundManager.play("click");
                });

                pnlActions.add(btnC1);
                pnlActions.add(btnC2);
                pnlActions.add(btnBrush);
                card.add(pnlActions, BorderLayout.EAST);

                pnlList.add(card);
                pnlList.add(Box.createVerticalStrut(6));
            }

            JScrollPane scroll = new JScrollPane(pnlList);
            scroll.setBorder(null);
            scroll.setBackground(BG_CARD);
            scroll.getViewport().setBackground(BG_CARD);
            root.add(scroll, BorderLayout.CENTER);

            // Footer
            JPanel pnlFooter = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
            pnlFooter.setBackground(BG_CARD);
            JLabel lblNote = new JLabel("All colors have also been auto-saved to your Palette bar.");
            lblNote.setFont(new Font("Segoe UI", Font.ITALIC, 11));
            lblNote.setForeground(ACCENT_GOLD);
            JButton btnClose = new JButton("Close");
            styleButton(btnClose, Color.WHITE);
            btnClose.setPreferredSize(new Dimension(90, 30));
            btnClose.addActionListener(e -> dispose());
            pnlFooter.add(lblNote);
            pnlFooter.add(btnClose);
            root.add(pnlFooter, BorderLayout.SOUTH);

            setContentPane(root);
        }
    }

    // =========================================================================
    // INNER CLASS: StudioFiltersDialog (Studio Digital Filters Lab)
    // =========================================================================
    public static class StudioFiltersDialog extends JDialog {
        public StudioFiltersDialog(ColorMixingStudio studio, PaintCanvas canvas) {
            super(studio, "Studio Post-Processing Image Filters Lab", true);
            setIconImages(ColorMixingStudio.getAppIconImages());
            ColorMixingStudio.applyTaskbarIcon();
            setSize(660, 520);
            setLocationRelativeTo(studio);
            setResizable(false);

            JPanel root = new JPanel(new BorderLayout(14, 14));
            root.setBackground(BG_CARD);
            root.setBorder(new EmptyBorder(20, 24, 20, 24));

            // Header
            JPanel pnlHeader = new JPanel(new BorderLayout(4, 4));
            pnlHeader.setBackground(BG_CARD);
            JLabel lblTitle = new JLabel("Studio Digital Post-Processing Shaders & FX");
            lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 17));
            lblTitle.setForeground(ACCENT_CYAN);
            JLabel lblSub = new JLabel("Apply non-destructive digital filters directly to your artwork (Ctrl+Z to Undo anytime).");
            lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            lblSub.setForeground(TEXT_MUTED);
            pnlHeader.add(lblTitle, BorderLayout.NORTH);
            pnlHeader.add(lblSub, BorderLayout.SOUTH);
            root.add(pnlHeader, BorderLayout.NORTH);

            // Filter options grid
            JPanel pnlGrid = new JPanel(new GridLayout(3, 2, 12, 12));
            pnlGrid.setBackground(BG_CARD);

            String[][] filters = {
                {"8-Bit Retro Pixelate", "Quantizes pixels into 8x8 blocky retro arcade aesthetic."},
                {"Cinematic Vignette", "Subtle darkening gradient along artwork corners & borders."},
                {"Vintage Sepia", "Warm antique photographic tone (Human visual spectrum warmth)."},
                {"Invert / Negative FX", "RGB color inversion (255 - R/G/B) for X-ray / neon contrast."},
                {"Cyberpunk Neon Boost", "Gamma curves boosting electric blues, hot pinks & saturations."},
                {"Monochrome Grayscale", "Standard ITU-R BT.601 photometric luminance desaturation."}
            };

            for (String[] f : filters) {
                final String name = f[0];
                String desc = f[1];

                JPanel card = new JPanel(new BorderLayout(6, 6));
                card.setBackground(BG_DARK);
                card.setBorder(BorderFactory.createCompoundBorder(
                        new LineBorder(new Color(60, 68, 85), 1, true),
                        new EmptyBorder(10, 12, 10, 12)
                ));

                JPanel pnlText = new JPanel();
                pnlText.setLayout(new BoxLayout(pnlText, BoxLayout.Y_AXIS));
                pnlText.setBackground(BG_DARK);

                JLabel lblName = new JLabel(name);
                lblName.setFont(new Font("Segoe UI", Font.BOLD, 13));
                lblName.setForeground(Color.WHITE);

                JLabel lblDesc = new JLabel("<html><body style='width:180px;'>" + desc + "</body></html>");
                lblDesc.setFont(new Font("Segoe UI", Font.PLAIN, 11));
                lblDesc.setForeground(TEXT_MUTED);

                pnlText.add(lblName);
                pnlText.add(Box.createVerticalStrut(4));
                pnlText.add(lblDesc);
                card.add(pnlText, BorderLayout.CENTER);

                JButton btnApply = new JButton("Apply Filter");
                styleButton(btnApply, Color.WHITE);
                btnApply.setFont(new Font("Segoe UI", Font.BOLD, 11));
                btnApply.addActionListener(e -> {
                    canvas.applyFilter(name);
                    JOptionPane.showMessageDialog(this,
                            name + " applied successfully!\nUse 'Undo' (Ctrl+Z) if you wish to revert.",
                            "Filter Applied", JOptionPane.INFORMATION_MESSAGE);
                });
                card.add(btnApply, BorderLayout.SOUTH);

                pnlGrid.add(card);
            }

            root.add(pnlGrid, BorderLayout.CENTER);

            // Footer
            JPanel pnlFooter = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
            pnlFooter.setBackground(BG_CARD);
            JButton btnClose = new JButton("Done / Close");
            styleButton(btnClose, Color.WHITE);
            btnClose.setPreferredSize(new Dimension(110, 32));
            btnClose.addActionListener(e -> dispose());
            pnlFooter.add(btnClose);
            root.add(pnlFooter, BorderLayout.SOUTH);

            setContentPane(root);
        }
    }

    // =========================================================================
    // INNER CLASS: TimelapseReplayDialog (Artwork Drawing Creation Replay)
    // =========================================================================
    public static class TimelapseReplayDialog extends JDialog {
        private final java.util.List<BufferedImage> frames;
        private int currentFrameIndex = 0;
        private javax.swing.Timer playTimer;
        private boolean isPlaying = false;
        private int playSpeedMs = 250;

        private final JLabel lblFrameCounter;
        private final JSlider scrubber;
        private final JButton btnPlayPause;
        private final JPanel pnlScreen;

        public TimelapseReplayDialog(ColorMixingStudio studio, java.util.List<BufferedImage> frameList) {
            super(studio, "Artwork Drawing Timelapse Replay Player", true);
            this.frames = (frameList != null && !frameList.isEmpty())
                    ? new ArrayList<>(frameList)
                    : Collections.emptyList();

            setIconImages(ColorMixingStudio.getAppIconImages());
            ColorMixingStudio.applyTaskbarIcon();
            setSize(780, 620);
            setLocationRelativeTo(studio);
            setResizable(false);

            JPanel root = new JPanel(new BorderLayout(12, 12));
            root.setBackground(BG_CARD);
            root.setBorder(new EmptyBorder(16, 20, 16, 20));

            // Header
            JPanel pnlHeader = new JPanel(new BorderLayout(4, 4));
            pnlHeader.setBackground(BG_CARD);
            JLabel lblTitle = new JLabel("Artwork Timelapse Video Player");
            lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 17));
            lblTitle.setForeground(ACCENT_CYAN);
            JLabel lblSub = new JLabel("Watch step-by-step history of how this drawing was crafted from blank canvas to masterpiece.");
            lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            lblSub.setForeground(TEXT_MUTED);
            pnlHeader.add(lblTitle, BorderLayout.NORTH);
            pnlHeader.add(lblSub, BorderLayout.SOUTH);
            root.add(pnlHeader, BorderLayout.NORTH);

            // Replay Screen Center
            pnlScreen = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);

                    int w = getWidth(), h = getHeight();
                    g2.setColor(new Color(15, 17, 22));
                    g2.fillRect(0, 0, w, h);

                    if (!frames.isEmpty() && currentFrameIndex >= 0 && currentFrameIndex < frames.size()) {
                        BufferedImage img = frames.get(currentFrameIndex);
                        if (img != null) {
                            int iw = img.getWidth(), ih = img.getHeight();
                            double scale = Math.min((double) (w - 20) / iw, (double) (h - 20) / ih);
                            int dw = Math.max(1, (int) Math.round(iw * scale));
                            int dh = Math.max(1, (int) Math.round(ih * scale));
                            int dx = (w - dw) / 2;
                            int dy = (h - dh) / 2;

                            // Shadow
                            g2.setColor(new Color(0, 0, 0, 100));
                            g2.fillRoundRect(dx + 4, dy + 4, dw, dh, 6, 6);

                            // Canvas frame
                            g2.drawImage(img, dx, dy, dw, dh, null);
                            g2.setColor(new Color(80, 90, 110));
                            g2.drawRoundRect(dx, dy, dw, dh, 6, 6);
                        }
                    } else {
                        g2.setColor(TEXT_MUTED);
                        g2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                        String msg = "No drawing history frames recorded yet.";
                        FontMetrics fm = g2.getFontMetrics();
                        g2.drawString(msg, (w - fm.stringWidth(msg)) / 2, h / 2);
                    }
                    g2.dispose();
                }
            };
            pnlScreen.setBackground(new Color(15, 17, 22));
            pnlScreen.setBorder(new LineBorder(new Color(50, 58, 72), 1, true));
            root.add(pnlScreen, BorderLayout.CENTER);

            // Controls Panel
            JPanel pnlControls = new JPanel();
            pnlControls.setLayout(new BoxLayout(pnlControls, BoxLayout.Y_AXIS));
            pnlControls.setBackground(BG_CARD);

            // Scrubber Row
            JPanel pnlScrub = new JPanel(new BorderLayout(8, 0));
            pnlScrub.setBackground(BG_CARD);

            int maxIndex = Math.max(0, frames.size() - 1);
            scrubber = new JSlider(0, maxIndex, 0);
            scrubber.setBackground(BG_CARD);
            scrubber.setForeground(ACCENT_CYAN);
            scrubber.addChangeListener(e -> {
                if (!scrubber.getValueIsAdjusting() || isPlaying) {
                    currentFrameIndex = scrubber.getValue();
                    updateCounter();
                    pnlScreen.repaint();
                }
            });

            lblFrameCounter = new JLabel("Frame 1 / " + Math.max(1, frames.size()), SwingConstants.RIGHT);
            lblFrameCounter.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblFrameCounter.setForeground(ACCENT_CYAN);
            lblFrameCounter.setPreferredSize(new Dimension(100, 24));

            pnlScrub.add(scrubber, BorderLayout.CENTER);
            pnlScrub.add(lblFrameCounter, BorderLayout.EAST);
            pnlControls.add(pnlScrub);
            pnlControls.add(Box.createVerticalStrut(8));

            // Buttons Row
            JPanel pnlButtons = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
            pnlButtons.setBackground(BG_CARD);

            JButton btnRestart = new JButton("Restart");
            styleButton(btnRestart, Color.WHITE);
            btnRestart.addActionListener(e -> {
                currentFrameIndex = 0;
                scrubber.setValue(0);
                updateCounter();
                pnlScreen.repaint();
            });

            btnPlayPause = new JButton("Play");
            styleButton(btnPlayPause, Color.WHITE);
            btnPlayPause.setPreferredSize(new Dimension(90, 32));
            btnPlayPause.addActionListener(e -> togglePlay());

            JLabel lblSpeed = new JLabel("Speed:");
            lblSpeed.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            lblSpeed.setForeground(TEXT_LIGHT);

            JComboBox<String> cbSpeed = new JComboBox<>(new String[] {"1x Normal", "2x Fast", "4x Super Fast", "8x Hyper"});
            cbSpeed.setBackground(Color.WHITE);
            cbSpeed.setForeground(Color.BLACK);
            cbSpeed.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            cbSpeed.addActionListener(e -> {
                int sel = cbSpeed.getSelectedIndex();
                if (sel == 0) playSpeedMs = 250;
                else if (sel == 1) playSpeedMs = 120;
                else if (sel == 2) playSpeedMs = 60;
                else playSpeedMs = 25;
                if (playTimer != null && playTimer.isRunning()) {
                    playTimer.setDelay(playSpeedMs);
                }
            });

            JButton btnClose = new JButton("Close");
            styleButton(btnClose, Color.WHITE);
            btnClose.addActionListener(e -> {
                if (playTimer != null) playTimer.stop();
                dispose();
            });

            pnlButtons.add(btnRestart);
            pnlButtons.add(btnPlayPause);
            pnlButtons.add(Box.createHorizontalStrut(10));
            pnlButtons.add(lblSpeed);
            pnlButtons.add(cbSpeed);
            pnlButtons.add(Box.createHorizontalStrut(10));
            pnlButtons.add(btnClose);

            pnlControls.add(pnlButtons);
            root.add(pnlControls, BorderLayout.SOUTH);

            // Timer for playback
            playTimer = new javax.swing.Timer(playSpeedMs, e -> {
                if (currentFrameIndex < frames.size() - 1) {
                    currentFrameIndex++;
                    scrubber.setValue(currentFrameIndex);
                    updateCounter();
                    pnlScreen.repaint();
                } else {
                    stopPlay();
                }
            });

            addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    if (playTimer != null) playTimer.stop();
                }
            });

            setContentPane(root);
            updateCounter();
        }

        private void togglePlay() {
            if (isPlaying) {
                stopPlay();
            } else {
                startPlay();
            }
        }

        private void startPlay() {
            if (frames.isEmpty()) return;
            if (currentFrameIndex >= frames.size() - 1) {
                currentFrameIndex = 0;
                scrubber.setValue(0);
            }
            isPlaying = true;
            btnPlayPause.setText("Pause");
            playTimer.setDelay(playSpeedMs);
            playTimer.start();
        }

        private void stopPlay() {
            isPlaying = false;
            btnPlayPause.setText("Play");
            if (playTimer != null) playTimer.stop();
        }

        private void updateCounter() {
            int total = Math.max(1, frames.size());
            int cur = frames.isEmpty() ? 0 : (currentFrameIndex + 1);
            lblFrameCounter.setText("Frame " + cur + " / " + total);
        }
    }

    // =========================================================================
    // INNER CLASS: StudioSplashScreen (3.5s Animated Startup Loading Screen)
    // =========================================================================

    public static class StudioSplashScreen extends JWindow {
        private JProgressBar progressBar;
        private JLabel lblStatus;

        public StudioSplashScreen() {
            applyTaskbarIcon();
            setSize(520, 360);
            setLocationRelativeTo(null);

            JPanel mainPanel = new JPanel();
            mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
            mainPanel.setBackground(BG_CARD);
            mainPanel.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(ACCENT_CYAN, 2, true),
                    new EmptyBorder(25, 30, 25, 30)
            ));

            // Logo Wrapper
            JPanel logoWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
            logoWrapper.setOpaque(false);
            StudioLogo logo = new StudioLogo(84, 84);
            logoWrapper.add(logo);
            mainPanel.add(logoWrapper);
            mainPanel.add(Box.createVerticalStrut(14));

            // Title
            JLabel title = new JLabel("CHILL PAINT MASTER", SwingConstants.CENTER);
            title.setFont(new Font("Segoe UI", Font.BOLD, 24));
            title.setForeground(ACCENT_GOLD);
            title.setAlignmentX(Component.CENTER_ALIGNMENT);
            mainPanel.add(title);
            mainPanel.add(Box.createVerticalStrut(4));

            // Subtitle
            JLabel subtitle = new JLabel("Interactive Color Mixing & Creative Canvas Studio", SwingConstants.CENTER);
            subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            subtitle.setForeground(TEXT_MUTED);
            subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
            mainPanel.add(subtitle);
            mainPanel.add(Box.createVerticalStrut(24));

            // Status Label
            lblStatus = new JLabel("Initializing Studio Engine...", SwingConstants.CENTER);
            lblStatus.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblStatus.setForeground(ACCENT_CYAN);
            lblStatus.setAlignmentX(Component.CENTER_ALIGNMENT);
            mainPanel.add(lblStatus);
            mainPanel.add(Box.createVerticalStrut(10));

            // Progress Bar
            progressBar = new JProgressBar(0, 100);
            progressBar.setPreferredSize(new Dimension(460, 8));
            progressBar.setMaximumSize(new Dimension(460, 8));
            progressBar.setAlignmentX(Component.CENTER_ALIGNMENT);
            progressBar.setForeground(ACCENT_GOLD);
            progressBar.setBackground(BG_INPUT);
            progressBar.setBorderPainted(false);
            mainPanel.add(progressBar);
            mainPanel.add(Box.createVerticalStrut(12));

            // Version info footer
            JLabel lblVersion = new JLabel("Version 2.0 Pro • Loading Workbench...", SwingConstants.CENTER);
            lblVersion.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            lblVersion.setForeground(TEXT_MUTED);
            lblVersion.setAlignmentX(Component.CENTER_ALIGNMENT);
            mainPanel.add(lblVersion);

            setContentPane(mainPanel);
        }

        public void showSplashAndProceed(Runnable onFinish) {
            setVisible(true);
            SoundManager.play("chime");

            Thread loaderThread = new Thread(() -> {
                final int totalDuration = 3500; // 3.5 seconds
                final int steps = 70;
                final int sleepTime = totalDuration / steps;

                String[] messages = {
                    "Initializing Obsidian Color Engine...",
                    "Loading Mathematical Blend Formulas...",
                    "Calibrating In-Memory Audio Synthesizer...",
                    "Building Vector Geometry & Canvas Tools...",
                    "Connecting Artist Authentication Portal...",
                    "Launching Chill Paint Master Studio..."
                };

                for (int i = 0; i <= steps; i++) {
                    final int percent = (int) ((i / (double) steps) * 100);
                    int msgIdx = Math.min(messages.length - 1, (i * messages.length) / steps);
                    final String msg = messages[msgIdx];

                    SwingUtilities.invokeLater(() -> {
                        progressBar.setValue(percent);
                        lblStatus.setText(msg);
                    });

                    try {
                        Thread.sleep(sleepTime);
                    } catch (InterruptedException ignored) {}
                }

                try { Thread.sleep(200); } catch (InterruptedException ignored) {}

                SwingUtilities.invokeLater(() -> {
                    dispose();
                    if (onFinish != null) onFinish.run();
                });
            });
            loaderThread.start();
        }
    }

    public static void showApp() {
        showApp(true);
    }

    public static void showApp(boolean withSplash) {
        SwingUtilities.invokeLater(() -> {
            Runnable launchLogin = () -> {
                StudioLoginDialog login = new StudioLoginDialog(null);
                login.setVisible(true);

                String artist = login.authenticatedUser;
                if (artist != null && !artist.isEmpty()) {
                    ColorMixingStudio studio = new ColorMixingStudio(artist);
                    studio.setVisible(true);
                } else {
                    System.exit(0);
                }
            };

            if (withSplash) {
                StudioSplashScreen splash = new StudioSplashScreen();
                splash.showSplashAndProceed(launchLogin);
            } else {
                launchLogin.run();
            }
        });
    }

    public static void main(String[] args) {
        applyTaskbarIcon();
        showApp();
    }
}
