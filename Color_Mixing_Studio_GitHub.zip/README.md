# 🎨 Chill Paint Master — Color Mixing Studio & Creative Vector Workbench

[![Java](https://img.shields.io/badge/Java-26%2B-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)](https://www.oracle.com/java/)
[![GUI](https://img.shields.io/badge/GUI-Swing%20%2F%20AWT-blue?style=for-the-badge)](https://docs.oracle.com/javase/tutorial/uiswing/)
[![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)](https://github.com/)

An advanced, interactive digital paint studio and spectrophotometric color mixing suite engineered in pure **Java (Swing & Java 2D)**. Designed for graphic artists, UI/UX designers, and students of color science.

---

## 🌟 Key Features

### 1. 🎮 Color IQ Challenge Mini-Game (NEW!)
- **5-Round Tournament Mode**: Match a mystery target color within 35 seconds.
- **Precision RGB Controls**: Fine-tune channels using tactile sliders and `[-10]`, `[-1]`, `[+1]`, `[+10]` micro-step buttons.
- **Perceptual Optical Algorithm**: Calculates match accuracy using human ocular sensitivity metrics ($\Delta C = \sqrt{2\Delta R^2 + 4\Delta G^2 + 3\Delta B^2}$).
- **Tournament Honors & Export**: Earn **S+ Rank (Tetrachromat Vision)**, copy scorecards, and push winning colors straight to the canvas.

### 2. 🧪 Scientific Color Theory & WCAG 2.1 Accessibility Lab
- Real-time relative luminance calculation ($L = 0.2126R + 0.7152G + 0.0722B$).
- WCAG 2.1 contrast ratio checker with AAA/AA compliance badges for UI designers.
- Color Vision Deficiency (CVD) simulation: **Protanopia**, **Deuteranopia**, and **Tritanopia**.

### 3. 🎨 Dual-Source Color Mixing Engine
- 8 Advanced Blending Algorithms: **Linear Lerp**, **Additive**, **Subtractive (CMYK)**, **Multiply**, **Screen**, **Overlay**, **Hard Light**, and **Difference**.
- Real-time slider ratio blending with live HEX, RGB, and HSV telemetry.
- Dynamic harmonic color generator: Complementary, Analogous, Triadic, and Tetradic harmonies.

### 4. 🖌️ Vector Canvas & Creative FX
- **Radial Kaleidoscope Mode**: 4x, 8x, 12x, and 16x rotational symmetry live drawing.
- **Luminous Neon Bloom**: Cyberpunk glowing particle brush with soft light blending.
- **Pura Fill & Paint Bucket**: Instant flood-fill algorithm for bounded areas and vector shapes.
- **Procedural Magic Art**: Mathematical generative art (Sacred Mandalas, Fibonacci Spirals, Sine Waves).
- **Audio Synthesizer Engine**: Real-time synthesized acoustic feedback (no external `.wav` dependencies).

---

## 📸 Screenshots

| Splash Screen | Studio Login Portal |
| :---: | :---: |
| ![Splash Screen](screenshots/splash_screen.png) | ![Login Portal](screenshots/login_portal.png) |

| Color IQ Challenge Game | Main Studio Canvas |
| :---: | :---: |
| ![Color IQ Game](screenshots/color_iq_game.png) | ![Main Studio](screenshots/studio_main.png) |

---

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
| :---: | :--- |
| <kbd>Ctrl</kbd> + <kbd>G</kbd> | Launch **Color IQ Challenge Tournament** |
| <kbd>Ctrl</kbd> + <kbd>T</kbd> | Open **Color Theory & Accessibility Lab** |
| <kbd>Ctrl</kbd> + <kbd>M</kbd> | Open **Procedural Magic Art Generator** |
| <kbd>Ctrl</kbd> + <kbd>Z</kbd> | Undo canvas action |
| <kbd>Ctrl</kbd> + <kbd>Y</kbd> | Redo canvas action |
| <kbd>Ctrl</kbd> + <kbd>C</kbd> | Copy canvas artwork to system clipboard |
| <kbd>Ctrl</kbd> + <kbd>S</kbd> | Save artwork as high-resolution PNG |
| <kbd>Ctrl</kbd> + <kbd>O</kbd> | Open external image to edit |
| <kbd>F11</kbd> | Toggle Fullscreen Showcase / Presentation Mode |

---

## 🚀 How to Run

### Method 1: Direct 1-Click Launch (Recommended)
Double-click `run.bat` or run:
```bat
run.bat
```

### Method 2: Java Command Line
Ensure you have **Java JDK 17 or higher** installed:
```bash
# Compile
javac -encoding UTF-8 ColorMixingStudio.java

# Run
java ColorMixingStudio
```

### Method 3: Standalone JAR
```bash
java -jar ColorMixingStudio.jar
```

---

## 👤 Author

- **Alfez Khan**  
- Bachelor of Computer Applications (BCA)  
- Adarsh College of Professional Studies  

---

## 📄 License
This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.
