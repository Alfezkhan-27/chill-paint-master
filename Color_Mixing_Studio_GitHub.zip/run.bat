@echo off
title Color Mixing Studio Launcher
cd /d "%~dp0"
echo Compiling ColorMixingStudio.java...
javac -encoding UTF-8 ColorMixingStudio.java
if %errorlevel% neq 0 (
    echo Compilation failed!
    pause
    exit /b %errorlevel%
)
echo Launching Color Mixing Studio...
java -cp . ColorMixingStudio
pause
